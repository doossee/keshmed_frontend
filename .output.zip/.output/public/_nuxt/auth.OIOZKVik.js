import{ax as a,ay as t,az as e}from"./entry.7ugRP3Aw.js";const s=a((o,n)=>{t().value||e("/login",{external:!0})});export{s as default};
//# sourceMappingURL=auth.OIOZKVik.js.map
