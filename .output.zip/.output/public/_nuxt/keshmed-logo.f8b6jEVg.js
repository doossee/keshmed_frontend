import"./entry.7ugRP3Aw.js";const o=""+globalThis.__publicAssetsURL("keshmed-logo.png");export{o as _};
//# sourceMappingURL=keshmed-logo.f8b6jEVg.js.map
