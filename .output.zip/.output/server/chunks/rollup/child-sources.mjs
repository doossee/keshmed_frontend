const sources = {};

export { sources };
