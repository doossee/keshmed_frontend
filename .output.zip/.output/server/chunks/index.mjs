import { i as iconBase } from './icon-base.mjs';

const ClRemoveMinus=props=>iconBase(props,`<svg width="24" height="24" fill="none" viewBox="0 0 24 24"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 12h12"/></svg>`);
const ClSearchMagnifyingGlass=props=>iconBase(props,`<svg width="24" height="24" fill="none" viewBox="0 0 24 24"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m15 15 6 6m-11-4a7 7 0 1 1 0-14 7 7 0 0 1 0 14Z"/></svg>`);
const ClCloseMd=props=>iconBase(props,`<svg width="24" height="24" fill="none" viewBox="0 0 24 24"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m18 18-6-6m0 0L6 6m6 6 6-6m-6 6-6 6"/></svg>`);

export { ClSearchMagnifyingGlass as C, ClCloseMd as a, ClRemoveMinus as b };
