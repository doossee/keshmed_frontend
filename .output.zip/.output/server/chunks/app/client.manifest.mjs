const client_manifest = {
  "_AppProductCard.vue.MkOdVf8S.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "AppProductCard.vue.MkOdVf8S.js",
    "imports": [
      "_index.1yCehivy.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_client-only.oAdxK6Sw.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "client-only.oAdxK6Sw.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_icon-base.vvY7qceX.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "icon-base.vvY7qceX.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.1yCehivy.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.1yCehivy.js",
    "imports": [
      "_icon-base.vvY7qceX.js",
      "_index.5lIj2-WH.js"
    ]
  },
  "_index.5lIj2-WH.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.5lIj2-WH.js",
    "imports": [
      "_icon-base.vvY7qceX.js"
    ]
  },
  "_index.lIBEqVyA.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.lIBEqVyA.js",
    "imports": [
      "_icon-base.vvY7qceX.js"
    ]
  },
  "_index.xfqLyiTU.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.xfqLyiTU.js",
    "imports": [
      "_icon-base.vvY7qceX.js"
    ]
  },
  "_index.zoal7U0i.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.zoal7U0i.js",
    "imports": [
      "_icon-base.vvY7qceX.js"
    ]
  },
  "_keshmed-logo.f8b6jEVg.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "keshmed-logo.f8b6jEVg.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_lodash.orgtvGpf.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "lodash.orgtvGpf.js",
    "imports": [
      "_icon-base.vvY7qceX.js"
    ]
  },
  "_useBrands.hvrC5f7P.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useBrands.hvrC5f7P.js"
  },
  "_useCategories.irO-WxiL.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useCategories.irO-WxiL.js"
  },
  "_useOrders.IqAoDDSj.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useOrders.IqAoDDSj.js"
  },
  "_useProducts.p1LffWDY.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useProducts.p1LffWDY.js"
  },
  "_vue.f36acd1f.tp68LqwU.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vue.f36acd1f.tp68LqwU.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "i18n.config.ts?hash=bffaebcb&config=1": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "i18n.config.PK8ZAroV.js",
    "isDynamicEntry": true,
    "src": "i18n.config.ts?hash=bffaebcb&config=1"
  },
  "layouts/admin-layout.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin-layout.5q5Sre0P.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.1yCehivy.js",
      "_index.5lIj2-WH.js",
      "_keshmed-logo.f8b6jEVg.js",
      "_client-only.oAdxK6Sw.js",
      "_icon-base.vvY7qceX.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/admin-layout.vue"
  },
  "layouts/index-layout.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index-layout.9S6GYWQv.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.1yCehivy.js",
      "_keshmed-logo.f8b6jEVg.js",
      "_client-only.oAdxK6Sw.js",
      "_icon-base.vvY7qceX.js",
      "_index.5lIj2-WH.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/index-layout.vue"
  },
  "middleware/auth.ts": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "auth.OIOZKVik.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/auth.ts"
  },
  "node_modules/@mdi/font/fonts/materialdesignicons-webfont.eot": {
    "resourceType": "font",
    "mimeType": "font/eot",
    "file": "materialdesignicons-webfont.kq_ClZaA.eot",
    "src": "node_modules/@mdi/font/fonts/materialdesignicons-webfont.eot"
  },
  "node_modules/@mdi/font/fonts/materialdesignicons-webfont.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "materialdesignicons-webfont.e5j8FT_3.ttf",
    "src": "node_modules/@mdi/font/fonts/materialdesignicons-webfont.ttf"
  },
  "node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "materialdesignicons-webfont.D15t_tsC.woff",
    "src": "node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff"
  },
  "node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "materialdesignicons-webfont.6eb_lmTU.woff2",
    "src": "node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff2"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "assets": [
      "materialdesignicons-webfont.kq_ClZaA.eot",
      "materialdesignicons-webfont.6eb_lmTU.woff2",
      "materialdesignicons-webfont.D15t_tsC.woff",
      "materialdesignicons-webfont.e5j8FT_3.ttf"
    ],
    "css": [
      "entry.CwUnOkqc.css"
    ],
    "dynamicImports": [
      "middleware/auth.ts",
      "layouts/admin-layout.vue",
      "layouts/index-layout.vue",
      "i18n.config.ts?hash=bffaebcb&config=1"
    ],
    "file": "entry.7ugRP3Aw.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.CwUnOkqc.css": {
    "file": "entry.CwUnOkqc.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "materialdesignicons-webfont.kq_ClZaA.eot": {
    "file": "materialdesignicons-webfont.kq_ClZaA.eot",
    "resourceType": "font",
    "mimeType": "font/eot"
  },
  "materialdesignicons-webfont.6eb_lmTU.woff2": {
    "file": "materialdesignicons-webfont.6eb_lmTU.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "materialdesignicons-webfont.D15t_tsC.woff": {
    "file": "materialdesignicons-webfont.D15t_tsC.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "materialdesignicons-webfont.e5j8FT_3.ttf": {
    "file": "materialdesignicons-webfont.e5j8FT_3.ttf",
    "resourceType": "font",
    "mimeType": "font/ttf"
  },
  "pages/admin/brands.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "brands.YnFC_boV.js",
    "imports": [
      "_useBrands.hvrC5f7P.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_lodash.orgtvGpf.js",
      "_index.1yCehivy.js",
      "_index.xfqLyiTU.js",
      "_index.5lIj2-WH.js",
      "_index.lIBEqVyA.js",
      "_index.zoal7U0i.js",
      "_icon-base.vvY7qceX.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/brands.vue"
  },
  "pages/admin/categories.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "categories.uyDWNm9m.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.5lIj2-WH.js",
      "_index.lIBEqVyA.js",
      "_index.zoal7U0i.js",
      "_useCategories.irO-WxiL.js",
      "_index.xfqLyiTU.js",
      "_icon-base.vvY7qceX.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/categories.vue"
  },
  "pages/admin/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.1ALCF4I3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_useProducts.p1LffWDY.js",
      "_useCategories.irO-WxiL.js",
      "_useBrands.hvrC5f7P.js",
      "_lodash.orgtvGpf.js",
      "_index.1yCehivy.js",
      "_index.xfqLyiTU.js",
      "_index.5lIj2-WH.js",
      "_index.lIBEqVyA.js",
      "_index.zoal7U0i.js",
      "_icon-base.vvY7qceX.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/index.vue"
  },
  "pages/admin/orders.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "orders.E05YctsL.js",
    "imports": [
      "_useOrders.IqAoDDSj.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_lodash.orgtvGpf.js",
      "_index.5lIj2-WH.js",
      "_index.xfqLyiTU.js",
      "_icon-base.vvY7qceX.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/orders.vue"
  },
  "pages/index/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.izeaALHj.js",
    "imports": [
      "_AppProductCard.vue.MkOdVf8S.js",
      "_vue.f36acd1f.tp68LqwU.js",
      "_useProducts.p1LffWDY.js",
      "_lodash.orgtvGpf.js",
      "_index.1yCehivy.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.5lIj2-WH.js",
      "_index.xfqLyiTU.js",
      "_icon-base.vvY7qceX.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index/index.vue"
  },
  "pages/index/product/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.UiTrT67d.js",
    "imports": [
      "_AppProductCard.vue.MkOdVf8S.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useOrders.IqAoDDSj.js",
      "_useProducts.p1LffWDY.js",
      "_vue.f36acd1f.tp68LqwU.js",
      "_index.1yCehivy.js",
      "_index.zoal7U0i.js",
      "_icon-base.vvY7qceX.js",
      "_index.5lIj2-WH.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index/product/[id].vue"
  },
  "pages/index/products.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "products.aKzbIz-X.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_vue.f36acd1f.tp68LqwU.js",
      "_useProducts.p1LffWDY.js",
      "_useCategories.irO-WxiL.js",
      "_useBrands.hvrC5f7P.js",
      "_lodash.orgtvGpf.js",
      "_icon-base.vvY7qceX.js",
      "_index.xfqLyiTU.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index/products.vue"
  },
  "pages/login.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "login.G4tvzTF0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_keshmed-logo.f8b6jEVg.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/login.vue"
  }
};

export { client_manifest as default };
