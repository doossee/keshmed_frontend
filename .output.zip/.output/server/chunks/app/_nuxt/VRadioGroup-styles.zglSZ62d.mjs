import { V as VRadioGroup } from './entry-styles-83.mjs-DCcmUJn7.mjs';

const VRadioGroupStyles_zglSZ62d = [VRadioGroup];

export { VRadioGroupStyles_zglSZ62d as default };
