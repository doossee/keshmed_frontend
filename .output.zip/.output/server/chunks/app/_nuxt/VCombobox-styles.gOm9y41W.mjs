import { V as VCombobox } from './entry-styles-57.mjs--X_bZD5P.mjs';

const VComboboxStyles_gOm9y41W = [VCombobox];

export { VComboboxStyles_gOm9y41W as default };
