import { V as VBanner } from './entry-styles-39.mjs-qo6At-s8.mjs';

const VBannerStyles_Gm6PMQtE = [VBanner];

export { VBannerStyles_Gm6PMQtE as default };
