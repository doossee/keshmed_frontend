import { V as VBtnToggle } from './entry-styles-10.mjs-uEKJANcw.mjs';

const VBtnToggleStyles_9f5apenc = [VBtnToggle];

export { VBtnToggleStyles_9f5apenc as default };
