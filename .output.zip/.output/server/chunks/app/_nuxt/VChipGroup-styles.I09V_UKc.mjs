import { V as VChipGroup } from './entry-styles-26.mjs-UIZNb_ON.mjs';

const VChipGroupStyles_I09V_UKc = [VChipGroup];

export { VChipGroupStyles_I09V_UKc as default };
