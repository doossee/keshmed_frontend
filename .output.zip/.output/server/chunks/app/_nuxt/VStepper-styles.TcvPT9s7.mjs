import { V as VStepper } from './entry-styles-87.mjs-HMDX6RmG.mjs';

const VStepperStyles_TcvPT9s7 = [VStepper];

export { VStepperStyles_TcvPT9s7 as default };
