const VDatePicker = ".v-date-picker__input{padding-left:24px;padding-right:24px;padding-top:16px}.v-date-picker{overflow:hidden;width:360px}.v-date-picker--show-week{width:408px}.v-date-picker-month{padding:0 12px 12px}.v-date-picker-month__day{height:48px;width:48px}.v-date-picker-month__day .v-btn{--v-btn-height:28px;--v-btn-size:0.85rem}";

export { VDatePicker as V };
