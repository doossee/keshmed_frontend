const VVirtualScroll = ".v-virtual-scroll{display:block;flex:1 1 auto;max-width:100%;overflow:auto;position:relative}.v-virtual-scroll__container{display:block}";

export { VVirtualScroll as V };
