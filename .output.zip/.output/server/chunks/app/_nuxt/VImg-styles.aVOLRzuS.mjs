import { V as VImg } from './entry-styles-7.mjs-2IYhEcX-.mjs';

const VImgStyles_aVOLRzuS = [VImg];

export { VImgStyles_aVOLRzuS as default };
