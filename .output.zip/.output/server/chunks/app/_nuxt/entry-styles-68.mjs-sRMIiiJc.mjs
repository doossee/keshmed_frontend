const VDatePickerYears = ".v-date-picker-years{height:320px;overflow-y:scroll}.v-date-picker-years__content{display:grid;flex:1 1;gap:8px 24px;grid-template-columns:repeat(3,1fr);justify-content:space-around;padding-inline:36px}.v-date-picker-years__content .v-btn{padding-inline:8px}";

export { VDatePickerYears as V };
