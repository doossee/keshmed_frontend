const VDatePickerMonths = ".v-date-picker-months{height:320px;overflow-y:scroll}.v-date-picker-months__content{align-items:center;display:grid;flex:1 1;grid-template-columns:repeat(2,1fr);height:inherit;justify-content:space-around;grid-gap:4px 24px;padding-inline-end:36px;padding-inline-start:36px}.v-date-picker-months__content .v-btn{padding-inline-end:8px;padding-inline-start:8px;text-transform:none}";

export { VDatePickerMonths as V };
