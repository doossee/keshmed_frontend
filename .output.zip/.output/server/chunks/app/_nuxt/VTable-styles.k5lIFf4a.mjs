import { V as VTable } from './entry-styles-61.mjs-mDQXrA3B.mjs';

const VTableStyles_k5lIFf4a = [VTable];

export { VTableStyles_k5lIFf4a as default };
