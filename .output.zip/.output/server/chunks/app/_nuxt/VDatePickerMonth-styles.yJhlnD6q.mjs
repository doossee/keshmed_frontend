import { V as VDatePickerMonth } from './entry-styles-66.mjs-SeIx_ITo.mjs';

const VDatePickerMonthStyles_yJhlnD6q = [VDatePickerMonth];

export { VDatePickerMonthStyles_yJhlnD6q as default };
