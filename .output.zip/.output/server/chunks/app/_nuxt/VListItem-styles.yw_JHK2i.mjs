import { V as VListItem } from './entry-styles-29.mjs-fa4bMrxU.mjs';

const VListItemStyles_yw_JHK2i = [VListItem];

export { VListItemStyles_yw_JHK2i as default };
