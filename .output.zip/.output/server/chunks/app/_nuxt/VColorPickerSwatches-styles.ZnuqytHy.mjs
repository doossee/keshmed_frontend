import { V as VColorPickerSwatches } from './entry-styles-55.mjs-PXK5yb3X.mjs';

const VColorPickerSwatchesStyles_ZnuqytHy = [VColorPickerSwatches];

export { VColorPickerSwatchesStyles_ZnuqytHy as default };
