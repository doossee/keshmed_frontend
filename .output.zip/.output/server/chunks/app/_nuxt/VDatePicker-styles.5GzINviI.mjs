import { V as VDatePicker } from './entry-styles-62.mjs-UUMb2fBK.mjs';

const VDatePickerStyles_5GzINviI = [VDatePicker];

export { VDatePickerStyles_5GzINviI as default };
