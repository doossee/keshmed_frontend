const VRadioGroup = ".v-radio-group>.v-input__control{flex-direction:column}.v-radio-group>.v-input__control>.v-label{margin-inline-start:16px}.v-radio-group>.v-input__control>.v-label+.v-selection-control-group{margin-top:8px;padding-inline-start:6px}.v-radio-group .v-input__details{padding-inline:16px}";

export { VRadioGroup as V };
