import { V as VBottomSheet } from './entry-styles-41.mjs-1rDBlfLq.mjs';

const VBottomSheetStyles_6NxR__mx = [VBottomSheet];

export { VBottomSheetStyles_6NxR__mx as default };
