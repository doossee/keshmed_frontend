const VMain = ".v-main{flex:1 0 auto;max-width:100%;padding:var(--v-layout-top) var(--v-layout-right) var(--v-layout-bottom) var(--v-layout-left);transition:.2s cubic-bezier(.4,0,.2,1)}.v-main__scroller{max-width:100%;position:relative}.v-main--scrollable{display:flex;height:100%;left:0;position:absolute;top:0;width:100%}.v-main--scrollable>.v-main__scroller{flex:1 1 auto;overflow-y:auto;--v-layout-left:0px;--v-layout-right:0px;--v-layout-top:0px;--v-layout-bottom:0px}";

export { VMain as V };
