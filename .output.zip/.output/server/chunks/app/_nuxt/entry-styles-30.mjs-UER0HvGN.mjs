const VDivider = ".v-divider{border-style:solid;border-width:thin 0 0;display:block;flex:1 1 100%;height:0;max-height:0;opacity:var(--v-border-opacity);transition:inherit}.v-divider--vertical{align-self:stretch;border-width:0 thin 0 0;display:inline-flex;height:inherit;margin-left:-1px;max-height:100%;max-width:0;vertical-align:text-bottom;width:0}.v-divider--inset:not(.v-divider--vertical){margin-inline-start:72px;max-width:calc(100% - 72px)}.v-divider--inset.v-divider--vertical{margin-bottom:8px;margin-top:8px;max-height:calc(100% - 16px)}";

export { VDivider as V };
