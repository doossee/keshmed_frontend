import { V as VTextarea } from './entry-styles-93.mjs-hN_78fig.mjs';
import { V as VTextField } from './entry-styles-34.mjs-HDrDkiq5.mjs';

const VTextareaStyles_uYgDHzXR = [VTextarea, VTextField];

export { VTextareaStyles_uYgDHzXR as default };
