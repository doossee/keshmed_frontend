import { v as vuetify_min, m as materialdesignicons_min } from './entry-styles-97.mjs-4fu8sI7S.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'packrup';
import 'nitropack/dist/runtime/plugin';
import 'vue';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'devalue';
import 'vue/server-renderer';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';

const vuetifyStyles_C3eDtH_c = [vuetify_min, materialdesignicons_min];

export { vuetifyStyles_C3eDtH_c as default };
