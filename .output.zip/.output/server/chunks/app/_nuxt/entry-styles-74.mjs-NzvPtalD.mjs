const VItemGroup = ".v-item-group{flex:0 1 auto;max-width:100%;position:relative;transition:.2s cubic-bezier(.4,0,.2,1)}";

export { VItemGroup as V };
