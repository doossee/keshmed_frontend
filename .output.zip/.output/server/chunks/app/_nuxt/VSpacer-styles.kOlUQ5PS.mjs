import { V as VGrid } from './entry-styles-64.mjs-yakVxNHl.mjs';

const VSpacerStyles_kOlUQ5PS = [VGrid];

export { VSpacerStyles_kOlUQ5PS as default };
