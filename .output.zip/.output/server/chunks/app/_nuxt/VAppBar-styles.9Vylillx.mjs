import { V as VAppBar } from './entry-styles-5.mjs-IMMAeviQ.mjs';

const VAppBarStyles_9Vylillx = [VAppBar];

export { VAppBarStyles_9Vylillx as default };
