import { V as VCode } from './entry-styles-47.mjs-0hcdJOBZ.mjs';

const indexStyles_HK6N00M8 = [VCode];

export { indexStyles_HK6N00M8 as default };
