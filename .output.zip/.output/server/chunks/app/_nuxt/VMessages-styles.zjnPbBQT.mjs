import { V as VMessages } from './entry-styles-24.mjs-luHSuQ4p.mjs';

const VMessagesStyles_zjnPbBQT = [VMessages];

export { VMessagesStyles_zjnPbBQT as default };
