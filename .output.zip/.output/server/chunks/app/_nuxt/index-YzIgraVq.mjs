import { i as iconBase } from '../../icon-base.mjs';
import { i as AkWhatsappFill } from '../../index2.mjs';

const BsJournalText=props=>iconBase(props,`<svg width="16" height="16" fill="currentColor" class="bi bi-journal-text" viewBox="0 0 16 16"><path d="M5 10.5a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 0 1h-2a.5.5 0 0 1-.5-.5zm0-2a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm0-2a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm0-2a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5z"/><path d="M3 0h10a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2v-1h1v1a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H3a1 1 0 0 0-1 1v1H1V2a2 2 0 0 1 2-2z"/><path d="M1 5v-.5a.5.5 0 0 1 1 0V5h.5a.5.5 0 0 1 0 1h-2a.5.5 0 0 1 0-1H1zm0 3v-.5a.5.5 0 0 1 1 0V8h.5a.5.5 0 0 1 0 1h-2a.5.5 0 0 1 0-1H1zm0 3v-.5a.5.5 0 0 1 1 0v.5h.5a.5.5 0 0 1 0 1h-2a.5.5 0 0 1 0-1H1z"/></svg>`);
const BsTelephone=props=>iconBase(props,`<svg width="16" height="16" fill="currentColor" class="bi bi-telephone" viewBox="0 0 16 16"><path d="M3.654 1.328a.678.678 0 0 0-1.015-.063L1.605 2.3c-.483.484-.661 1.169-.45 1.77a17.568 17.568 0 0 0 4.168 6.608 17.569 17.569 0 0 0 6.608 4.168c.601.211 1.286.033 1.77-.45l1.034-1.034a.678.678 0 0 0-.063-1.015l-2.307-1.794a.678.678 0 0 0-.58-.122l-2.19.547a1.745 1.745 0 0 1-1.657-.459L5.482 8.062a1.745 1.745 0 0 1-.46-1.657l.548-2.19a.678.678 0 0 0-.122-.58L3.654 1.328zM1.884.511a1.745 1.745 0 0 1 2.612.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z"/></svg>`);

const BxInstagram=props=>iconBase(props,`<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M11.999 7.377a4.623 4.623 0 1 0 0 9.248 4.623 4.623 0 0 0 0-9.248zm0 7.627a3.004 3.004 0 1 1 0-6.008 3.004 3.004 0 0 1 0 6.008z"/><circle cx="16.806" cy="7.207" r="1.078"/><path d="M20.533 6.111A4.605 4.605 0 0 0 17.9 3.479a6.606 6.606 0 0 0-2.186-.42c-.963-.042-1.268-.054-3.71-.054s-2.755 0-3.71.054a6.554 6.554 0 0 0-2.184.42 4.6 4.6 0 0 0-2.633 2.632 6.585 6.585 0 0 0-.419 2.186c-.043.962-.056 1.267-.056 3.71 0 2.442 0 2.753.056 3.71.015.748.156 1.486.419 2.187a4.61 4.61 0 0 0 2.634 2.632 6.584 6.584 0 0 0 2.185.45c.963.042 1.268.055 3.71.055s2.755 0 3.71-.055a6.615 6.615 0 0 0 2.186-.419 4.613 4.613 0 0 0 2.633-2.633c.263-.7.404-1.438.419-2.186.043-.962.056-1.267.056-3.71s0-2.753-.056-3.71a6.581 6.581 0 0 0-.421-2.217zm-1.218 9.532a5.043 5.043 0 0 1-.311 1.688 2.987 2.987 0 0 1-1.712 1.711 4.985 4.985 0 0 1-1.67.311c-.95.044-1.218.055-3.654.055-2.438 0-2.687 0-3.655-.055a4.96 4.96 0 0 1-1.669-.311 2.985 2.985 0 0 1-1.719-1.711 5.08 5.08 0 0 1-.311-1.669c-.043-.95-.053-1.218-.053-3.654 0-2.437 0-2.686.053-3.655a5.038 5.038 0 0 1 .311-1.687c.305-.789.93-1.41 1.719-1.712a5.01 5.01 0 0 1 1.669-.311c.951-.043 1.218-.055 3.655-.055s2.687 0 3.654.055a4.96 4.96 0 0 1 1.67.311 2.991 2.991 0 0 1 1.712 1.712 5.08 5.08 0 0 1 .311 1.669c.043.951.054 1.218.054 3.655 0 2.436 0 2.698-.043 3.654h-.011z"/></svg>`);
const BxTelegram=props=>iconBase(props,`<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="m20.665 3.717-17.73 6.837c-1.21.486-1.203 1.161-.222 1.462l4.552 1.42 10.532-6.645c.498-.303.953-.14.579.192l-8.533 7.701h-.002l.002.001-.314 4.692c.46 0 .663-.211.921-.46l2.211-2.15 4.599 3.397c.848.467 1.457.227 1.668-.785l3.019-14.228c.309-1.239-.473-1.8-1.282-1.434z"/></svg>`);
const BxHomeAlt2=props=>iconBase(props,`<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12.71 2.29a1 1 0 0 0-1.42 0l-9 9a1 1 0 0 0 0 1.42A1 1 0 0 0 3 13h1v7a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7h1a1 1 0 0 0 1-1 1 1 0 0 0-.29-.71zM6 20v-9.59l6-6 6 6V20z"/></svg>`);
const BxSupport=props=>iconBase(props,`<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.486 2 2 6.486 2 12v4.143C2 17.167 2.897 18 4 18h1a1 1 0 0 0 1-1v-5.143a1 1 0 0 0-1-1h-.908C4.648 6.987 7.978 4 12 4s7.352 2.987 7.908 6.857H19a1 1 0 0 0-1 1V18c0 1.103-.897 2-2 2h-2v-1h-4v3h6c2.206 0 4-1.794 4-4 1.103 0 2-.833 2-1.857V12c0-5.514-4.486-10-10-10z"/></svg>`);

const CaCategory=props=>iconBase(props,`<svg width="32" height="32" viewBox="0 0 32 32" fill="currentColor"><path d="M27 22.141V18a2 2 0 0 0-2-2h-8v-4h2a2.002 2.002 0 0 0 2-2V4a2.002 2.002 0 0 0-2-2h-6a2.002 2.002 0 0 0-2 2v6a2.002 2.002 0 0 0 2 2h2v4H7a2 2 0 0 0-2 2v4.142a4 4 0 1 0 2 0V18h8v4.142a4 4 0 1 0 2 0V18h8v4.141a4 4 0 1 0 2 0ZM13 4h6l.001 6H13ZM8 26a2 2 0 1 1-2-2 2.002 2.002 0 0 1 2 2Zm10 0a2 2 0 1 1-2-2 2.003 2.003 0 0 1 2 2Zm8 2a2 2 0 1 1 2-2 2.002 2.002 0 0 1-2 2Z"/><path d="M0 0h32v32H0z" style="fill:none"/></svg>`);
const CaPhoneFilled=props=>iconBase(props,`<svg viewBox="0 0 32 32" fill="currentColor"><path d="m20.33 21.48 2.24-2.24a2.19 2.19 0 0 1 2.34-.48l2.73 1.09a2.18 2.18 0 0 1 1.36 2v5A2.17 2.17 0 0 1 26.72 29C7.59 27.81 3.73 11.61 3 5.41A2.17 2.17 0 0 1 5.17 3H10a2.16 2.16 0 0 1 2 1.36l1.09 2.73a2.16 2.16 0 0 1-.47 2.34l-2.24 2.24s1.29 8.73 9.95 9.81Z"/><path d="M0 0h32v32H0z" style="fill:none"/></svg>`);
const CaPhone=props=>iconBase(props,`<svg viewBox="0 0 32 32" fill="currentColor"><path d="M26 29h-.17C6.18 27.87 3.39 11.29 3 6.23A3 3 0 0 1 5.76 3h5.51a2 2 0 0 1 1.86 1.26L14.65 8a2 2 0 0 1-.44 2.16l-2.13 2.15a9.37 9.37 0 0 0 7.58 7.6l2.17-2.15a2 2 0 0 1 2.17-.41l3.77 1.51A2 2 0 0 1 29 20.72V26a3 3 0 0 1-3 3ZM6 5a1 1 0 0 0-1 1v.08C5.46 12 8.41 26 25.94 27a1 1 0 0 0 1.06-.94v-5.34l-3.77-1.51-2.87 2.85-.48-.06c-8.7-1.09-9.88-9.79-9.88-9.88l-.06-.48 2.84-2.87L11.28 5Z"/><path d="M0 0h32v32H0z" style="fill:none"/></svg>`);
const CaProduct=props=>iconBase(props,`<svg width="32" height="32" viewBox="0 0 32 32" fill="currentColor"><path d="M8 18h6v2H8zM8 22h10v2H8z"/><path d="M26 4H6a2.002 2.002 0 0 0-2 2v20a2.002 2.002 0 0 0 2 2h20a2.002 2.002 0 0 0 2-2V6a2.002 2.002 0 0 0-2-2Zm-8 2v4h-4V6ZM6 26V6h6v6h8V6h6l.001 20Z"/><path d="M0 0h32v32H0z" style="fill:none"/></svg>`);
const CaStarReview=props=>iconBase(props,`<svg width="32" height="32" viewBox="0 0 32 32" fill="currentColor"><path d="M18 26h8v2h-8zM18 22h12v2H18zM18 18h12v2H18z"/><path d="M20.549 11.217 16 2l-4.549 9.217L1.28 12.695l7.36 7.175L6.902 30 14 26.269v-2.26l-4.441 2.335 1.052-6.136.178-1.037-.753-.733-4.458-4.347 6.161-.895 1.04-.151.466-.943L16 6.519l2.755 5.583.466.943 1.04.151 7.454 1.085L28 12.3l-7.451-1.083z"/><path d="M0 0h32v32H0z" style="fill:none"/></svg>`);

const CoBrandGmail=props=>iconBase(props,`<svg width="32" height="32" viewBox="0 0 32 32" fill="currentColor"><path d="M32 6v20c0 1.135-.865 2-2 2h-2V9.849l-12 8.62-12-8.62V28H2c-1.135 0-2-.865-2-2V6c0-.568.214-1.068.573-1.422A1.973 1.973 0 0 1 2 4h.667L16 13.667 29.333 4H30c.568 0 1.068.214 1.427.578.359.354.573.854.573 1.422z"/></svg>`);
const CoBrandTelegramPlane=props=>iconBase(props,`<svg width="32" height="32" viewBox="0 0 32 32" fill="currentColor"><path d="m29.919 6.163-4.225 19.925c-.319 1.406-1.15 1.756-2.331 1.094l-6.438-4.744-3.106 2.988c-.344.344-.631.631-1.294.631l.463-6.556L24.919 8.72c.519-.462-.113-.719-.806-.256l-14.75 9.288-6.35-1.988c-1.381-.431-1.406-1.381.288-2.044l24.837-9.569c1.15-.431 2.156.256 1.781 2.013z"/></svg>`);

const FaBasketShopping=props=>iconBase(props,`<svg viewBox="0 0 576 512" fill="currentColor"><!--! Font Awesome Free 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2023 Fonticons, Inc.--><path d="M253.3 35.1c6.1-11.8 1.5-26.3-10.2-32.4s-26.3-1.5-32.4 10.2L117.6 192H32c-17.7 0-32 14.3-32 32s14.3 32 32 32l51.9 207.5C91 492 116.6 512 146 512h284c29.4 0 55-20 62.1-48.5L544 256c17.7 0 32-14.3 32-32s-14.3-32-32-32h-85.6L365.3 12.9c-6.1-11.7-20.6-16.3-32.4-10.2s-16.3 20.6-10.2 32.4L404.3 192H171.7l81.6-156.9zM192 304v96c0 8.8-7.2 16-16 16s-16-7.2-16-16v-96c0-8.8 7.2-16 16-16s16 7.2 16 16zm96-16c8.8 0 16 7.2 16 16v96c0 8.8-7.2 16-16 16s-16-7.2-16-16v-96c0-8.8 7.2-16 16-16zm128 16v96c0 8.8-7.2 16-16 16s-16-7.2-16-16v-96c0-8.8 7.2-16 16-16s16 7.2 16 16z"/></svg>`);
const FaScrewdriverWrench=props=>iconBase(props,`<svg viewBox="0 0 512 512" fill="currentColor"><!--! Font Awesome Free 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2023 Fonticons, Inc.--><path d="M78.6 5c-9.5-7.4-23-6.5-31.6 2L7 47c-8.5 8.5-9.4 22-2.1 31.6l80 104c4.5 5.9 11.6 9.4 19 9.4H158l109 109c-14.7 29-10 65.4 14.3 89.6l112 112c12.5 12.5 32.8 12.5 45.3 0l64-64c12.5-12.5 12.5-32.8 0-45.3l-112-112c-24.2-24.2-60.6-29-89.6-14.3L192 158v-54c0-7.5-3.5-14.5-9.4-19L78.6 5zM19.9 396.1C7.2 408.8 0 426.1 0 444.1 0 481.6 30.4 512 67.9 512c18 0 35.3-7.2 48-19.9l117.8-117.8c-7.8-20.9-9-43.6-3.6-65.1l-61.7-61.7L19.9 396.1zM512 144c0-10.5-1.1-20.7-3.2-30.5-2.4-11.2-16.1-14.1-24.2-6l-63.9 63.9c-3 3-7.1 4.7-11.3 4.7H352c-8.8 0-16-7.2-16-16v-57.5c0-4.2 1.7-8.3 4.7-11.3l63.9-63.9c8.1-8.1 5.2-21.8-6-24.2C388.7 1.1 378.5 0 368 0c-79.5 0-144 64.5-144 144v.8l85.3 85.3c36-9.1 75.8.5 104 28.7l15.7 15.7c49-23 83-72.8 83-130.5zM56 432a24 24 0 1 1 48 0 24 24 0 1 1-48 0z"/></svg>`);
const FaTruckRampBox=props=>iconBase(props,`<svg viewBox="0 0 640 512" fill="currentColor"><!--! Font Awesome Free 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2023 Fonticons, Inc.--><path d="M640 0v400c0 61.9-50.1 112-112 112-61 0-110.5-48.7-112-109.3L48.4 502.9c-17.1 4.6-34.6-5.4-39.3-22.5s5.4-34.6 22.5-39.3L352 353.8V64c0-35.3 28.7-64 64-64h224zm-64 400a48 48 0 1 0-96 0 48 48 0 1 0 96 0zM23.1 207.7c-4.6-17.1 5.6-34.6 22.6-39.2l46.4-12.4 20.7 77.3c2.3 8.5 11.1 13.6 19.6 11.3l30.9-8.3c8.5-2.3 13.6-11.1 11.3-19.6l-20.7-77.3 46.4-12.4c17.1-4.6 34.6 5.6 39.2 22.6l41.4 154.5c4.6 17.1-5.6 34.6-22.6 39.2l-154.6 41.5c-17.1 4.6-34.6-5.6-39.2-22.6L23.1 207.7z"/></svg>`);

const IoOutlineLogOut=props=>iconBase(props,`<svg width="512" height="512" viewBox="0 0 512 512" fill="currentColor"><path d="M304 336v40a40 40 0 0 1-40 40H104a40 40 0 0 1-40-40V136a40 40 0 0 1 40-40h152c22.09 0 48 17.91 48 40v40M368 336l80-80-80-80M176 256h256" style="fill:none;stroke:#000;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px"/></svg>`);
const IoHammer=props=>iconBase(props,`<svg width="512" height="512" viewBox="0 0 512 512" fill="currentColor"><path d="m280.16 242.79-26.11-26.12a32 32 0 0 0-45.14-.12L27.38 384.08c-6.61 6.23-10.95 14.17-11.35 23.06a32.11 32.11 0 0 0 9.21 23.94l39 39.43a.46.46 0 0 0 .07.07A32.29 32.29 0 0 0 87 480h1.18c8.89-.33 16.85-4.5 23.17-11.17l168.7-180.7a32 32 0 0 0 .11-45.34ZM490 190l-.31-.31-34.27-33.92a21.46 21.46 0 0 0-15.28-6.26 21.89 21.89 0 0 0-12.79 4.14c0-.43.06-.85.09-1.22.45-6.5 1.15-16.32-5.2-25.22a258 258 0 0 0-24.8-28.74.6.6 0 0 0-.08-.08c-13.32-13.12-42.31-37.83-86.72-55.94A139.55 139.55 0 0 0 257.56 32C226 32 202 46.24 192.81 54.68a119.92 119.92 0 0 0-14.18 16.22 16 16 0 0 0 18.65 24.34 74.45 74.45 0 0 1 8.58-2.63 63.46 63.46 0 0 1 18.45-1.15c13.19 1.09 28.79 7.64 35.69 13.09 11.7 9.41 17.33 22.09 18.26 41.09.18 3.82-7.72 18.14-20 34.48a16 16 0 0 0 1.45 21l34.41 34.41a16 16 0 0 0 22 .62c9.73-8.69 24.55-21.79 29.73-25 7.69-4.73 13.19-5.64 14.7-5.8a19.18 19.18 0 0 1 11.29 2.38 1.24 1.24 0 0 1-.31.95l-1.82 1.73-.3.28a21.52 21.52 0 0 0 .05 30.54l34.26 33.91a21.45 21.45 0 0 0 15.28 6.25 21.7 21.7 0 0 0 15.22-6.2l55.5-54.82c.19-.19.38-.39.56-.59A21.87 21.87 0 0 0 490 190Z"/></svg>`);

const navigation_links = [
  { lang: true, title: "links.home", url: "/", icon: BxHomeAlt2 },
  { lang: true, title: "links.products", url: "/products", icon: FaBasketShopping }
  // { title: 'links.brands', url: '/brands', icon: 'mdi' },
  // { title: 'links.saved', url: '/saved', icon: 'mdi' },
];
const conditions = [
  { title_uz: "Yangi", title_en: "New", title_ru: "\u041D\u043E\u0432\u044B\u0439", value: "new" },
  { title_uz: "Qutisi ochilgan", title_en: "Openbox", title_ru: "\u041E\u0442\u043A\u0440\u044B\u0442\u0430\u044F \u043A\u043E\u0440\u043E\u0431\u043A\u0430", value: "openbox" },
  { title_uz: "Ta'mirlangan", title_en: "Refurbished", title_ru: "\u041E\u0442\u0440\u0435\u043C\u043E\u043D\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0439", value: "refurbished" },
  { title_uz: "Ishlatilgan", title_en: "Used", title_ru: "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043B", value: "used" }
];
const social_links = [
  { title: "@Kesh_Med", url: "https://t.me/Kesh_Med", icon: BxTelegram },
  { title: "@keshmed37", url: "https://www.instagram.com/keshmed37", icon: BxInstagram },
  { title: "+998 (90) 889 37 00", url: "tel:+998908893700", icon: AkWhatsappFill }
];
const contact_links = [
  { url: "tel:+998908893700", title: "+998 (90) 889 37 00", icon: CaPhone },
  { url: "mailto:keshmed37@gmail.com", title: "keshmed37@gmail.com", icon: CoBrandGmail }
  // { title: '+998 90 123 45 67', icon: '' },
];
const index_card_items = [
  { icon: FaTruckRampBox, title: "home.card_1_title", description: "home.card_1_desc" },
  { icon: IoHammer, title: "home.card_2_title", description: "home.card_2_desc" },
  { icon: FaScrewdriverWrench, title: "home.card_3_title", description: "home.card_3_desc" },
  { icon: BxSupport, title: "home.card_4_title", description: "home.card_4_desc" }
];
const faqs = [
  {
    question: {
      en: "What are the main characteristics of your medical equipment?",
      uz: "Tibbiy jihozlaringizning asosiy xususiyatlari qanday?",
      ru: "\u041A\u0430\u043A\u043E\u0432\u044B \u043E\u0441\u043D\u043E\u0432\u043D\u044B\u0435 \u0445\u0430\u0440\u0430\u043A\u0442\u0435\u0440\u0438\u0441\u0442\u0438\u043A\u0438 \u0432\u0430\u0448\u0435\u0433\u043E \u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0441\u043A\u043E\u0433\u043E \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u044F?"
    },
    answer: {
      en: "Answer: We provide high quality medical equipment that meets all modern standards of safety and effectiveness. Our products provide reliable and precise performance for better patient care.",
      uz: "Javob: Biz xavfsizlik va samaradorlikning barcha zamonaviy standartlariga javob beradigan yuqori sifatli tibbiy asbob-uskunalar bilan ta'minlaymiz. Mahsulotlarimiz bemorni yaxshiroq parvarish qilish uchun ishonchli va aniq ishlashni ta'minlaydi.",
      ru: "\u041E\u0442\u0432\u0435\u0442: \u041C\u044B \u043F\u0440\u0435\u0434\u043E\u0441\u0442\u0430\u0432\u043B\u044F\u0435\u043C \u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0441\u043A\u043E\u0435 \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0432\u044B\u0441\u043E\u043A\u043E\u0433\u043E \u043A\u0430\u0447\u0435\u0441\u0442\u0432\u0430, \u043A\u043E\u0442\u043E\u0440\u043E\u0435 \u043E\u0442\u0432\u0435\u0447\u0430\u0435\u0442 \u0432\u0441\u0435\u043C \u0441\u043E\u0432\u0440\u0435\u043C\u0435\u043D\u043D\u044B\u043C \u0441\u0442\u0430\u043D\u0434\u0430\u0440\u0442\u0430\u043C \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0441\u0442\u0438 \u0438 \u044D\u0444\u0444\u0435\u043A\u0442\u0438\u0432\u043D\u043E\u0441\u0442\u0438. \u041D\u0430\u0448\u0438 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u044B \u043E\u0431\u0435\u0441\u043F\u0435\u0447\u0438\u0432\u0430\u044E\u0442 \u043D\u0430\u0434\u0435\u0436\u043D\u043E\u0435 \u0438 \u0442\u043E\u0447\u043D\u043E\u0435 \u0444\u0443\u043D\u043A\u0446\u0438\u043E\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u0434\u043B\u044F \u043B\u0443\u0447\u0448\u0435\u0433\u043E \u0443\u0445\u043E\u0434\u0430 \u043E \u043F\u0430\u0446\u0438\u0435\u043D\u0442\u0430\u0445."
    }
  },
  {
    question: {
      en: "What are the warranty terms for your equipment?",
      uz: "Sizning uskunangiz uchun kafolat shartlari qanday?",
      ru: "\u041A\u0430\u043A\u043E\u0432\u044B \u0443\u0441\u043B\u043E\u0432\u0438\u044F \u0433\u0430\u0440\u0430\u043D\u0442\u0438\u0438 \u043D\u0430 \u0432\u0430\u0448\u0435 \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435?"
    },
    answer: {
      en: "Answer: We provide a warranty on all our products. Please contact us for details about warranty periods and service conditions.",
      uz: "Javob: Biz barcha mahsulotlarimizga kafolat beramiz. Kafolat muddati va xizmat ko'rsatish shartlari haqida batafsil ma'lumot olish uchun biz bilan bog'laning.",
      ru: "\u041E\u0442\u0432\u0435\u0442: \u041C\u044B \u043F\u0440\u0435\u0434\u043E\u0441\u0442\u0430\u0432\u043B\u044F\u0435\u043C \u0433\u0430\u0440\u0430\u043D\u0442\u0438\u044E \u043D\u0430 \u0432\u0441\u0435 \u043D\u0430\u0448\u0438 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u044B. \u041F\u043E\u0436\u0430\u043B\u0443\u0439\u0441\u0442\u0430, \u0441\u0432\u044F\u0436\u0438\u0442\u0435\u0441\u044C \u0441 \u043D\u0430\u043C\u0438, \u0447\u0442\u043E\u0431\u044B \u0443\u0437\u043D\u0430\u0442\u044C \u043F\u043E\u0434\u0440\u043E\u0431\u043D\u043E\u0441\u0442\u0438 \u043E \u0441\u0440\u043E\u043A\u0430\u0445 \u0433\u0430\u0440\u0430\u043D\u0442\u0438\u0438 \u0438 \u0443\u0441\u043B\u043E\u0432\u0438\u044F\u0445 \u043E\u0431\u0441\u043B\u0443\u0436\u0438\u0432\u0430\u043D\u0438\u044F."
    }
  },
  {
    question: {
      en: "What services do you provide after the sale?",
      uz: "Sotishdan keyin qanday xizmatlarni taqdim qilasiz?",
      ru: "\u041A\u0430\u043A\u0438\u0435 \u0443\u0441\u043B\u0443\u0433\u0438 \u043F\u0440\u0435\u0434\u043E\u0441\u0442\u0430\u0432\u043B\u044F\u0435\u0442\u0435 \u043F\u043E\u0441\u043B\u0435 \u043F\u0440\u043E\u0434\u0430\u0436\u0438?"
    },
    answer: {
      en: "Answer: We provide full after sales support, including training, technical support, service and spare parts.",
      uz: "Javob: Biz savdodan keyingi to'liq yordamni, jumladan, o'qitish, texnik yordam, xizmat ko'rsatish va ehtiyot qismlarni taqdim etamiz.",
      ru: "\u041E\u0442\u0432\u0435\u0442: \u041C\u044B \u043E\u0431\u0435\u0441\u043F\u0435\u0447\u0438\u0432\u0430\u0435\u043C \u043F\u043E\u043B\u043D\u0443\u044E \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0443 \u043F\u043E\u0441\u043B\u0435 \u043F\u0440\u043E\u0434\u0430\u0436\u0438, \u0432\u043A\u043B\u044E\u0447\u0430\u044F \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u0430, \u0442\u0435\u0445\u043D\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0443, \u0441\u0435\u0440\u0432\u0438\u0441\u043D\u043E\u0435 \u043E\u0431\u0441\u043B\u0443\u0436\u0438\u0432\u0430\u043D\u0438\u0435 \u0438 \u0437\u0430\u043F\u0430\u0441\u043D\u044B\u0435 \u0447\u0430\u0441\u0442\u0438."
    }
  },
  {
    question: {
      en: "What are the payment methods for your equipment?",
      uz: "Sizning uskunangiz uchun qanday to'lov usullari mavjud?",
      ru: "\u041A\u0430\u043A\u043E\u0432\u044B \u0441\u043F\u043E\u0441\u043E\u0431\u044B \u043E\u043F\u043B\u0430\u0442\u044B \u0437\u0430 \u0432\u0430\u0448\u0435 \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435?"
    },
    answer: {
      en: "Answer: We accept a variety of payment methods, including bank transfers, credit cards and other electronic payment methods. Please contact us to discuss details.",
      uz: "Javob: Biz turli xil to'lov usullarini, jumladan, bank o'tkazmalarini, kredit kartalarini va boshqa elektron to'lov usullarini qabul qilamiz. Tafsilotlarni muhokama qilish uchun biz bilan bog'laning.",
      ru: "\u041E\u0442\u0432\u0435\u0442: \u041C\u044B \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0435\u043C \u0440\u0430\u0437\u043B\u0438\u0447\u043D\u044B\u0435 \u0441\u043F\u043E\u0441\u043E\u0431\u044B \u043E\u043F\u043B\u0430\u0442\u044B, \u0432\u043A\u043B\u044E\u0447\u0430\u044F \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0435 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u044B, \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u044B\u0435 \u043A\u0430\u0440\u0442\u044B \u0438 \u0434\u0440\u0443\u0433\u0438\u0435 \u044D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u044B\u0435 \u043C\u0435\u0442\u043E\u0434\u044B \u043E\u043F\u043B\u0430\u0442\u044B. \u041F\u043E\u0436\u0430\u043B\u0443\u0439\u0441\u0442\u0430, \u0441\u0432\u044F\u0436\u0438\u0442\u0435\u0441\u044C \u0441 \u043D\u0430\u043C\u0438, \u0447\u0442\u043E\u0431\u044B \u043E\u0431\u0441\u0443\u0434\u0438\u0442\u044C \u043F\u043E\u0434\u0440\u043E\u0431\u043D\u043E\u0441\u0442\u0438."
    }
  },
  {
    question: {
      en: "Can you provide samples of your equipment for testing?",
      uz: "Sinov uchun uskunangiz namunalarini bera olasizmi?",
      ru: "\u041C\u043E\u0436\u0435\u0442\u0435 \u043B\u0438 \u0432\u044B \u043F\u0440\u0435\u0434\u043E\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043E\u0431\u0440\u0430\u0437\u0446\u044B \u0432\u0430\u0448\u0435\u0433\u043E \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u044F \u0434\u043B\u044F \u0442\u0435\u0441\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F?"
    },
    answer: {
      en: "Answer: Yes, we can provide samples of our equipment for testing before purchase. Please contact us to arrange testing.",
      uz: "Javob: Ha, biz sotib olishdan oldin sinov uchun uskunamiz namunalarini taqdim eta olamiz. Iltimos, testni tashkil qilish uchun biz bilan bog'laning.",
      ru: "\u041E\u0442\u0432\u0435\u0442: \u0414\u0430, \u043C\u044B \u043C\u043E\u0436\u0435\u043C \u043F\u0440\u0435\u0434\u043E\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043E\u0431\u0440\u0430\u0437\u0446\u044B \u043D\u0430\u0448\u0435\u0433\u043E \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u044F \u0434\u043B\u044F \u0442\u0435\u0441\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u043F\u0435\u0440\u0435\u0434 \u043F\u043E\u043A\u0443\u043F\u043A\u043E\u0439. \u041F\u043E\u0436\u0430\u043B\u0443\u0439\u0441\u0442\u0430, \u0441\u0432\u044F\u0436\u0438\u0442\u0435\u0441\u044C \u0441 \u043D\u0430\u043C\u0438, \u0447\u0442\u043E\u0431\u044B \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u043E\u0432\u0430\u0442\u044C \u0442\u0435\u0441\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435."
    }
  },
  {
    question: {
      en: "What are the delivery times and delivery conditions?",
      uz: "Yetkazib berish muddatlari va etkazib berish shartlari qanday?",
      ru: "\u041A\u0430\u043A\u043E\u0432\u044B \u0441\u0440\u043E\u043A\u0438 \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0438 \u0438 \u0443\u0441\u043B\u043E\u0432\u0438\u044F \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0438?"
    },
    answer: {
      en: "Answer: We are committed to providing fast and reliable delivery of our products. Delivery times and conditions vary depending on specific orders and customer location. Please contact our logistics department for details.",
      uz: "Javob: Biz mahsulotlarimizni tez va ishonchli yetkazib berishni ta'minlashga intilamiz. Yetkazib berish muddati va shartlari ma'lum buyurtmalar va mijozning joylashuviga qarab farq qiladi. Tafsilotlar uchun logistika bo'limimizga murojaat qiling.",
      ru: "\u041E\u0442\u0432\u0435\u0442: \u041C\u044B \u0441\u0442\u0440\u0435\u043C\u0438\u043C\u0441\u044F \u043E\u0431\u0435\u0441\u043F\u0435\u0447\u0438\u0442\u044C \u0431\u044B\u0441\u0442\u0440\u0443\u044E \u0438 \u043D\u0430\u0434\u0435\u0436\u043D\u0443\u044E \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0443 \u043D\u0430\u0448\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432. \u0421\u0440\u043E\u043A\u0438 \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0438 \u0438 \u0443\u0441\u043B\u043E\u0432\u0438\u044F \u0437\u0430\u0432\u0438\u0441\u044F\u0442 \u043E\u0442 \u043A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u044B\u0445 \u0437\u0430\u043A\u0430\u0437\u043E\u0432 \u0438 \u043C\u0435\u0441\u0442\u043E\u043F\u043E\u043B\u043E\u0436\u0435\u043D\u0438\u044F \u043A\u043B\u0438\u0435\u043D\u0442\u0430. \u041F\u043E\u0436\u0430\u043B\u0443\u0439\u0441\u0442\u0430, \u043E\u0431\u0440\u0430\u0442\u0438\u0442\u0435\u0441\u044C \u043A \u043D\u0430\u0448\u0435\u043C\u0443 \u043E\u0442\u0434\u0435\u043B\u0443 \u043B\u043E\u0433\u0438\u0441\u0442\u0438\u043A\u0438 \u0434\u043B\u044F \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u0438\u044F \u043F\u043E\u0434\u0440\u043E\u0431\u043D\u043E\u0439 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438."
    }
  },
  {
    question: {
      en: "Can you provide setup and installation of your equipment?",
      uz: "Uskunangizni sozlash va o'rnatishni ta'minlay olasizmi?",
      ru: "\u041C\u043E\u0436\u0435\u0442\u0435 \u043B\u0438 \u0432\u044B \u043F\u0440\u0435\u0434\u043E\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0443 \u0438 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043A\u0443 \u0432\u0430\u0448\u0435\u0433\u043E \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u044F?"
    },
    answer: {
      en: "Answer: Yes, we provide configuration, installation and training services for personnel in using our equipment. This helps ensure that the products are used effectively and safely.",
      uz: "Javob: Ha, biz jihozlarimizdan foydalanishda xodimlar uchun konfiguratsiya, o'rnatish va o'qitish xizmatlarini taqdim etamiz. Bu mahsulotlardan samarali va xavfsiz foydalanishga yordam beradi.",
      ru: "\u041E\u0442\u0432\u0435\u0442: \u0414\u0430, \u043C\u044B \u043F\u0440\u0435\u0434\u043E\u0441\u0442\u0430\u0432\u043B\u044F\u0435\u043C \u0443\u0441\u043B\u0443\u0433\u0438 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438, \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043A\u0438 \u0438 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u0430 \u043F\u043E \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u0438\u044E \u043D\u0430\u0448\u0435\u0433\u043E \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u044F. \u042D\u0442\u043E \u043F\u043E\u043C\u043E\u0433\u0430\u0435\u0442 \u043E\u0431\u0435\u0441\u043F\u0435\u0447\u0438\u0442\u044C \u044D\u0444\u0444\u0435\u043A\u0442\u0438\u0432\u043D\u043E\u0435 \u0438 \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0435 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u0438\u0435 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432."
    }
  },
  {
    question: {
      en: "What to do if problems arise with the equipment?",
      uz: "Uskunada muammolar yuzaga kelsa nima qilish kerak?",
      ru: "\u0427\u0442\u043E \u0434\u0435\u043B\u0430\u0442\u044C \u0432 \u0441\u043B\u0443\u0447\u0430\u0435 \u0432\u043E\u0437\u043D\u0438\u043A\u043D\u043E\u0432\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0431\u043B\u0435\u043C \u0441 \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435\u043C?"
    },
    answer: {
      en: "Answer: If you have any problems with our equipment, please contact our technical support department immediately. We will be happy to help you solve any problems and ensure continued operation of your equipment.",
      uz: "Javob: Uskunalarimiz bilan bog'liq muammolar mavjud bo'lsa, darhol texnik yordam bo'limimizga murojaat qiling. Biz sizga har qanday muammolarni hal qilishda yordam berishdan va uskunangizning uzluksiz ishlashini ta'minlashdan mamnun bo'lamiz.",
      ru: "\u041E\u0442\u0432\u0435\u0442: \u0415\u0441\u043B\u0438 \u0443 \u0432\u0430\u0441 \u0432\u043E\u0437\u043D\u0438\u043A\u043B\u0438 \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u044B \u0441 \u043D\u0430\u0448\u0438\u043C \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435\u043C, \u043F\u043E\u0436\u0430\u043B\u0443\u0439\u0441\u0442\u0430, \u043D\u0435\u043C\u0435\u0434\u043B\u0435\u043D\u043D\u043E \u0441\u0432\u044F\u0436\u0438\u0442\u0435\u0441\u044C \u0441 \u043D\u0430\u0448\u0438\u043C \u043E\u0442\u0434\u0435\u043B\u043E\u043C \u0442\u0435\u0445\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0438. \u041C\u044B \u0441 \u0440\u0430\u0434\u043E\u0441\u0442\u044C\u044E \u043F\u043E\u043C\u043E\u0436\u0435\u043C \u0432\u0430\u043C \u0440\u0435\u0448\u0438\u0442\u044C \u043B\u044E\u0431\u044B\u0435 \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u044B \u0438 \u043E\u0431\u0435\u0441\u043F\u0435\u0447\u0438\u0442\u044C \u043D\u0435\u043F\u0440\u0435\u0440\u044B\u0432\u043D\u0443\u044E \u0440\u0430\u0431\u043E\u0442\u0443 \u0432\u0430\u0448\u0435\u0433\u043E \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u044F."
    }
  }
];
const admin_links = [
  { title: "admin.products", icon: CaProduct, url: "/admin" },
  { title: "products.categories", icon: CaCategory, url: "/admin/categories" },
  { title: "products.brands", icon: CaStarReview, url: "/admin/brands" },
  { title: "admin.orders", icon: BsJournalText, url: "/admin/orders" }
];
const languages = [
  { img: "/flag/us.svg", lang: "ru", title: "\u0420\u0443\u0441\u0441\u043A\u0438\u0439" },
  { img: "/flag/ru.svg", lang: "uz", title: "O'zbek" },
  { img: "/flag/uz.svg", lang: "en", title: "English" }
];
const countries = [
  {
    "id": 0,
    "flag": "/flag/af.svg",
    "name": "Afghanistan",
    "code": "AF"
  },
  {
    "id": 1,
    "flag": "/flag/ax.svg",
    "name": "\xC5land Islands",
    "code": "AX"
  },
  {
    "id": 2,
    "flag": "/flag/al.svg",
    "name": "Albania",
    "code": "AL"
  },
  {
    "id": 3,
    "flag": "/flag/dz.svg",
    "name": "Algeria",
    "code": "DZ"
  },
  {
    "id": 4,
    "flag": "/flag/as.svg",
    "name": "American Samoa",
    "code": "AS"
  },
  {
    "id": 5,
    "flag": "/flag/ad.svg",
    "name": "AndorrA",
    "code": "AD"
  },
  {
    "id": 6,
    "flag": "/flag/ao.svg",
    "name": "Angola",
    "code": "AO"
  },
  {
    "id": 7,
    "flag": "/flag/ai.svg",
    "name": "Anguilla",
    "code": "AI"
  },
  {
    "id": 8,
    "flag": "/flag/aq.svg",
    "name": "Antarctica",
    "code": "AQ"
  },
  {
    "id": 9,
    "flag": "/flag/ag.svg",
    "name": "Antigua and Barbuda",
    "code": "AG"
  },
  {
    "id": 10,
    "flag": "/flag/ar.svg",
    "name": "Argentina",
    "code": "AR"
  },
  {
    "id": 11,
    "flag": "/flag/am.svg",
    "name": "Armenia",
    "code": "AM"
  },
  {
    "id": 12,
    "flag": "/flag/aw.svg",
    "name": "Aruba",
    "code": "AW"
  },
  {
    "id": 13,
    "flag": "/flag/au.svg",
    "name": "Australia",
    "code": "AU"
  },
  {
    "id": 14,
    "flag": "/flag/at.svg",
    "name": "Austria",
    "code": "AT"
  },
  {
    "id": 15,
    "flag": "/flag/az.svg",
    "name": "Azerbaijan",
    "code": "AZ"
  },
  {
    "id": 16,
    "flag": "/flag/bs.svg",
    "name": "Bahamas",
    "code": "BS"
  },
  {
    "id": 17,
    "flag": "/flag/bh.svg",
    "name": "Bahrain",
    "code": "BH"
  },
  {
    "id": 18,
    "flag": "/flag/bd.svg",
    "name": "Bangladesh",
    "code": "BD"
  },
  {
    "id": 19,
    "flag": "/flag/bb.svg",
    "name": "Barbados",
    "code": "BB"
  },
  {
    "id": 20,
    "flag": "/flag/by.svg",
    "name": "Belarus",
    "code": "BY"
  },
  {
    "id": 21,
    "flag": "/flag/be.svg",
    "name": "Belgium",
    "code": "BE"
  },
  {
    "id": 22,
    "flag": "/flag/bz.svg",
    "name": "Belize",
    "code": "BZ"
  },
  {
    "id": 23,
    "flag": "/flag/bj.svg",
    "name": "Benin",
    "code": "BJ"
  },
  {
    "id": 24,
    "flag": "/flag/bm.svg",
    "name": "Bermuda",
    "code": "BM"
  },
  {
    "id": 25,
    "flag": "/flag/bt.svg",
    "name": "Bhutan",
    "code": "BT"
  },
  {
    "id": 26,
    "flag": "/flag/bo.svg",
    "name": "Bolivia",
    "code": "BO"
  },
  {
    "id": 27,
    "flag": "/flag/ba.svg",
    "name": "Bosnia and Herzegovina",
    "code": "BA"
  },
  {
    "id": 28,
    "flag": "/flag/bw.svg",
    "name": "Botswana",
    "code": "BW"
  },
  {
    "id": 29,
    "flag": "/flag/bv.svg",
    "name": "Bouvet Island",
    "code": "BV"
  },
  {
    "id": 30,
    "flag": "/flag/br.svg",
    "name": "Brazil",
    "code": "BR"
  },
  {
    "id": 31,
    "flag": "/flag/io.svg",
    "name": "British Indian Ocean Territory",
    "code": "IO"
  },
  {
    "id": 32,
    "flag": "/flag/bn.svg",
    "name": "Brunei Darussalam",
    "code": "BN"
  },
  {
    "id": 33,
    "flag": "/flag/bg.svg",
    "name": "Bulgaria",
    "code": "BG"
  },
  {
    "id": 34,
    "flag": "/flag/bf.svg",
    "name": "Burkina Faso",
    "code": "BF"
  },
  {
    "id": 35,
    "flag": "/flag/bi.svg",
    "name": "Burundi",
    "code": "BI"
  },
  {
    "id": 36,
    "flag": "/flag/kh.svg",
    "name": "Cambodia",
    "code": "KH"
  },
  {
    "id": 37,
    "flag": "/flag/cm.svg",
    "name": "Cameroon",
    "code": "CM"
  },
  {
    "id": 38,
    "flag": "/flag/ca.svg",
    "name": "Canada",
    "code": "CA"
  },
  {
    "id": 39,
    "flag": "/flag/cv.svg",
    "name": "Cape Verde",
    "code": "CV"
  },
  {
    "id": 40,
    "flag": "/flag/ky.svg",
    "name": "Cayman Islands",
    "code": "KY"
  },
  {
    "id": 41,
    "flag": "/flag/cf.svg",
    "name": "Central African Republic",
    "code": "CF"
  },
  {
    "id": 42,
    "flag": "/flag/td.svg",
    "name": "Chad",
    "code": "TD"
  },
  {
    "id": 43,
    "flag": "/flag/cl.svg",
    "name": "Chile",
    "code": "CL"
  },
  {
    "id": 44,
    "flag": "/flag/cn.svg",
    "name": "China",
    "code": "CN"
  },
  {
    "id": 45,
    "flag": "/flag/cx.svg",
    "name": "Christmas Island",
    "code": "CX"
  },
  {
    "id": 46,
    "flag": "/flag/cc.svg",
    "name": "Cocos (Keeling) Islands",
    "code": "CC"
  },
  {
    "id": 47,
    "flag": "/flag/co.svg",
    "name": "Colombia",
    "code": "CO"
  },
  {
    "id": 48,
    "flag": "/flag/km.svg",
    "name": "Comoros",
    "code": "KM"
  },
  {
    "id": 49,
    "flag": "/flag/cg.svg",
    "name": "Congo",
    "code": "CG"
  },
  {
    "id": 50,
    "flag": "/flag/cd.svg",
    "name": "Congo, The Democratic Republic of the",
    "code": "CD"
  },
  {
    "id": 51,
    "flag": "/flag/ck.svg",
    "name": "Cook Islands",
    "code": "CK"
  },
  {
    "id": 52,
    "flag": "/flag/cr.svg",
    "name": "Costa Rica",
    "code": "CR"
  },
  {
    "id": 53,
    "flag": "/flag/ci.svg",
    "name": "Cote D'Ivoire",
    "code": "CI"
  },
  {
    "id": 54,
    "flag": "/flag/hr.svg",
    "name": "Croatia",
    "code": "HR"
  },
  {
    "id": 55,
    "flag": "/flag/cu.svg",
    "name": "Cuba",
    "code": "CU"
  },
  {
    "id": 56,
    "flag": "/flag/cy.svg",
    "name": "Cyprus",
    "code": "CY"
  },
  {
    "id": 57,
    "flag": "/flag/cz.svg",
    "name": "Czech Republic",
    "code": "CZ"
  },
  {
    "id": 58,
    "flag": "/flag/dk.svg",
    "name": "Denmark",
    "code": "DK"
  },
  {
    "id": 59,
    "flag": "/flag/dj.svg",
    "name": "Djibouti",
    "code": "DJ"
  },
  {
    "id": 60,
    "flag": "/flag/dm.svg",
    "name": "Dominica",
    "code": "DM"
  },
  {
    "id": 61,
    "flag": "/flag/do.svg",
    "name": "Dominican Republic",
    "code": "DO"
  },
  {
    "id": 62,
    "flag": "/flag/ec.svg",
    "name": "Ecuador",
    "code": "EC"
  },
  {
    "id": 63,
    "flag": "/flag/eg.svg",
    "name": "Egypt",
    "code": "EG"
  },
  {
    "id": 64,
    "flag": "/flag/sv.svg",
    "name": "El Salvador",
    "code": "SV"
  },
  {
    "id": 65,
    "flag": "/flag/gq.svg",
    "name": "Equatorial Guinea",
    "code": "GQ"
  },
  {
    "id": 66,
    "flag": "/flag/er.svg",
    "name": "Eritrea",
    "code": "ER"
  },
  {
    "id": 67,
    "flag": "/flag/ee.svg",
    "name": "Estonia",
    "code": "EE"
  },
  {
    "id": 68,
    "flag": "/flag/et.svg",
    "name": "Ethiopia",
    "code": "ET"
  },
  {
    "id": 69,
    "flag": "/flag/fk.svg",
    "name": "Falkland Islands (Malvinas)",
    "code": "FK"
  },
  {
    "id": 70,
    "flag": "/flag/fo.svg",
    "name": "Faroe Islands",
    "code": "FO"
  },
  {
    "id": 71,
    "flag": "/flag/fj.svg",
    "name": "Fiji",
    "code": "FJ"
  },
  {
    "id": 72,
    "flag": "/flag/fi.svg",
    "name": "Finland",
    "code": "FI"
  },
  {
    "id": 73,
    "flag": "/flag/fr.svg",
    "name": "France",
    "code": "FR"
  },
  {
    "id": 74,
    "flag": "/flag/gf.svg",
    "name": "French Guiana",
    "code": "GF"
  },
  {
    "id": 75,
    "flag": "/flag/pf.svg",
    "name": "French Polynesia",
    "code": "PF"
  },
  {
    "id": 76,
    "flag": "/flag/tf.svg",
    "name": "French Southern Territories",
    "code": "TF"
  },
  {
    "id": 77,
    "flag": "/flag/ga.svg",
    "name": "Gabon",
    "code": "GA"
  },
  {
    "id": 78,
    "flag": "/flag/gm.svg",
    "name": "Gambia",
    "code": "GM"
  },
  {
    "id": 79,
    "flag": "/flag/ge.svg",
    "name": "Georgia",
    "code": "GE"
  },
  {
    "id": 80,
    "flag": "/flag/de.svg",
    "name": "Germany",
    "code": "DE"
  },
  {
    "id": 81,
    "flag": "/flag/gh.svg",
    "name": "Ghana",
    "code": "GH"
  },
  {
    "id": 82,
    "flag": "/flag/gi.svg",
    "name": "Gibraltar",
    "code": "GI"
  },
  {
    "id": 83,
    "flag": "/flag/gr.svg",
    "name": "Greece",
    "code": "GR"
  },
  {
    "id": 84,
    "flag": "/flag/gl.svg",
    "name": "Greenland",
    "code": "GL"
  },
  {
    "id": 85,
    "flag": "/flag/gd.svg",
    "name": "Grenada",
    "code": "GD"
  },
  {
    "id": 86,
    "flag": "/flag/gp.svg",
    "name": "Guadeloupe",
    "code": "GP"
  },
  {
    "id": 87,
    "flag": "/flag/gu.svg",
    "name": "Guam",
    "code": "GU"
  },
  {
    "id": 88,
    "flag": "/flag/gt.svg",
    "name": "Guatemala",
    "code": "GT"
  },
  {
    "id": 89,
    "flag": "/flag/gg.svg",
    "name": "Guernsey",
    "code": "GG"
  },
  {
    "id": 90,
    "flag": "/flag/gn.svg",
    "name": "Guinea",
    "code": "GN"
  },
  {
    "id": 91,
    "flag": "/flag/gw.svg",
    "name": "Guinea-Bissau",
    "code": "GW"
  },
  {
    "id": 92,
    "flag": "/flag/gy.svg",
    "name": "Guyana",
    "code": "GY"
  },
  {
    "id": 93,
    "flag": "/flag/ht.svg",
    "name": "Haiti",
    "code": "HT"
  },
  {
    "id": 94,
    "flag": "/flag/hm.svg",
    "name": "Heard Island and Mcdonald Islands",
    "code": "HM"
  },
  {
    "id": 95,
    "flag": "/flag/va.svg",
    "name": "Holy See (Vatican City State)",
    "code": "VA"
  },
  {
    "id": 96,
    "flag": "/flag/hn.svg",
    "name": "Honduras",
    "code": "HN"
  },
  {
    "id": 97,
    "flag": "/flag/hk.svg",
    "name": "Hong Kong",
    "code": "HK"
  },
  {
    "id": 98,
    "flag": "/flag/hu.svg",
    "name": "Hungary",
    "code": "HU"
  },
  {
    "id": 99,
    "flag": "/flag/is.svg",
    "name": "Iceland",
    "code": "IS"
  },
  {
    "id": 100,
    "flag": "/flag/in.svg",
    "name": "India",
    "code": "IN"
  },
  {
    "id": 101,
    "flag": "/flag/id.svg",
    "name": "Indonesia",
    "code": "ID"
  },
  {
    "id": 102,
    "flag": "/flag/ir.svg",
    "name": "Iran, Islamic Republic Of",
    "code": "IR"
  },
  {
    "id": 103,
    "flag": "/flag/iq.svg",
    "name": "Iraq",
    "code": "IQ"
  },
  {
    "id": 104,
    "flag": "/flag/ie.svg",
    "name": "Ireland",
    "code": "IE"
  },
  {
    "id": 105,
    "flag": "/flag/im.svg",
    "name": "Isle of Man",
    "code": "IM"
  },
  {
    "id": 106,
    "flag": "/flag/il.svg",
    "name": "Israel",
    "code": "IL"
  },
  {
    "id": 107,
    "flag": "/flag/it.svg",
    "name": "Italy",
    "code": "IT"
  },
  {
    "id": 108,
    "flag": "/flag/jm.svg",
    "name": "Jamaica",
    "code": "JM"
  },
  {
    "id": 109,
    "flag": "/flag/jp.svg",
    "name": "Japan",
    "code": "JP"
  },
  {
    "id": 110,
    "flag": "/flag/je.svg",
    "name": "Jersey",
    "code": "JE"
  },
  {
    "id": 111,
    "flag": "/flag/jo.svg",
    "name": "Jordan",
    "code": "JO"
  },
  {
    "id": 112,
    "flag": "/flag/kz.svg",
    "name": "Kazakhstan",
    "code": "KZ"
  },
  {
    "id": 113,
    "flag": "/flag/ke.svg",
    "name": "Kenya",
    "code": "KE"
  },
  {
    "id": 114,
    "flag": "/flag/ki.svg",
    "name": "Kiribati",
    "code": "KI"
  },
  {
    "id": 115,
    "flag": "/flag/kp.svg",
    "name": "Korea, Democratic People'S Republic of",
    "code": "KP"
  },
  {
    "id": 116,
    "flag": "/flag/kr.svg",
    "name": "Korea, Republic of",
    "code": "KR"
  },
  {
    "id": 117,
    "flag": "/flag/kw.svg",
    "name": "Kuwait",
    "code": "KW"
  },
  {
    "id": 118,
    "flag": "/flag/kg.svg",
    "name": "Kyrgyzstan",
    "code": "KG"
  },
  {
    "id": 119,
    "flag": "/flag/la.svg",
    "name": "Lao People'S Democratic Republic",
    "code": "LA"
  },
  {
    "id": 120,
    "flag": "/flag/lv.svg",
    "name": "Latvia",
    "code": "LV"
  },
  {
    "id": 121,
    "flag": "/flag/lb.svg",
    "name": "Lebanon",
    "code": "LB"
  },
  {
    "id": 122,
    "flag": "/flag/ls.svg",
    "name": "Lesotho",
    "code": "LS"
  },
  {
    "id": 123,
    "flag": "/flag/lr.svg",
    "name": "Liberia",
    "code": "LR"
  },
  {
    "id": 124,
    "flag": "/flag/ly.svg",
    "name": "Libyan Arab Jamahiriya",
    "code": "LY"
  },
  {
    "id": 125,
    "flag": "/flag/li.svg",
    "name": "Liechtenstein",
    "code": "LI"
  },
  {
    "id": 126,
    "flag": "/flag/lt.svg",
    "name": "Lithuania",
    "code": "LT"
  },
  {
    "id": 127,
    "flag": "/flag/lu.svg",
    "name": "Luxembourg",
    "code": "LU"
  },
  {
    "id": 128,
    "flag": "/flag/mo.svg",
    "name": "Macao",
    "code": "MO"
  },
  {
    "id": 129,
    "flag": "/flag/mk.svg",
    "name": "Macedonia, The Former Yugoslav Republic of",
    "code": "MK"
  },
  {
    "id": 130,
    "flag": "/flag/mg.svg",
    "name": "Madagascar",
    "code": "MG"
  },
  {
    "id": 131,
    "flag": "/flag/mw.svg",
    "name": "Malawi",
    "code": "MW"
  },
  {
    "id": 132,
    "flag": "/flag/my.svg",
    "name": "Malaysia",
    "code": "MY"
  },
  {
    "id": 133,
    "flag": "/flag/mv.svg",
    "name": "Maldives",
    "code": "MV"
  },
  {
    "id": 134,
    "flag": "/flag/ml.svg",
    "name": "Mali",
    "code": "ML"
  },
  {
    "id": 135,
    "flag": "/flag/mt.svg",
    "name": "Malta",
    "code": "MT"
  },
  {
    "id": 136,
    "flag": "/flag/mh.svg",
    "name": "Marshall Islands",
    "code": "MH"
  },
  {
    "id": 137,
    "flag": "/flag/mq.svg",
    "name": "Martinique",
    "code": "MQ"
  },
  {
    "id": 138,
    "flag": "/flag/mr.svg",
    "name": "Mauritania",
    "code": "MR"
  },
  {
    "id": 139,
    "flag": "/flag/mu.svg",
    "name": "Mauritius",
    "code": "MU"
  },
  {
    "id": 140,
    "flag": "/flag/yt.svg",
    "name": "Mayotte",
    "code": "YT"
  },
  {
    "id": 141,
    "flag": "/flag/mx.svg",
    "name": "Mexico",
    "code": "MX"
  },
  {
    "id": 142,
    "flag": "/flag/fm.svg",
    "name": "Micronesia, Federated States of",
    "code": "FM"
  },
  {
    "id": 143,
    "flag": "/flag/md.svg",
    "name": "Moldova, Republic of",
    "code": "MD"
  },
  {
    "id": 144,
    "flag": "/flag/mc.svg",
    "name": "Monaco",
    "code": "MC"
  },
  {
    "id": 145,
    "flag": "/flag/mn.svg",
    "name": "Mongolia",
    "code": "MN"
  },
  {
    "id": 146,
    "flag": "/flag/ms.svg",
    "name": "Montserrat",
    "code": "MS"
  },
  {
    "id": 147,
    "flag": "/flag/ma.svg",
    "name": "Morocco",
    "code": "MA"
  },
  {
    "id": 148,
    "flag": "/flag/mz.svg",
    "name": "Mozambique",
    "code": "MZ"
  },
  {
    "id": 149,
    "flag": "/flag/mm.svg",
    "name": "Myanmar",
    "code": "MM"
  },
  {
    "id": 150,
    "flag": "/flag/na.svg",
    "name": "Namibia",
    "code": "NA"
  },
  {
    "id": 151,
    "flag": "/flag/nr.svg",
    "name": "Nauru",
    "code": "NR"
  },
  {
    "id": 152,
    "flag": "/flag/np.svg",
    "name": "Nepal",
    "code": "NP"
  },
  {
    "id": 153,
    "flag": "/flag/nl.svg",
    "name": "Netherlands",
    "code": "NL"
  },
  {
    "id": 154,
    "flag": "/flag/nl.svg",
    "name": "Netherlands Antilles",
    "code": "AN"
  },
  {
    "id": 155,
    "flag": "/flag/nc.svg",
    "name": "New Caledonia",
    "code": "NC"
  },
  {
    "id": 156,
    "flag": "/flag/nz.svg",
    "name": "New Zealand",
    "code": "NZ"
  },
  {
    "id": 157,
    "flag": "/flag/ni.svg",
    "name": "Nicaragua",
    "code": "NI"
  },
  {
    "id": 158,
    "flag": "/flag/ne.svg",
    "name": "Niger",
    "code": "NE"
  },
  {
    "id": 159,
    "flag": "/flag/ng.svg",
    "name": "Nigeria",
    "code": "NG"
  },
  {
    "id": 160,
    "flag": "/flag/nu.svg",
    "name": "Niue",
    "code": "NU"
  },
  {
    "id": 161,
    "flag": "/flag/nf.svg",
    "name": "Norfolk Island",
    "code": "NF"
  },
  {
    "id": 162,
    "flag": "/flag/mp.svg",
    "name": "Northern Mariana Islands",
    "code": "MP"
  },
  {
    "id": 163,
    "flag": "/flag/no.svg",
    "name": "Norway",
    "code": "NO"
  },
  {
    "id": 164,
    "flag": "/flag/om.svg",
    "name": "Oman",
    "code": "OM"
  },
  {
    "id": 165,
    "flag": "/flag/pk.svg",
    "name": "Pakistan",
    "code": "PK"
  },
  {
    "id": 166,
    "flag": "/flag/pw.svg",
    "name": "Palau",
    "code": "PW"
  },
  {
    "id": 167,
    "flag": "/flag/ps.svg",
    "name": "Palestinian Territory, Occupied",
    "code": "PS"
  },
  {
    "id": 168,
    "flag": "/flag/pa.svg",
    "name": "Panama",
    "code": "PA"
  },
  {
    "id": 169,
    "flag": "/flag/pg.svg",
    "name": "Papua New Guinea",
    "code": "PG"
  },
  {
    "id": 170,
    "flag": "/flag/py.svg",
    "name": "Paraguay",
    "code": "PY"
  },
  {
    "id": 171,
    "flag": "/flag/pe.svg",
    "name": "Peru",
    "code": "PE"
  },
  {
    "id": 172,
    "flag": "/flag/ph.svg",
    "name": "Philippines",
    "code": "PH"
  },
  {
    "id": 173,
    "flag": "/flag/pn.svg",
    "name": "Pitcairn",
    "code": "PN"
  },
  {
    "id": 174,
    "flag": "/flag/pl.svg",
    "name": "Poland",
    "code": "PL"
  },
  {
    "id": 175,
    "flag": "/flag/pt.svg",
    "name": "Portugal",
    "code": "PT"
  },
  {
    "id": 176,
    "flag": "/flag/pr.svg",
    "name": "Puerto Rico",
    "code": "PR"
  },
  {
    "id": 177,
    "flag": "/flag/qa.svg",
    "name": "Qatar",
    "code": "QA"
  },
  {
    "id": 178,
    "flag": "/flag/re.svg",
    "name": "Reunion",
    "code": "RE"
  },
  {
    "id": 179,
    "flag": "/flag/ro.svg",
    "name": "Romania",
    "code": "RO"
  },
  {
    "id": 180,
    "flag": "/flag/ru.svg",
    "name": "Russian Federation",
    "code": "RU"
  },
  {
    "id": 181,
    "flag": "/flag/rw.svg",
    "name": "RWANDA",
    "code": "RW"
  },
  {
    "id": 182,
    "flag": "/flag/sh.svg",
    "name": "Saint Helena",
    "code": "SH"
  },
  {
    "id": 183,
    "flag": "/flag/kn.svg",
    "name": "Saint Kitts and Nevis",
    "code": "KN"
  },
  {
    "id": 184,
    "flag": "/flag/lc.svg",
    "name": "Saint Lucia",
    "code": "LC"
  },
  {
    "id": 185,
    "flag": "/flag/pm.svg",
    "name": "Saint Pierre and Miquelon",
    "code": "PM"
  },
  {
    "id": 186,
    "flag": "/flag/vc.svg",
    "name": "Saint Vincent and the Grenadines",
    "code": "VC"
  },
  {
    "id": 187,
    "flag": "/flag/ws.svg",
    "name": "Samoa",
    "code": "WS"
  },
  {
    "id": 188,
    "flag": "/flag/sm.svg",
    "name": "San Marino",
    "code": "SM"
  },
  {
    "id": 189,
    "flag": "/flag/st.svg",
    "name": "Sao Tome and Principe",
    "code": "ST"
  },
  {
    "id": 190,
    "flag": "/flag/sa.svg",
    "name": "Saudi Arabia",
    "code": "SA"
  },
  {
    "id": 191,
    "flag": "/flag/sn.svg",
    "name": "Senegal",
    "code": "SN"
  },
  {
    "id": 192,
    "flag": "/flag/cn.svg",
    "name": "Serbia and Montenegro",
    "code": "CS"
  },
  {
    "id": 193,
    "flag": "/flag/sc.svg",
    "name": "Seychelles",
    "code": "SC"
  },
  {
    "id": 194,
    "flag": "/flag/sl.svg",
    "name": "Sierra Leone",
    "code": "SL"
  },
  {
    "id": 195,
    "flag": "/flag/sg.svg",
    "name": "Singapore",
    "code": "SG"
  },
  {
    "id": 196,
    "flag": "/flag/sk.svg",
    "name": "Slovakia",
    "code": "SK"
  },
  {
    "id": 197,
    "flag": "/flag/si.svg",
    "name": "Slovenia",
    "code": "SI"
  },
  {
    "id": 198,
    "flag": "/flag/sb.svg",
    "name": "Solomon Islands",
    "code": "SB"
  },
  {
    "id": 199,
    "flag": "/flag/so.svg",
    "name": "Somalia",
    "code": "SO"
  },
  {
    "id": 200,
    "flag": "/flag/za.svg",
    "name": "South Africa",
    "code": "ZA"
  },
  {
    "id": 201,
    "flag": "/flag/gs.svg",
    "name": "South Georgia and the South Sandwich Islands",
    "code": "GS"
  },
  {
    "id": 202,
    "flag": "/flag/es.svg",
    "name": "Spain",
    "code": "ES"
  },
  {
    "id": 203,
    "flag": "/flag/lk.svg",
    "name": "Sri Lanka",
    "code": "LK"
  },
  {
    "id": 204,
    "flag": "/flag/sd.svg",
    "name": "Sudan",
    "code": "SD"
  },
  {
    "id": 205,
    "flag": "/flag/sr.svg",
    "name": "Suriname",
    "code": "SR"
  },
  {
    "id": 206,
    "flag": "/flag/sj.svg",
    "name": "Svalbard and Jan Mayen",
    "code": "SJ"
  },
  {
    "id": 207,
    "flag": "/flag/sz.svg",
    "name": "Swaziland",
    "code": "SZ"
  },
  {
    "id": 208,
    "flag": "/flag/se.svg",
    "name": "Sweden",
    "code": "SE"
  },
  {
    "id": 209,
    "flag": "/flag/ch.svg",
    "name": "Switzerland",
    "code": "CH"
  },
  {
    "id": 210,
    "flag": "/flag/sy.svg",
    "name": "Syrian Arab Republic",
    "code": "SY"
  },
  {
    "id": 211,
    "flag": "/flag/tw.svg",
    "name": "Taiwan, Province of China",
    "code": "TW"
  },
  {
    "id": 212,
    "flag": "/flag/tj.svg",
    "name": "Tajikistan",
    "code": "TJ"
  },
  {
    "id": 213,
    "flag": "/flag/tz.svg",
    "name": "Tanzania, United Republic of",
    "code": "TZ"
  },
  {
    "id": 214,
    "flag": "/flag/th.svg",
    "name": "Thailand",
    "code": "TH"
  },
  {
    "id": 215,
    "flag": "/flag/tl.svg",
    "name": "Timor-Leste",
    "code": "TL"
  },
  {
    "id": 216,
    "flag": "/flag/tg.svg",
    "name": "Togo",
    "code": "TG"
  },
  {
    "id": 217,
    "flag": "/flag/tk.svg",
    "name": "Tokelau",
    "code": "TK"
  },
  {
    "id": 218,
    "flag": "/flag/to.svg",
    "name": "Tonga",
    "code": "TO"
  },
  {
    "id": 219,
    "flag": "/flag/tt.svg",
    "name": "Trinidad and Tobago",
    "code": "TT"
  },
  {
    "id": 220,
    "flag": "/flag/tn.svg",
    "name": "Tunisia",
    "code": "TN"
  },
  {
    "id": 221,
    "flag": "/flag/tr.svg",
    "name": "Turkey",
    "code": "TR"
  },
  {
    "id": 222,
    "flag": "/flag/tm.svg",
    "name": "Turkmenistan",
    "code": "TM"
  },
  {
    "id": 223,
    "flag": "/flag/tc.svg",
    "name": "Turks and Caicos Islands",
    "code": "TC"
  },
  {
    "id": 224,
    "flag": "/flag/tv.svg",
    "name": "Tuvalu",
    "code": "TV"
  },
  {
    "id": 225,
    "flag": "/flag/ug.svg",
    "name": "Uganda",
    "code": "UG"
  },
  {
    "id": 226,
    "flag": "/flag/ua.svg",
    "name": "Ukraine",
    "code": "UA"
  },
  {
    "id": 227,
    "flag": "/flag/ae.svg",
    "name": "United Arab Emirates",
    "code": "AE"
  },
  {
    "id": 228,
    "flag": "/flag/gb.svg",
    "name": "United Kingdom",
    "code": "GB"
  },
  {
    "id": 229,
    "flag": "/flag/us.svg",
    "name": "United States",
    "code": "US"
  },
  {
    "id": 230,
    "flag": "/flag/um.svg",
    "name": "United States Minor Outlying Islands",
    "code": "UM"
  },
  {
    "id": 231,
    "flag": "/flag/uy.svg",
    "name": "Uruguay",
    "code": "UY"
  },
  {
    "id": 232,
    "flag": "/flag/uz.svg",
    "name": "Uzbekistan",
    "code": "UZ"
  },
  {
    "id": 233,
    "flag": "/flag/vu.svg",
    "name": "Vanuatu",
    "code": "VU"
  },
  {
    "id": 234,
    "flag": "/flag/ve.svg",
    "name": "Venezuela",
    "code": "VE"
  },
  {
    "id": 235,
    "flag": "/flag/vn.svg",
    "name": "Viet Nam",
    "code": "VN"
  },
  {
    "id": 236,
    "flag": "/flag/vg.svg",
    "name": "Virgin Islands, British",
    "code": "VG"
  },
  {
    "id": 237,
    "flag": "/flag/vi.svg",
    "name": "Virgin Islands, U.S.",
    "code": "VI"
  },
  {
    "id": 238,
    "flag": "/flag/wf.svg",
    "name": "Wallis and Futuna",
    "code": "WF"
  },
  {
    "id": 239,
    "flag": "/flag/eh.svg",
    "name": "Western Sahara",
    "code": "EH"
  },
  {
    "id": 240,
    "flag": "/flag/ye.svg",
    "name": "Yemen",
    "code": "YE"
  },
  {
    "id": 241,
    "flag": "/flag/zm.svg",
    "name": "Zambia",
    "code": "ZM"
  },
  {
    "id": 242,
    "flag": "/flag/zw.svg",
    "name": "Zimbabwe",
    "code": "ZW"
  }
];

export { BsTelephone as B, CoBrandTelegramPlane as C, IoOutlineLogOut as I, conditions as a, CaPhoneFilled as b, countries as c, admin_links as d, contact_links as e, faqs as f, index_card_items as i, languages as l, navigation_links as n, social_links as s };
