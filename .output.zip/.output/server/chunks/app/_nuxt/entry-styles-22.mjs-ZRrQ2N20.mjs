const VSelectionControlGroup = ".v-selection-control-group{display:flex;flex-direction:column;grid-area:control}.v-selection-control-group--inline{flex-direction:row;flex-wrap:wrap}";

export { VSelectionControlGroup as V };
