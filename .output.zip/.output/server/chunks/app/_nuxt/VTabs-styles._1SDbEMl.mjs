import { V as VTabs } from './entry-styles-91.mjs-oq6e0zzx.mjs';

const VTabsStyles__1SDbEMl = [VTabs];

export { VTabsStyles__1SDbEMl as default };
