import { V as VSelectionControl } from './entry-styles-20.mjs-qC3XvAJJ.mjs';

const VSelectionControlStyles_HXRf3Oyi = [VSelectionControl];

export { VSelectionControlStyles_HXRf3Oyi as default };
