import { V as VDatePickerHeader } from './entry-styles-65.mjs-gFsK50--.mjs';

const VDatePickerHeaderStyles_6JWk3h1 = [VDatePickerHeader];

export { VDatePickerHeaderStyles_6JWk3h1 as default };
