import { V as VCheckbox } from './entry-styles-19.mjs-7r1A2P8l.mjs';

const VCheckboxStyles_TRDerJqf = [VCheckbox];

export { VCheckboxStyles_TRDerJqf as default };
