import { V as VSelectionControlGroup } from './entry-styles-22.mjs-ZRrQ2N20.mjs';

const VSelectionControlGroupStyles_2CFgCLx3 = [VSelectionControlGroup];

export { VSelectionControlGroupStyles_2CFgCLx3 as default };
