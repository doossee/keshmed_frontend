import { V as VWindow } from './entry-styles-46.mjs-GARD7TnV.mjs';

const VWindowStyles_EosrgDwv = [VWindow];

export { VWindowStyles_EosrgDwv as default };
