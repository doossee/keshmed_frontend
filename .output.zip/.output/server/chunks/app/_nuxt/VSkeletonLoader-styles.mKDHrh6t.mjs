import { V as VSkeletonLoader } from './entry-styles-85.mjs-elQV1fFZ.mjs';

const VSkeletonLoaderStyles_mKDHrh6t = [VSkeletonLoader];

export { VSkeletonLoaderStyles_mKDHrh6t as default };
