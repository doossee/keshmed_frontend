import { V as VLocaleProvider } from './entry-styles-78.mjs-dRFzz_Yl.mjs';

const VLocaleProviderStyles_4RT9Rai_ = [VLocaleProvider];

export { VLocaleProviderStyles_4RT9Rai_ as default };
