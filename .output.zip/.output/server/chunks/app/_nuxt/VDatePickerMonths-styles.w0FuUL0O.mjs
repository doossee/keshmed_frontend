import { V as VDatePickerMonths } from './entry-styles-67.mjs-gb2-O8vd.mjs';

const VDatePickerMonthsStyles_w0FuUL0O = [VDatePickerMonths];

export { VDatePickerMonthsStyles_w0FuUL0O as default };
