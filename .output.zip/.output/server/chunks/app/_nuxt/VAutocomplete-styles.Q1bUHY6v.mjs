import { V as VAutocomplete } from './entry-styles-17.mjs-3jHOfgNU.mjs';

const VAutocompleteStyles_Q1bUHY6v = [VAutocomplete];

export { VAutocompleteStyles_Q1bUHY6v as default };
