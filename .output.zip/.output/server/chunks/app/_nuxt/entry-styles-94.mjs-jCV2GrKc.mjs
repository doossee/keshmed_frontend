const VThemeProvider = ".v-theme-provider{background:rgb(var(--v-theme-background));color:rgb(var(--v-theme-on-background))}";

export { VThemeProvider as V };
