import { V as VColorPickerCanvas } from './entry-styles-49.mjs-SIoEDD-Y.mjs';

const VColorPickerCanvasStyles_vLP1saUn = [VColorPickerCanvas];

export { VColorPickerCanvasStyles_vLP1saUn as default };
