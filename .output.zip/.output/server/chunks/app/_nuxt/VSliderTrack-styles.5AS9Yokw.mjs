import { V as VSliderTrack } from './entry-styles-54.mjs-KV4_YjNM.mjs';

const VSliderTrackStyles_5AS9Yokw = [VSliderTrack];

export { VSliderTrackStyles_5AS9Yokw as default };
