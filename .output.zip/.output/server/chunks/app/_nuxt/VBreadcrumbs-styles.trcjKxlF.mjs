import { V as VBreadcrumbs } from './entry-styles-43.mjs-lSl6Qxnh.mjs';

const VBreadcrumbsStyles_trcjKxlF = [VBreadcrumbs];

export { VBreadcrumbsStyles_trcjKxlF as default };
