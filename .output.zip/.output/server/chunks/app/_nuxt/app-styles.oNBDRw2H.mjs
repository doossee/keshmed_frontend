import { a as app_vue_vue_type_style_index_0_lang } from './entry-styles-98.mjs-oP2smgW5.mjs';

const appStyles_oNBDRw2H = [app_vue_vue_type_style_index_0_lang];

export { appStyles_oNBDRw2H as default };
