import { V as VSelect } from './entry-styles-33.mjs-lCkhEE9L.mjs';

const VSelectStyles_pHsMepf9 = [VSelect];

export { VSelectStyles_pHsMepf9 as default };
