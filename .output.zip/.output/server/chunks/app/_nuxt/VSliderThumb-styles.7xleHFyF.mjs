import { V as VSliderThumb } from './entry-styles-53.mjs-U3JNY0IE.mjs';

const VSliderThumbStyles_7xleHFyF = [VSliderThumb];

export { VSliderThumbStyles_7xleHFyF as default };
