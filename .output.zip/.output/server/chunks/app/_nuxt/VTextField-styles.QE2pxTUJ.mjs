import { V as VTextField } from './entry-styles-34.mjs-HDrDkiq5.mjs';

const VTextFieldStyles_QE2pxTUJ = [VTextField];

export { VTextFieldStyles_QE2pxTUJ as default };
