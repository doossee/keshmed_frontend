const VCheckbox = ".v-checkbox.v-input{flex:0 1 auto}.v-checkbox .v-selection-control{min-height:var(--v-input-control-height)}";

export { VCheckbox as V };
