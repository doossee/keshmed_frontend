import { V as VSnackbar } from './entry-styles-86.mjs-ojU2iV_e.mjs';

const VSnackbarStyles_Ms7mFv39 = [VSnackbar];

export { VSnackbarStyles_Ms7mFv39 as default };
