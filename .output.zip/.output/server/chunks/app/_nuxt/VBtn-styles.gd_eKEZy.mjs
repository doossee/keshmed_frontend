import { V as VBtn } from './entry-styles-9.mjs-gPxytHDV.mjs';

const VBtnStyles_gd_eKEZy = [VBtn];

export { VBtnStyles_gd_eKEZy as default };
