import { V as VInfiniteScroll } from './entry-styles-73.mjs-V2vss3fT.mjs';

const VInfiniteScrollStyles_4pGYW4ga = [VInfiniteScroll];

export { VInfiniteScrollStyles_4pGYW4ga as default };
