import { V as VBadge } from './entry-styles-38.mjs-BG39a8Cw.mjs';

const VBadgeStyles_bvgIA8Ti = [VBadge];

export { VBadgeStyles_bvgIA8Ti as default };
