import { V as VDatePickerControls } from './entry-styles-63.mjs-avyOoydr.mjs';

const VDatePickerControlsStyles_IntcGPt5 = [VDatePickerControls];

export { VDatePickerControlsStyles_IntcGPt5 as default };
