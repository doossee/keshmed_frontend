import { V as VSwitch } from './entry-styles-89.mjs-7HPx9qSV.mjs';

const VSwitchStyles_zPnxK1lG = [VSwitch];

export { VSwitchStyles_zPnxK1lG as default };
