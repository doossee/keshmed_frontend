const VColorPickerCanvas = ".v-color-picker-canvas{contain:content;display:flex;overflow:hidden;position:relative;touch-action:none}.v-color-picker-canvas__dot{background:transparent;border-radius:50%;box-shadow:0 0 0 1.5px #fff,inset 0 0 1px 1.5px rgba(0,0,0,.3);height:15px;left:0;position:absolute;top:0;width:15px}.v-color-picker-canvas__dot--disabled{box-shadow:0 0 0 1.5px hsla(0,0%,100%,.7),inset 0 0 1px 1.5px rgba(0,0,0,.3)}.v-color-picker-canvas:hover .v-color-picker-canvas__dot{will-change:transform}";

export { VColorPickerCanvas as V };
