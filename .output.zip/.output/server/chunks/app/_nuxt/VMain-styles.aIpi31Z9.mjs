import { V as VMain } from './entry-styles-79.mjs-xbt3I0nA.mjs';

const VMainStyles_aIpi31Z9 = [VMain];

export { VMainStyles_aIpi31Z9 as default };
