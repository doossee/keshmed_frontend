import { V as VCounter } from './entry-styles-35.mjs-ilYc2tCQ.mjs';

const VCounterStyles_pC388ifX = [VCounter];

export { VCounterStyles_pC388ifX as default };
