const VCode = ".v-code{background-color:rgb(var(--v-theme-code));border-radius:4px;color:rgb(var(--v-theme-on-code));font-size:.9em;font-weight:400;line-height:1.8;padding:.2em .4em}";

export { VCode as V };
