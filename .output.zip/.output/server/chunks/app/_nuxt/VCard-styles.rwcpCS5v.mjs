import { V as VCard } from './entry-styles-44.mjs-Z3Uw6IB6.mjs';

const VCardStyles_rwcpCS5v = [VCard];

export { VCardStyles_rwcpCS5v as default };
