import { V as VLayoutItem } from './entry-styles-77.mjs-U1XI2N20.mjs';

const VLayoutItemStyles_SuSRN3xK = [VLayoutItem];

export { VLayoutItemStyles_SuSRN3xK as default };
