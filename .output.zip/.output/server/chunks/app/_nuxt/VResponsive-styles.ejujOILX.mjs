import { V as VResponsive } from './entry-styles-8.mjs-ke6YaEiJ.mjs';

const VResponsiveStyles_ejujOILX = [VResponsive];

export { VResponsiveStyles_ejujOILX as default };
