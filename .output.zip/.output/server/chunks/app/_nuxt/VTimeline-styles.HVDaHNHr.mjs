import { V as VTimeline } from './entry-styles-95.mjs-xadgbAY6.mjs';

const VTimelineStyles_HVDaHNHr = [VTimeline];

export { VTimelineStyles_HVDaHNHr as default };
