const VTab = ".v-tab.v-tab.v-btn{border-radius:0;height:var(--v-tabs-height);min-width:90px}.v-slide-group--horizontal .v-tab{max-width:360px}.v-slide-group--vertical .v-tab{justify-content:start}.v-tab__slider{background:currentColor;bottom:0;height:2px;left:0;opacity:0;pointer-events:none;position:absolute;width:100%}.v-tab--selected .v-tab__slider{opacity:1}.v-slide-group--vertical .v-tab__slider{height:100%;top:0;width:2px}";

export { VTab as V };
