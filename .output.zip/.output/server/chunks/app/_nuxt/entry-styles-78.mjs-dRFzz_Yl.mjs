const VLocaleProvider = ".v-locale-provider{display:contents}";

export { VLocaleProvider as V };
