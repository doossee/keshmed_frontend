import { V as VOtpInput } from './entry-styles-81.mjs-S__Uw5a9.mjs';

const VOtpInputStyles_HTAjsHn3 = [VOtpInput];

export { VOtpInputStyles_HTAjsHn3 as default };
