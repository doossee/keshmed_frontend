import { V as VOverlay } from './entry-styles-32.mjs-0oQI_mC4.mjs';

const VOverlayStyles_em7d2Ngs = [VOverlay];

export { VOverlayStyles_em7d2Ngs as default };
