import { V as VProgressCircular } from './entry-styles-13.mjs-oU1eOA6W.mjs';

const VProgressCircularStyles_MBQJK7v = [VProgressCircular];

export { VProgressCircularStyles_MBQJK7v as default };
