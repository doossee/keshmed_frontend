import { V as VList } from './entry-styles-28.mjs-Jtp32xqJ.mjs';

const VListStyles_gEFJzutS = [VList];

export { VListStyles_gEFJzutS as default };
