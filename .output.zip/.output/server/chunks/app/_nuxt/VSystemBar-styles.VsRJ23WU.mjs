import { V as VSystemBar } from './entry-styles-90.mjs-MbkVpvKx.mjs';

const VSystemBarStyles_VsRJ23WU = [VSystemBar];

export { VSystemBarStyles_VsRJ23WU as default };
