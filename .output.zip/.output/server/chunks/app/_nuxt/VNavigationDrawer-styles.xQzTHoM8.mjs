import { V as VNavigationDrawer } from './entry-styles-80.mjs-sUvvFzGF.mjs';

const VNavigationDrawerStyles_xQzTHoM8 = [VNavigationDrawer];

export { VNavigationDrawerStyles_xQzTHoM8 as default };
