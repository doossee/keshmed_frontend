import { V as VApp } from './entry-styles-4.mjs-D7a1fWhr.mjs';

const VAppStyles_R_HxWUdx = [VApp];

export { VAppStyles_R_HxWUdx as default };
