import { V as VIcon } from './entry-styles-12.mjs-2BW8m3aY.mjs';

const VIconStyles_xH67tpki = [VIcon];

export { VIconStyles_xH67tpki as default };
