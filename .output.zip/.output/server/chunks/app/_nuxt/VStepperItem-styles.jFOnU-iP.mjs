import { V as VStepperItem } from './entry-styles-88.mjs-m2l962dA.mjs';

const VStepperItemStyles_jFOnUIP = [VStepperItem];

export { VStepperItemStyles_jFOnUIP as default };
