const app_vue_vue_type_style_index_0_lang = "html{scroll-behavior:smooth}";

export { app_vue_vue_type_style_index_0_lang as a };
