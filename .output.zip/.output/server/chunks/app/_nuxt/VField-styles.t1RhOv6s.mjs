import { V as VField } from './entry-styles-36.mjs-XWAcHBTB.mjs';

const VFieldStyles_t1RhOv6s = [VField];

export { VFieldStyles_t1RhOv6s as default };
