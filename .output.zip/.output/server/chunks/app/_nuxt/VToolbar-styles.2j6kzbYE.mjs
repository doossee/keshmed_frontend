import { V as VToolbar } from './entry-styles-6.mjs-62NBHEGF.mjs';

const VToolbarStyles_2j6kzbYE = [VToolbar];

export { VToolbarStyles_2j6kzbYE as default };
