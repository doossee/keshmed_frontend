import { V as VDivider } from './entry-styles-30.mjs-UER0HvGN.mjs';

const VDividerStyles_UOnYh_5u = [VDivider];

export { VDividerStyles_UOnYh_5u as default };
