import { V as VKbd } from './entry-styles-75.mjs--MdWR0er.mjs';

const indexStyles_yVWGE9R9 = [VKbd];

export { indexStyles_yVWGE9R9 as default };
