import { V as VSheet } from './entry-styles-56.mjs-oaUc7gV9.mjs';

const VSheetStyles_LZTr8Ns = [VSheet];

export { VSheetStyles_LZTr8Ns as default };
