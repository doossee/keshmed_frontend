import { V as VColorPicker } from './entry-styles-48.mjs-b0NqDjKr.mjs';

const VColorPickerStyles_KoXRSOM = [VColorPicker];

export { VColorPickerStyles_KoXRSOM as default };
