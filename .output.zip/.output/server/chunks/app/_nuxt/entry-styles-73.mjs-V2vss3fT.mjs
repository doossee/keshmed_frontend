const VInfiniteScroll = ".v-infinite-scroll--horizontal{display:flex;flex-direction:row;overflow-x:auto}.v-infinite-scroll--horizontal .v-infinite-scroll-intersect{height:100%;width:1px}.v-infinite-scroll--vertical{display:flex;flex-direction:column;overflow-y:auto}.v-infinite-scroll--vertical .v-infinite-scroll-intersect{height:1px;width:100%}.v-infinite-scroll__side{align-items:center;display:flex;justify-content:center;padding:8px}";

export { VInfiniteScroll as V };
