import { V as VPicker } from './entry-styles-69.mjs-tE3cDLbD.mjs';

const VPickerStyles_awtR8NfT = [VPicker];

export { VPickerStyles_awtR8NfT as default };
