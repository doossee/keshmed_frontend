import { V as VFooter } from './entry-styles-72.mjs-I4JsX0cY.mjs';

const VFooterStyles_W2X5Aj95 = [VFooter];

export { VFooterStyles_W2X5Aj95 as default };
