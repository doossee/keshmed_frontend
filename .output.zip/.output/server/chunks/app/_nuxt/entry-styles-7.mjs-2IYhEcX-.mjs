const VImg = ".v-img{--v-theme-overlay-multiplier:3;z-index:0}.v-img--booting .v-responsive__sizer{transition:none}.v-img--rounded{border-radius:4px}.v-img__error,.v-img__gradient,.v-img__img,.v-img__picture,.v-img__placeholder{height:100%;left:0;position:absolute;top:0;width:100%;z-index:-1}.v-img__img--preload{filter:blur(4px)}.v-img__img--contain{-o-object-fit:contain;object-fit:contain}.v-img__img--cover{-o-object-fit:cover;object-fit:cover}.v-img__gradient{background-repeat:no-repeat}";

export { VImg as V };
