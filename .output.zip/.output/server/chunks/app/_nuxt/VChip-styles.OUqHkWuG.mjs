import { V as VChip } from './entry-styles-25.mjs-qv7hS3Ev.mjs';

const VChipStyles_OUqHkWuG = [VChip];

export { VChipStyles_OUqHkWuG as default };
