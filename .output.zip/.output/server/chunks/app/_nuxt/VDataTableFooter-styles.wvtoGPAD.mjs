import { V as VDataTableFooter } from './entry-styles-59.mjs-dsnKo9lc.mjs';

const VDataTableFooterStyles_wvtoGPAD = [VDataTableFooter];

export { VDataTableFooterStyles_wvtoGPAD as default };
