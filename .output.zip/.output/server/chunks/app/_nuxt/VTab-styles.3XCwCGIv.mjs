import { V as VTab } from './entry-styles-92.mjs--dLnEaUt.mjs';

const VTabStyles_3XCwCGIv = [VTab];

export { VTabStyles_3XCwCGIv as default };
