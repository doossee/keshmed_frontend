import { V as VAvatar } from './entry-styles-18.mjs-gbIkHSJ9.mjs';

const VAvatarStyles_TmvGSzP5 = [VAvatar];

export { VAvatarStyles_TmvGSzP5 as default };
