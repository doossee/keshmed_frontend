import { V as VExpansionPanel } from './entry-styles-70.mjs-guVPftP6.mjs';

const VExpansionPanelsStyles_kaRtXKPy = [VExpansionPanel];

export { VExpansionPanelsStyles_kaRtXKPy as default };
