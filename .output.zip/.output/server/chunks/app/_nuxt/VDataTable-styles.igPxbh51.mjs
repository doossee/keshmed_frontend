import { V as VDataTable } from './entry-styles-58.mjs-IBwqzgCj.mjs';

const VDataTableStyles_igPxbh51 = [VDataTable];

export { VDataTableStyles_igPxbh51 as default };
