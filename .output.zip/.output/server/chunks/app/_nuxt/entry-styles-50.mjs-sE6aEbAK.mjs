const VColorPickerEdit = ".v-color-picker-edit{display:flex;margin-top:24px}.v-color-picker-edit__input{display:flex;flex-wrap:wrap;justify-content:center;text-align:center;width:100%}.v-color-picker-edit__input:not(:last-child){margin-inline-end:8px}.v-color-picker-edit__input input{background:rgba(var(--v-theme-surface-variant),.2);border-radius:4px;color:rgba(var(--v-theme-on-surface));height:32px;margin-bottom:8px;min-width:0;outline:none;text-align:center;width:100%}.v-color-picker-edit__input span{font-size:.75rem}";

export { VColorPickerEdit as V };
