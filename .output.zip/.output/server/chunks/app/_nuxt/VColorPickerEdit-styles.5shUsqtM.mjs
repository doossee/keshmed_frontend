import { V as VColorPickerEdit } from './entry-styles-50.mjs-sE6aEbAK.mjs';

const VColorPickerEditStyles_5shUsqtM = [VColorPickerEdit];

export { VColorPickerEditStyles_5shUsqtM as default };
