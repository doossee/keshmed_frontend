import { V as VThemeProvider } from './entry-styles-94.mjs-jCV2GrKc.mjs';

const VThemeProviderStyles_fQa8Q8uD = [VThemeProvider];

export { VThemeProviderStyles_fQa8Q8uD as default };
