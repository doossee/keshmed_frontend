import { V as VBtnGroup } from './entry-styles-11.mjs-SM4YzH9_.mjs';

const VBtnGroupStyles_xuOYWch7 = [VBtnGroup];

export { VBtnGroupStyles_xuOYWch7 as default };
