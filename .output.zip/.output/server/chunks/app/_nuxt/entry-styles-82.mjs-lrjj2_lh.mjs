const VParallax = ".v-parallax{overflow:hidden;position:relative}.v-parallax--active>.v-img__img{will-change:transform}";

export { VParallax as V };
