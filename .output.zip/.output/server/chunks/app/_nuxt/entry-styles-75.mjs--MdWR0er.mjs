const VKbd = ".v-kbd{background:rgb(var(--v-theme-kbd));border-radius:3px;box-shadow:0 3px 1px -2px var(--v-shadow-key-umbra-opacity,rgba(0,0,0,.2)),0 2px 2px 0 var(--v-shadow-key-penumbra-opacity,rgba(0,0,0,.14)),0 1px 5px 0 var(--v-shadow-key-ambient-opacity,rgba(0,0,0,.12));color:rgb(var(--v-theme-on-kbd));display:inline;font-size:85%;font-weight:400;padding:.2em .4rem}";

export { VKbd as V };
