import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_0 = "" + publicAssetsURL("keshmed-logo.png");

export { _imports_0 as _ };
