const VLayoutItem = ".v-layout-item{transition:.2s cubic-bezier(.4,0,.2,1)}.v-layout-item,.v-layout-item--absolute{position:absolute}";

export { VLayoutItem as V };
