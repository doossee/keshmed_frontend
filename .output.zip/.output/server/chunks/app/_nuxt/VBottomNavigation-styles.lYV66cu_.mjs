import { V as VBottomNavigation } from './entry-styles-40.mjs-oKRY6Bl_.mjs';

const VBottomNavigationStyles_lYV66cu_ = [VBottomNavigation];

export { VBottomNavigationStyles_lYV66cu_ as default };
