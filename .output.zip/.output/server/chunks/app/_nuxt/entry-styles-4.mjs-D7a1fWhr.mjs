const VApp = ".v-application{background:rgb(var(--v-theme-background));color:rgba(var(--v-theme-on-background),var(--v-high-emphasis-opacity));display:flex}.v-application__wrap{backface-visibility:hidden;display:flex;flex:1 1 auto;flex-direction:column;max-width:100%;min-height:100vh;min-height:100dvh;position:relative}";

export { VApp as V };
