import { V as VParallax } from './entry-styles-82.mjs-lrjj2_lh.mjs';

const VParallaxStyles_kbMCQJmV = [VParallax];

export { VParallaxStyles_kbMCQJmV as default };
