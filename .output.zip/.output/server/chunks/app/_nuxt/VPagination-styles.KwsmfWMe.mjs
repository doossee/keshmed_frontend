import { V as VPagination } from './entry-styles-60.mjs-yeRqhYKl.mjs';

const VPaginationStyles_KwsmfWMe = [VPagination];

export { VPaginationStyles_KwsmfWMe as default };
