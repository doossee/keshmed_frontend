import { V as VLabel } from './entry-styles-21.mjs-oJvF75zc.mjs';

const VLabelStyles_prKIV3O3 = [VLabel];

export { VLabelStyles_prKIV3O3 as default };
