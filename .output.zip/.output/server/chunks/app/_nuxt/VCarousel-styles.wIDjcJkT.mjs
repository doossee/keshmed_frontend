import { V as VCarousel } from './entry-styles-45.mjs-Mwjcx7Qb.mjs';

const VCarouselStyles_wIDjcJkT = [VCarousel];

export { VCarouselStyles_wIDjcJkT as default };
