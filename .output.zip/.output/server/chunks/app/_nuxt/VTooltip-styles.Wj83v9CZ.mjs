import { V as VTooltip } from './entry-styles-96.mjs-qx0vImQ7.mjs';

const VTooltipStyles_Wj83v9CZ = [VTooltip];

export { VTooltipStyles_Wj83v9CZ as default };
