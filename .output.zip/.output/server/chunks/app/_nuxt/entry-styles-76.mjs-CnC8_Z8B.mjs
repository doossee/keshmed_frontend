const VLayout = ".v-layout{--v-scrollbar-offset:0px;display:flex;flex:1 1 auto}.v-layout--full-height{--v-scrollbar-offset:inherit;height:100%}";

export { VLayout as V };
