import { V as VRating } from './entry-styles-84.mjs-1CZpr_1Q.mjs';

const VRatingStyles_ijwjTdcL = [VRating];

export { VRatingStyles_ijwjTdcL as default };
