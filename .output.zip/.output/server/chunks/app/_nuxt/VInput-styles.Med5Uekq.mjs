import { V as VInput } from './entry-styles-23.mjs-HNrvo8B9.mjs';

const VInputStyles_Med5Uekq = [VInput];

export { VInputStyles_Med5Uekq as default };
