import { V as VSlideGroup } from './entry-styles-27.mjs-vZJdwzRi.mjs';

const VSlideGroupStyles_qL9gHBtL = [VSlideGroup];

export { VSlideGroupStyles_qL9gHBtL as default };
