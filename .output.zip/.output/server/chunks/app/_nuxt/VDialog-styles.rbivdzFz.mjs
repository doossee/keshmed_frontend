import { V as VDialog } from './entry-styles-42.mjs-jVqjbn78.mjs';

const VDialogStyles_rbivdzFz = [VDialog];

export { VDialogStyles_rbivdzFz as default };
