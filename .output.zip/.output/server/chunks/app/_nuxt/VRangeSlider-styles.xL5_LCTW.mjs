import { V as VSlider } from './entry-styles-52.mjs-vmurU4Pi.mjs';

const VRangeSliderStyles_xL5_LCTW = [VSlider];

export { VRangeSliderStyles_xL5_LCTW as default };
