import { V as VVirtualScroll } from './entry-styles-37.mjs-QA_RhaWw.mjs';

const VVirtualScrollStyles_JoMjt6lp = [VVirtualScroll];

export { VVirtualScrollStyles_JoMjt6lp as default };
