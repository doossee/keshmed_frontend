import { V as VAlert } from './entry-styles-16.mjs-A2ltK2yD.mjs';

const VAlertStyles_V1_vaZGd = [VAlert];

export { VAlertStyles_V1_vaZGd as default };
