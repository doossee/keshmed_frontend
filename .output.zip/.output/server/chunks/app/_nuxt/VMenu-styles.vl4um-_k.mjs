import { V as VMenu } from './entry-styles-31.mjs-SsdG1w0n.mjs';

const VMenuStyles_vl4um_k = [VMenu];

export { VMenuStyles_vl4um_k as default };
