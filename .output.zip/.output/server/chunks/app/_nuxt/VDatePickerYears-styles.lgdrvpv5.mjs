import { V as VDatePickerYears } from './entry-styles-68.mjs-sRMIiiJc.mjs';

const VDatePickerYearsStyles_lgdrvpv5 = [VDatePickerYears];

export { VDatePickerYearsStyles_lgdrvpv5 as default };
