import { V as VRipple } from './entry-styles-15.mjs-3N2nuj9T.mjs';

const indexStyles_LArFcEt1 = [VRipple];

export { indexStyles_LArFcEt1 as default };
