import { V as VItemGroup } from './entry-styles-74.mjs-NzvPtalD.mjs';

const VItemGroupStyles_zv3JB64K = [VItemGroup];

export { VItemGroupStyles_zv3JB64K as default };
