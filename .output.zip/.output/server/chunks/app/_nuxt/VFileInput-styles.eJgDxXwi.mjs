import { V as VFileInput } from './entry-styles-71.mjs-Pl7hROMV.mjs';

const VFileInputStyles_eJgDxXwi = [VFileInput];

export { VFileInputStyles_eJgDxXwi as default };
