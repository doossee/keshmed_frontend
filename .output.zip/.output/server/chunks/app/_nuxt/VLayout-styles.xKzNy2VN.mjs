import { V as VLayout } from './entry-styles-76.mjs-CnC8_Z8B.mjs';

const VLayoutStyles_xKzNy2VN = [VLayout];

export { VLayoutStyles_xKzNy2VN as default };
