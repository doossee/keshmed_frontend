import { V as VColorPickerPreview } from './entry-styles-51.mjs--2_-Vuro.mjs';

const VColorPickerPreviewStyles_2952gpFH = [VColorPickerPreview];

export { VColorPickerPreviewStyles_2952gpFH as default };
