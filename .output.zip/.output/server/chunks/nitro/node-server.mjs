globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import http, { Server as Server$1 } from 'node:http';
import https, { Server } from 'node:https';
import { promises, existsSync } from 'fs';
import { dirname as dirname$1, resolve as resolve$2, join } from 'path';
import { packString } from 'packrup';
import { defineNitroPlugin as defineNitroPlugin$1 } from 'nitropack/dist/runtime/plugin';
import { toValue } from 'vue';
import { promises as promises$1 } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { ipxFSStorage, ipxHttpStorage, createIPX, createIPXH3Handler } from 'ipx';

const suspectProtoRx = /"(?:_|\\u0{2}5[Ff]){2}(?:p|\\u0{2}70)(?:r|\\u0{2}72)(?:o|\\u0{2}6[Ff])(?:t|\\u0{2}74)(?:o|\\u0{2}6[Ff])(?:_|\\u0{2}5[Ff]){2}"\s*:/;
const suspectConstructorRx = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/;
const JsonSigRx = /^\s*["[{]|^\s*-?\d{1,16}(\.\d{1,17})?([Ee][+-]?\d+)?\s*$/;
function jsonParseTransform(key, value) {
  if (key === "__proto__" || key === "constructor" && value && typeof value === "object" && "prototype" in value) {
    warnKeyDropped(key);
    return;
  }
  return value;
}
function warnKeyDropped(key) {
  console.warn(`[destr] Dropping "${key}" key to prevent prototype pollution.`);
}
function destr(value, options = {}) {
  if (typeof value !== "string") {
    return value;
  }
  const _value = value.trim();
  if (
    // eslint-disable-next-line unicorn/prefer-at
    value[0] === '"' && value.at(-1) === '"' && !value.includes("\\")
  ) {
    return _value.slice(1, -1);
  }
  if (_value.length <= 9) {
    const _lval = _value.toLowerCase();
    if (_lval === "true") {
      return true;
    }
    if (_lval === "false") {
      return false;
    }
    if (_lval === "undefined") {
      return void 0;
    }
    if (_lval === "null") {
      return null;
    }
    if (_lval === "nan") {
      return Number.NaN;
    }
    if (_lval === "infinity") {
      return Number.POSITIVE_INFINITY;
    }
    if (_lval === "-infinity") {
      return Number.NEGATIVE_INFINITY;
    }
  }
  if (!JsonSigRx.test(value)) {
    if (options.strict) {
      throw new SyntaxError("[destr] Invalid JSON");
    }
    return value;
  }
  try {
    if (suspectProtoRx.test(value) || suspectConstructorRx.test(value)) {
      if (options.strict) {
        throw new Error("[destr] Possible prototype pollution");
      }
      return JSON.parse(value, jsonParseTransform);
    }
    return JSON.parse(value);
  } catch (error) {
    if (options.strict) {
      throw error;
    }
    return value;
  }
}

const HASH_RE = /#/g;
const AMPERSAND_RE = /&/g;
const EQUAL_RE = /=/g;
const PLUS_RE = /\+/g;
const ENC_CARET_RE = /%5e/gi;
const ENC_BACKTICK_RE = /%60/gi;
const ENC_PIPE_RE = /%7c/gi;
const ENC_SPACE_RE = /%20/gi;
const ENC_SLASH_RE = /%2f/gi;
function encode$1(text) {
  return encodeURI("" + text).replace(ENC_PIPE_RE, "|");
}
function encodeQueryValue(input) {
  return encode$1(typeof input === "string" ? input : JSON.stringify(input)).replace(PLUS_RE, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CARET_RE, "^");
}
function encodeQueryKey(text) {
  return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
}
function decode$1(text = "") {
  try {
    return decodeURIComponent("" + text);
  } catch {
    return "" + text;
  }
}
function decodePath(text) {
  return decode$1(text.replace(ENC_SLASH_RE, "%252F"));
}
function decodeQueryKey(text) {
  return decode$1(text.replace(PLUS_RE, " "));
}
function decodeQueryValue(text) {
  return decode$1(text.replace(PLUS_RE, " "));
}

function parseQuery(parametersString = "") {
  const object = {};
  if (parametersString[0] === "?") {
    parametersString = parametersString.slice(1);
  }
  for (const parameter of parametersString.split("&")) {
    const s = parameter.match(/([^=]+)=?(.*)/) || [];
    if (s.length < 2) {
      continue;
    }
    const key = decodeQueryKey(s[1]);
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = decodeQueryValue(s[2] || "");
    if (object[key] === void 0) {
      object[key] = value;
    } else if (Array.isArray(object[key])) {
      object[key].push(value);
    } else {
      object[key] = [object[key], value];
    }
  }
  return object;
}
function encodeQueryItem(key, value) {
  if (typeof value === "number" || typeof value === "boolean") {
    value = String(value);
  }
  if (!value) {
    return encodeQueryKey(key);
  }
  if (Array.isArray(value)) {
    return value.map((_value) => `${encodeQueryKey(key)}=${encodeQueryValue(_value)}`).join("&");
  }
  return `${encodeQueryKey(key)}=${encodeQueryValue(value)}`;
}
function stringifyQuery(query) {
  return Object.keys(query).filter((k) => query[k] !== void 0).map((k) => encodeQueryItem(k, query[k])).filter(Boolean).join("&");
}
const PROTOCOL_STRICT_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{1,2})/;
const PROTOCOL_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{2})?/;
const PROTOCOL_RELATIVE_REGEX = /^([/\\]\s*){2,}[^/\\]/;
function hasProtocol(inputString, opts = {}) {
  if (typeof opts === "boolean") {
    opts = { acceptRelative: opts };
  }
  if (opts.strict) {
    return PROTOCOL_STRICT_REGEX.test(inputString);
  }
  return PROTOCOL_REGEX.test(inputString) || (opts.acceptRelative ? PROTOCOL_RELATIVE_REGEX.test(inputString) : false);
}
const TRAILING_SLASH_RE = /\/$|\/\?|\/#/;
function hasTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/");
  }
  return TRAILING_SLASH_RE.test(input);
}
function withoutTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return (hasTrailingSlash(input) ? input.slice(0, -1) : input) || "/";
  }
  if (!hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex >= 0) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
  }
  const [s0, ...s] = path.split("?");
  return (s0.slice(0, -1) || "/") + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function withTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/") ? input : input + "/";
  }
  if (hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex >= 0) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
    if (!path) {
      return fragment;
    }
  }
  const [s0, ...s] = path.split("?");
  return s0 + "/" + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function hasLeadingSlash(input = "") {
  return input.startsWith("/");
}
function withLeadingSlash(input = "") {
  return hasLeadingSlash(input) ? input : "/" + input;
}
function withBase(input, base) {
  if (isEmptyURL(base) || hasProtocol(input)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (input.startsWith(_base)) {
    return input;
  }
  return joinURL(_base, input);
}
function withoutBase(input, base) {
  if (isEmptyURL(base)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (!input.startsWith(_base)) {
    return input;
  }
  const trimmed = input.slice(_base.length);
  return trimmed[0] === "/" ? trimmed : "/" + trimmed;
}
function withQuery(input, query) {
  const parsed = parseURL(input);
  const mergedQuery = { ...parseQuery(parsed.search), ...query };
  parsed.search = stringifyQuery(mergedQuery);
  return stringifyParsedURL(parsed);
}
function getQuery$1(input) {
  return parseQuery(parseURL(input).search);
}
function isEmptyURL(url) {
  return !url || url === "/";
}
function isNonEmptyURL(url) {
  return url && url !== "/";
}
const JOIN_LEADING_SLASH_RE = /^\.?\//;
function joinURL(base, ...input) {
  let url = base || "";
  for (const segment of input.filter((url2) => isNonEmptyURL(url2))) {
    if (url) {
      const _segment = segment.replace(JOIN_LEADING_SLASH_RE, "");
      url = withTrailingSlash(url) + _segment;
    } else {
      url = segment;
    }
  }
  return url;
}
function withHttps(input) {
  return withProtocol(input, "https://");
}
function withProtocol(input, protocol) {
  const match = input.match(PROTOCOL_REGEX);
  if (!match) {
    return protocol + input;
  }
  return protocol + input.slice(match[0].length);
}

function parseURL(input = "", defaultProto) {
  const _specialProtoMatch = input.match(
    /^[\s\0]*(blob:|data:|javascript:|vbscript:)(.*)/i
  );
  if (_specialProtoMatch) {
    const [, _proto, _pathname = ""] = _specialProtoMatch;
    return {
      protocol: _proto.toLowerCase(),
      pathname: _pathname,
      href: _proto + _pathname,
      auth: "",
      host: "",
      search: "",
      hash: ""
    };
  }
  if (!hasProtocol(input, { acceptRelative: true })) {
    return defaultProto ? parseURL(defaultProto + input) : parsePath(input);
  }
  const [, protocol = "", auth, hostAndPath = ""] = input.replace(/\\/g, "/").match(/^[\s\0]*([\w+.-]{2,}:)?\/\/([^/@]+@)?(.*)/) || [];
  const [, host = "", path = ""] = hostAndPath.match(/([^#/?]*)(.*)?/) || [];
  const { pathname, search, hash } = parsePath(
    path.replace(/\/(?=[A-Za-z]:)/, "")
  );
  return {
    protocol: protocol.toLowerCase(),
    auth: auth ? auth.slice(0, Math.max(0, auth.length - 1)) : "",
    host,
    pathname,
    search,
    hash
  };
}
function parsePath(input = "") {
  const [pathname = "", search = "", hash = ""] = (input.match(/([^#?]*)(\?[^#]*)?(#.*)?/) || []).splice(1);
  return {
    pathname,
    search,
    hash
  };
}
function stringifyParsedURL(parsed) {
  const pathname = parsed.pathname || "";
  const search = parsed.search ? (parsed.search.startsWith("?") ? "" : "?") + parsed.search : "";
  const hash = parsed.hash || "";
  const auth = parsed.auth ? parsed.auth + "@" : "";
  const host = parsed.host || "";
  const proto = parsed.protocol ? parsed.protocol + "//" : "";
  return proto + auth + host + pathname + search + hash;
}

const fieldContentRegExp = /^[\u0009\u0020-\u007E\u0080-\u00FF]+$/;
function parse(str, options) {
  if (typeof str !== "string") {
    throw new TypeError("argument str must be a string");
  }
  const obj = {};
  const opt = options || {};
  const dec = opt.decode || decode;
  let index = 0;
  while (index < str.length) {
    const eqIdx = str.indexOf("=", index);
    if (eqIdx === -1) {
      break;
    }
    let endIdx = str.indexOf(";", index);
    if (endIdx === -1) {
      endIdx = str.length;
    } else if (endIdx < eqIdx) {
      index = str.lastIndexOf(";", eqIdx - 1) + 1;
      continue;
    }
    const key = str.slice(index, eqIdx).trim();
    if (void 0 === obj[key]) {
      let val = str.slice(eqIdx + 1, endIdx).trim();
      if (val.codePointAt(0) === 34) {
        val = val.slice(1, -1);
      }
      obj[key] = tryDecode(val, dec);
    }
    index = endIdx + 1;
  }
  return obj;
}
function serialize(name, value, options) {
  const opt = options || {};
  const enc = opt.encode || encode;
  if (typeof enc !== "function") {
    throw new TypeError("option encode is invalid");
  }
  if (!fieldContentRegExp.test(name)) {
    throw new TypeError("argument name is invalid");
  }
  const encodedValue = enc(value);
  if (encodedValue && !fieldContentRegExp.test(encodedValue)) {
    throw new TypeError("argument val is invalid");
  }
  let str = name + "=" + encodedValue;
  if (void 0 !== opt.maxAge && opt.maxAge !== null) {
    const maxAge = opt.maxAge - 0;
    if (Number.isNaN(maxAge) || !Number.isFinite(maxAge)) {
      throw new TypeError("option maxAge is invalid");
    }
    str += "; Max-Age=" + Math.floor(maxAge);
  }
  if (opt.domain) {
    if (!fieldContentRegExp.test(opt.domain)) {
      throw new TypeError("option domain is invalid");
    }
    str += "; Domain=" + opt.domain;
  }
  if (opt.path) {
    if (!fieldContentRegExp.test(opt.path)) {
      throw new TypeError("option path is invalid");
    }
    str += "; Path=" + opt.path;
  }
  if (opt.expires) {
    if (!isDate(opt.expires) || Number.isNaN(opt.expires.valueOf())) {
      throw new TypeError("option expires is invalid");
    }
    str += "; Expires=" + opt.expires.toUTCString();
  }
  if (opt.httpOnly) {
    str += "; HttpOnly";
  }
  if (opt.secure) {
    str += "; Secure";
  }
  if (opt.priority) {
    const priority = typeof opt.priority === "string" ? opt.priority.toLowerCase() : opt.priority;
    switch (priority) {
      case "low":
        str += "; Priority=Low";
        break;
      case "medium":
        str += "; Priority=Medium";
        break;
      case "high":
        str += "; Priority=High";
        break;
      default:
        throw new TypeError("option priority is invalid");
    }
  }
  if (opt.sameSite) {
    const sameSite = typeof opt.sameSite === "string" ? opt.sameSite.toLowerCase() : opt.sameSite;
    switch (sameSite) {
      case true:
        str += "; SameSite=Strict";
        break;
      case "lax":
        str += "; SameSite=Lax";
        break;
      case "strict":
        str += "; SameSite=Strict";
        break;
      case "none":
        str += "; SameSite=None";
        break;
      default:
        throw new TypeError("option sameSite is invalid");
    }
  }
  return str;
}
function isDate(val) {
  return Object.prototype.toString.call(val) === "[object Date]" || val instanceof Date;
}
function tryDecode(str, decode2) {
  try {
    return decode2(str);
  } catch {
    return str;
  }
}
function decode(str) {
  return str.includes("%") ? decodeURIComponent(str) : str;
}
function encode(val) {
  return encodeURIComponent(val);
}

const defaults = Object.freeze({
  ignoreUnknown: false,
  respectType: false,
  respectFunctionNames: false,
  respectFunctionProperties: false,
  unorderedObjects: true,
  unorderedArrays: false,
  unorderedSets: false,
  excludeKeys: void 0,
  excludeValues: void 0,
  replacer: void 0
});
function objectHash(object, options) {
  if (options) {
    options = { ...defaults, ...options };
  } else {
    options = defaults;
  }
  const hasher = createHasher(options);
  hasher.dispatch(object);
  return hasher.toString();
}
const defaultPrototypesKeys = Object.freeze([
  "prototype",
  "__proto__",
  "constructor"
]);
function createHasher(options) {
  let buff = "";
  let context = /* @__PURE__ */ new Map();
  const write = (str) => {
    buff += str;
  };
  return {
    toString() {
      return buff;
    },
    getContext() {
      return context;
    },
    dispatch(value) {
      if (options.replacer) {
        value = options.replacer(value);
      }
      const type = value === null ? "null" : typeof value;
      return this[type](value);
    },
    object(object) {
      if (object && typeof object.toJSON === "function") {
        return this.object(object.toJSON());
      }
      const objString = Object.prototype.toString.call(object);
      let objType = "";
      const objectLength = objString.length;
      if (objectLength < 10) {
        objType = "unknown:[" + objString + "]";
      } else {
        objType = objString.slice(8, objectLength - 1);
      }
      objType = objType.toLowerCase();
      let objectNumber = null;
      if ((objectNumber = context.get(object)) === void 0) {
        context.set(object, context.size);
      } else {
        return this.dispatch("[CIRCULAR:" + objectNumber + "]");
      }
      if (typeof Buffer !== "undefined" && Buffer.isBuffer && Buffer.isBuffer(object)) {
        write("buffer:");
        return write(object.toString("utf8"));
      }
      if (objType !== "object" && objType !== "function" && objType !== "asyncfunction") {
        if (this[objType]) {
          this[objType](object);
        } else if (!options.ignoreUnknown) {
          this.unkown(object, objType);
        }
      } else {
        let keys = Object.keys(object);
        if (options.unorderedObjects) {
          keys = keys.sort();
        }
        let extraKeys = [];
        if (options.respectType !== false && !isNativeFunction(object)) {
          extraKeys = defaultPrototypesKeys;
        }
        if (options.excludeKeys) {
          keys = keys.filter((key) => {
            return !options.excludeKeys(key);
          });
          extraKeys = extraKeys.filter((key) => {
            return !options.excludeKeys(key);
          });
        }
        write("object:" + (keys.length + extraKeys.length) + ":");
        const dispatchForKey = (key) => {
          this.dispatch(key);
          write(":");
          if (!options.excludeValues) {
            this.dispatch(object[key]);
          }
          write(",");
        };
        for (const key of keys) {
          dispatchForKey(key);
        }
        for (const key of extraKeys) {
          dispatchForKey(key);
        }
      }
    },
    array(arr, unordered) {
      unordered = unordered === void 0 ? options.unorderedArrays !== false : unordered;
      write("array:" + arr.length + ":");
      if (!unordered || arr.length <= 1) {
        for (const entry of arr) {
          this.dispatch(entry);
        }
        return;
      }
      const contextAdditions = /* @__PURE__ */ new Map();
      const entries = arr.map((entry) => {
        const hasher = createHasher(options);
        hasher.dispatch(entry);
        for (const [key, value] of hasher.getContext()) {
          contextAdditions.set(key, value);
        }
        return hasher.toString();
      });
      context = contextAdditions;
      entries.sort();
      return this.array(entries, false);
    },
    date(date) {
      return write("date:" + date.toJSON());
    },
    symbol(sym) {
      return write("symbol:" + sym.toString());
    },
    unkown(value, type) {
      write(type);
      if (!value) {
        return;
      }
      write(":");
      if (value && typeof value.entries === "function") {
        return this.array(
          Array.from(value.entries()),
          true
          /* ordered */
        );
      }
    },
    error(err) {
      return write("error:" + err.toString());
    },
    boolean(bool) {
      return write("bool:" + bool);
    },
    string(string) {
      write("string:" + string.length + ":");
      write(string);
    },
    function(fn) {
      write("fn:");
      if (isNativeFunction(fn)) {
        this.dispatch("[native]");
      } else {
        this.dispatch(fn.toString());
      }
      if (options.respectFunctionNames !== false) {
        this.dispatch("function-name:" + String(fn.name));
      }
      if (options.respectFunctionProperties) {
        this.object(fn);
      }
    },
    number(number) {
      return write("number:" + number);
    },
    xml(xml) {
      return write("xml:" + xml.toString());
    },
    null() {
      return write("Null");
    },
    undefined() {
      return write("Undefined");
    },
    regexp(regex) {
      return write("regex:" + regex.toString());
    },
    uint8array(arr) {
      write("uint8array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    uint8clampedarray(arr) {
      write("uint8clampedarray:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    int8array(arr) {
      write("int8array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    uint16array(arr) {
      write("uint16array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    int16array(arr) {
      write("int16array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    uint32array(arr) {
      write("uint32array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    int32array(arr) {
      write("int32array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    float32array(arr) {
      write("float32array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    float64array(arr) {
      write("float64array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    arraybuffer(arr) {
      write("arraybuffer:");
      return this.dispatch(new Uint8Array(arr));
    },
    url(url) {
      return write("url:" + url.toString());
    },
    map(map) {
      write("map:");
      const arr = [...map];
      return this.array(arr, options.unorderedSets !== false);
    },
    set(set) {
      write("set:");
      const arr = [...set];
      return this.array(arr, options.unorderedSets !== false);
    },
    file(file) {
      write("file:");
      return this.dispatch([file.name, file.size, file.type, file.lastModfied]);
    },
    blob() {
      if (options.ignoreUnknown) {
        return write("[blob]");
      }
      throw new Error(
        'Hashing Blob objects is currently not supported\nUse "options.replacer" or "options.ignoreUnknown"\n'
      );
    },
    domwindow() {
      return write("domwindow");
    },
    bigint(number) {
      return write("bigint:" + number.toString());
    },
    /* Node.js standard native objects */
    process() {
      return write("process");
    },
    timer() {
      return write("timer");
    },
    pipe() {
      return write("pipe");
    },
    tcp() {
      return write("tcp");
    },
    udp() {
      return write("udp");
    },
    tty() {
      return write("tty");
    },
    statwatcher() {
      return write("statwatcher");
    },
    securecontext() {
      return write("securecontext");
    },
    connection() {
      return write("connection");
    },
    zlib() {
      return write("zlib");
    },
    context() {
      return write("context");
    },
    nodescript() {
      return write("nodescript");
    },
    httpparser() {
      return write("httpparser");
    },
    dataview() {
      return write("dataview");
    },
    signal() {
      return write("signal");
    },
    fsevent() {
      return write("fsevent");
    },
    tlswrap() {
      return write("tlswrap");
    }
  };
}
const nativeFunc = "[native code] }";
const nativeFuncLength = nativeFunc.length;
function isNativeFunction(f) {
  if (typeof f !== "function") {
    return false;
  }
  return Function.prototype.toString.call(f).slice(-nativeFuncLength) === nativeFunc;
}

class WordArray {
  constructor(words, sigBytes) {
    words = this.words = words || [];
    this.sigBytes = sigBytes === void 0 ? words.length * 4 : sigBytes;
  }
  toString(encoder) {
    return (encoder || Hex).stringify(this);
  }
  concat(wordArray) {
    this.clamp();
    if (this.sigBytes % 4) {
      for (let i = 0; i < wordArray.sigBytes; i++) {
        const thatByte = wordArray.words[i >>> 2] >>> 24 - i % 4 * 8 & 255;
        this.words[this.sigBytes + i >>> 2] |= thatByte << 24 - (this.sigBytes + i) % 4 * 8;
      }
    } else {
      for (let j = 0; j < wordArray.sigBytes; j += 4) {
        this.words[this.sigBytes + j >>> 2] = wordArray.words[j >>> 2];
      }
    }
    this.sigBytes += wordArray.sigBytes;
    return this;
  }
  clamp() {
    this.words[this.sigBytes >>> 2] &= 4294967295 << 32 - this.sigBytes % 4 * 8;
    this.words.length = Math.ceil(this.sigBytes / 4);
  }
  clone() {
    return new WordArray([...this.words]);
  }
}
const Hex = {
  stringify(wordArray) {
    const hexChars = [];
    for (let i = 0; i < wordArray.sigBytes; i++) {
      const bite = wordArray.words[i >>> 2] >>> 24 - i % 4 * 8 & 255;
      hexChars.push((bite >>> 4).toString(16), (bite & 15).toString(16));
    }
    return hexChars.join("");
  }
};
const Base64 = {
  stringify(wordArray) {
    const keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    const base64Chars = [];
    for (let i = 0; i < wordArray.sigBytes; i += 3) {
      const byte1 = wordArray.words[i >>> 2] >>> 24 - i % 4 * 8 & 255;
      const byte2 = wordArray.words[i + 1 >>> 2] >>> 24 - (i + 1) % 4 * 8 & 255;
      const byte3 = wordArray.words[i + 2 >>> 2] >>> 24 - (i + 2) % 4 * 8 & 255;
      const triplet = byte1 << 16 | byte2 << 8 | byte3;
      for (let j = 0; j < 4 && i * 8 + j * 6 < wordArray.sigBytes * 8; j++) {
        base64Chars.push(keyStr.charAt(triplet >>> 6 * (3 - j) & 63));
      }
    }
    return base64Chars.join("");
  }
};
const Latin1 = {
  parse(latin1Str) {
    const latin1StrLength = latin1Str.length;
    const words = [];
    for (let i = 0; i < latin1StrLength; i++) {
      words[i >>> 2] |= (latin1Str.charCodeAt(i) & 255) << 24 - i % 4 * 8;
    }
    return new WordArray(words, latin1StrLength);
  }
};
const Utf8 = {
  parse(utf8Str) {
    return Latin1.parse(unescape(encodeURIComponent(utf8Str)));
  }
};
class BufferedBlockAlgorithm {
  constructor() {
    this._data = new WordArray();
    this._nDataBytes = 0;
    this._minBufferSize = 0;
    this.blockSize = 512 / 32;
  }
  reset() {
    this._data = new WordArray();
    this._nDataBytes = 0;
  }
  _append(data) {
    if (typeof data === "string") {
      data = Utf8.parse(data);
    }
    this._data.concat(data);
    this._nDataBytes += data.sigBytes;
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  _doProcessBlock(_dataWords, _offset) {
  }
  _process(doFlush) {
    let processedWords;
    let nBlocksReady = this._data.sigBytes / (this.blockSize * 4);
    if (doFlush) {
      nBlocksReady = Math.ceil(nBlocksReady);
    } else {
      nBlocksReady = Math.max((nBlocksReady | 0) - this._minBufferSize, 0);
    }
    const nWordsReady = nBlocksReady * this.blockSize;
    const nBytesReady = Math.min(nWordsReady * 4, this._data.sigBytes);
    if (nWordsReady) {
      for (let offset = 0; offset < nWordsReady; offset += this.blockSize) {
        this._doProcessBlock(this._data.words, offset);
      }
      processedWords = this._data.words.splice(0, nWordsReady);
      this._data.sigBytes -= nBytesReady;
    }
    return new WordArray(processedWords, nBytesReady);
  }
}
class Hasher extends BufferedBlockAlgorithm {
  update(messageUpdate) {
    this._append(messageUpdate);
    this._process();
    return this;
  }
  finalize(messageUpdate) {
    if (messageUpdate) {
      this._append(messageUpdate);
    }
  }
}

const H = [
  1779033703,
  -1150833019,
  1013904242,
  -1521486534,
  1359893119,
  -1694144372,
  528734635,
  1541459225
];
const K = [
  1116352408,
  1899447441,
  -1245643825,
  -373957723,
  961987163,
  1508970993,
  -1841331548,
  -1424204075,
  -670586216,
  310598401,
  607225278,
  1426881987,
  1925078388,
  -2132889090,
  -1680079193,
  -1046744716,
  -459576895,
  -272742522,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  -1740746414,
  -1473132947,
  -1341970488,
  -1084653625,
  -958395405,
  -710438585,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  -2117940946,
  -1838011259,
  -1564481375,
  -1474664885,
  -1035236496,
  -949202525,
  -778901479,
  -694614492,
  -200395387,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  -2067236844,
  -1933114872,
  -1866530822,
  -1538233109,
  -1090935817,
  -965641998
];
const W = [];
class SHA256 extends Hasher {
  constructor() {
    super(...arguments);
    this._hash = new WordArray([...H]);
  }
  reset() {
    super.reset();
    this._hash = new WordArray([...H]);
  }
  _doProcessBlock(M, offset) {
    const H2 = this._hash.words;
    let a = H2[0];
    let b = H2[1];
    let c = H2[2];
    let d = H2[3];
    let e = H2[4];
    let f = H2[5];
    let g = H2[6];
    let h = H2[7];
    for (let i = 0; i < 64; i++) {
      if (i < 16) {
        W[i] = M[offset + i] | 0;
      } else {
        const gamma0x = W[i - 15];
        const gamma0 = (gamma0x << 25 | gamma0x >>> 7) ^ (gamma0x << 14 | gamma0x >>> 18) ^ gamma0x >>> 3;
        const gamma1x = W[i - 2];
        const gamma1 = (gamma1x << 15 | gamma1x >>> 17) ^ (gamma1x << 13 | gamma1x >>> 19) ^ gamma1x >>> 10;
        W[i] = gamma0 + W[i - 7] + gamma1 + W[i - 16];
      }
      const ch = e & f ^ ~e & g;
      const maj = a & b ^ a & c ^ b & c;
      const sigma0 = (a << 30 | a >>> 2) ^ (a << 19 | a >>> 13) ^ (a << 10 | a >>> 22);
      const sigma1 = (e << 26 | e >>> 6) ^ (e << 21 | e >>> 11) ^ (e << 7 | e >>> 25);
      const t1 = h + sigma1 + ch + K[i] + W[i];
      const t2 = sigma0 + maj;
      h = g;
      g = f;
      f = e;
      e = d + t1 | 0;
      d = c;
      c = b;
      b = a;
      a = t1 + t2 | 0;
    }
    H2[0] = H2[0] + a | 0;
    H2[1] = H2[1] + b | 0;
    H2[2] = H2[2] + c | 0;
    H2[3] = H2[3] + d | 0;
    H2[4] = H2[4] + e | 0;
    H2[5] = H2[5] + f | 0;
    H2[6] = H2[6] + g | 0;
    H2[7] = H2[7] + h | 0;
  }
  finalize(messageUpdate) {
    super.finalize(messageUpdate);
    const nBitsTotal = this._nDataBytes * 8;
    const nBitsLeft = this._data.sigBytes * 8;
    this._data.words[nBitsLeft >>> 5] |= 128 << 24 - nBitsLeft % 32;
    this._data.words[(nBitsLeft + 64 >>> 9 << 4) + 14] = Math.floor(
      nBitsTotal / 4294967296
    );
    this._data.words[(nBitsLeft + 64 >>> 9 << 4) + 15] = nBitsTotal;
    this._data.sigBytes = this._data.words.length * 4;
    this._process();
    return this._hash;
  }
}
function sha256base64(message) {
  return new SHA256().finalize(message).toString(Base64);
}

function hash(object, options = {}) {
  const hashed = typeof object === "string" ? object : objectHash(object, options);
  return sha256base64(hashed).slice(0, 10);
}

function isEqual(object1, object2, hashOptions = {}) {
  if (object1 === object2) {
    return true;
  }
  if (objectHash(object1, hashOptions) === objectHash(object2, hashOptions)) {
    return true;
  }
  return false;
}

const NODE_TYPES = {
  NORMAL: 0,
  WILDCARD: 1,
  PLACEHOLDER: 2
};

function createRouter$1(options = {}) {
  const ctx = {
    options,
    rootNode: createRadixNode(),
    staticRoutesMap: {}
  };
  const normalizeTrailingSlash = (p) => options.strictTrailingSlash ? p : p.replace(/\/$/, "") || "/";
  if (options.routes) {
    for (const path in options.routes) {
      insert(ctx, normalizeTrailingSlash(path), options.routes[path]);
    }
  }
  return {
    ctx,
    // @ts-ignore
    lookup: (path) => lookup(ctx, normalizeTrailingSlash(path)),
    insert: (path, data) => insert(ctx, normalizeTrailingSlash(path), data),
    remove: (path) => remove(ctx, normalizeTrailingSlash(path))
  };
}
function lookup(ctx, path) {
  const staticPathNode = ctx.staticRoutesMap[path];
  if (staticPathNode) {
    return staticPathNode.data;
  }
  const sections = path.split("/");
  const params = {};
  let paramsFound = false;
  let wildcardNode = null;
  let node = ctx.rootNode;
  let wildCardParam = null;
  for (let i = 0; i < sections.length; i++) {
    const section = sections[i];
    if (node.wildcardChildNode !== null) {
      wildcardNode = node.wildcardChildNode;
      wildCardParam = sections.slice(i).join("/");
    }
    const nextNode = node.children.get(section);
    if (nextNode !== void 0) {
      node = nextNode;
    } else {
      node = node.placeholderChildNode;
      if (node !== null) {
        params[node.paramName] = section;
        paramsFound = true;
      } else {
        break;
      }
    }
  }
  if ((node === null || node.data === null) && wildcardNode !== null) {
    node = wildcardNode;
    params[node.paramName || "_"] = wildCardParam;
    paramsFound = true;
  }
  if (!node) {
    return null;
  }
  if (paramsFound) {
    return {
      ...node.data,
      params: paramsFound ? params : void 0
    };
  }
  return node.data;
}
function insert(ctx, path, data) {
  let isStaticRoute = true;
  const sections = path.split("/");
  let node = ctx.rootNode;
  let _unnamedPlaceholderCtr = 0;
  for (const section of sections) {
    let childNode;
    if (childNode = node.children.get(section)) {
      node = childNode;
    } else {
      const type = getNodeType(section);
      childNode = createRadixNode({ type, parent: node });
      node.children.set(section, childNode);
      if (type === NODE_TYPES.PLACEHOLDER) {
        childNode.paramName = section === "*" ? `_${_unnamedPlaceholderCtr++}` : section.slice(1);
        node.placeholderChildNode = childNode;
        isStaticRoute = false;
      } else if (type === NODE_TYPES.WILDCARD) {
        node.wildcardChildNode = childNode;
        childNode.paramName = section.slice(
          3
          /* "**:" */
        ) || "_";
        isStaticRoute = false;
      }
      node = childNode;
    }
  }
  node.data = data;
  if (isStaticRoute === true) {
    ctx.staticRoutesMap[path] = node;
  }
  return node;
}
function remove(ctx, path) {
  let success = false;
  const sections = path.split("/");
  let node = ctx.rootNode;
  for (const section of sections) {
    node = node.children.get(section);
    if (!node) {
      return success;
    }
  }
  if (node.data) {
    const lastSection = sections[sections.length - 1];
    node.data = null;
    if (Object.keys(node.children).length === 0) {
      const parentNode = node.parent;
      parentNode.children.delete(lastSection);
      parentNode.wildcardChildNode = null;
      parentNode.placeholderChildNode = null;
    }
    success = true;
  }
  return success;
}
function createRadixNode(options = {}) {
  return {
    type: options.type || NODE_TYPES.NORMAL,
    parent: options.parent || null,
    children: /* @__PURE__ */ new Map(),
    data: options.data || null,
    paramName: options.paramName || null,
    wildcardChildNode: null,
    placeholderChildNode: null
  };
}
function getNodeType(str) {
  if (str.startsWith("**")) {
    return NODE_TYPES.WILDCARD;
  }
  if (str[0] === ":" || str === "*") {
    return NODE_TYPES.PLACEHOLDER;
  }
  return NODE_TYPES.NORMAL;
}

function toRouteMatcher(router) {
  const table = _routerNodeToTable("", router.ctx.rootNode);
  return _createMatcher(table);
}
function _createMatcher(table) {
  return {
    ctx: { table },
    matchAll: (path) => _matchRoutes(path, table)
  };
}
function _createRouteTable() {
  return {
    static: /* @__PURE__ */ new Map(),
    wildcard: /* @__PURE__ */ new Map(),
    dynamic: /* @__PURE__ */ new Map()
  };
}
function _matchRoutes(path, table) {
  const matches = [];
  for (const [key, value] of _sortRoutesMap(table.wildcard)) {
    if (path.startsWith(key)) {
      matches.push(value);
    }
  }
  for (const [key, value] of _sortRoutesMap(table.dynamic)) {
    if (path.startsWith(key + "/")) {
      const subPath = "/" + path.slice(key.length).split("/").splice(2).join("/");
      matches.push(..._matchRoutes(subPath, value));
    }
  }
  const staticMatch = table.static.get(path);
  if (staticMatch) {
    matches.push(staticMatch);
  }
  return matches.filter(Boolean);
}
function _sortRoutesMap(m) {
  return [...m.entries()].sort((a, b) => a[0].length - b[0].length);
}
function _routerNodeToTable(initialPath, initialNode) {
  const table = _createRouteTable();
  function _addNode(path, node) {
    if (path) {
      if (node.type === NODE_TYPES.NORMAL && !(path.includes("*") || path.includes(":"))) {
        table.static.set(path, node.data);
      } else if (node.type === NODE_TYPES.WILDCARD) {
        table.wildcard.set(path.replace("/**", ""), node.data);
      } else if (node.type === NODE_TYPES.PLACEHOLDER) {
        const subTable = _routerNodeToTable("", node);
        if (node.data) {
          subTable.static.set("/", node.data);
        }
        table.dynamic.set(path.replace(/\/\*|\/:\w+/, ""), subTable);
        return;
      }
    }
    for (const [childPath, child] of node.children.entries()) {
      _addNode(`${path}/${childPath}`.replace("//", "/"), child);
    }
  }
  _addNode(initialPath, initialNode);
  return table;
}

function isPlainObject(value) {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== null && prototype !== Object.prototype && Object.getPrototypeOf(prototype) !== null) {
    return false;
  }
  if (Symbol.iterator in value) {
    return false;
  }
  if (Symbol.toStringTag in value) {
    return Object.prototype.toString.call(value) === "[object Module]";
  }
  return true;
}

function _defu(baseObject, defaults, namespace = ".", merger) {
  if (!isPlainObject(defaults)) {
    return _defu(baseObject, {}, namespace, merger);
  }
  const object = Object.assign({}, defaults);
  for (const key in baseObject) {
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = baseObject[key];
    if (value === null || value === void 0) {
      continue;
    }
    if (merger && merger(object, key, value, namespace)) {
      continue;
    }
    if (Array.isArray(value) && Array.isArray(object[key])) {
      object[key] = [...value, ...object[key]];
    } else if (isPlainObject(value) && isPlainObject(object[key])) {
      object[key] = _defu(
        value,
        object[key],
        (namespace ? `${namespace}.` : "") + key.toString(),
        merger
      );
    } else {
      object[key] = value;
    }
  }
  return object;
}
function createDefu(merger) {
  return (...arguments_) => (
    // eslint-disable-next-line unicorn/no-array-reduce
    arguments_.reduce((p, c) => _defu(p, c, "", merger), {})
  );
}
const defu = createDefu();
const defuFn = createDefu((object, key, currentValue) => {
  if (object[key] !== void 0 && typeof currentValue === "function") {
    object[key] = currentValue(object[key]);
    return true;
  }
});

function rawHeaders(headers) {
  const rawHeaders2 = [];
  for (const key in headers) {
    if (Array.isArray(headers[key])) {
      for (const h of headers[key]) {
        rawHeaders2.push(key, h);
      }
    } else {
      rawHeaders2.push(key, headers[key]);
    }
  }
  return rawHeaders2;
}
function mergeFns(...functions) {
  return function(...args) {
    for (const fn of functions) {
      fn(...args);
    }
  };
}
function createNotImplementedError(name) {
  throw new Error(`[unenv] ${name} is not implemented yet!`);
}

let defaultMaxListeners = 10;
let EventEmitter$1 = class EventEmitter {
  __unenv__ = true;
  _events = /* @__PURE__ */ Object.create(null);
  _maxListeners;
  static get defaultMaxListeners() {
    return defaultMaxListeners;
  }
  static set defaultMaxListeners(arg) {
    if (typeof arg !== "number" || arg < 0 || Number.isNaN(arg)) {
      throw new RangeError(
        'The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + arg + "."
      );
    }
    defaultMaxListeners = arg;
  }
  setMaxListeners(n) {
    if (typeof n !== "number" || n < 0 || Number.isNaN(n)) {
      throw new RangeError(
        'The value of "n" is out of range. It must be a non-negative number. Received ' + n + "."
      );
    }
    this._maxListeners = n;
    return this;
  }
  getMaxListeners() {
    return _getMaxListeners(this);
  }
  emit(type, ...args) {
    if (!this._events[type] || this._events[type].length === 0) {
      return false;
    }
    if (type === "error") {
      let er;
      if (args.length > 0) {
        er = args[0];
      }
      if (er instanceof Error) {
        throw er;
      }
      const err = new Error(
        "Unhandled error." + (er ? " (" + er.message + ")" : "")
      );
      err.context = er;
      throw err;
    }
    for (const _listener of this._events[type]) {
      (_listener.listener || _listener).apply(this, args);
    }
    return true;
  }
  addListener(type, listener) {
    return _addListener(this, type, listener, false);
  }
  on(type, listener) {
    return _addListener(this, type, listener, false);
  }
  prependListener(type, listener) {
    return _addListener(this, type, listener, true);
  }
  once(type, listener) {
    return this.on(type, _wrapOnce(this, type, listener));
  }
  prependOnceListener(type, listener) {
    return this.prependListener(type, _wrapOnce(this, type, listener));
  }
  removeListener(type, listener) {
    return _removeListener(this, type, listener);
  }
  off(type, listener) {
    return this.removeListener(type, listener);
  }
  removeAllListeners(type) {
    return _removeAllListeners(this, type);
  }
  listeners(type) {
    return _listeners(this, type, true);
  }
  rawListeners(type) {
    return _listeners(this, type, false);
  }
  listenerCount(type) {
    return this.rawListeners(type).length;
  }
  eventNames() {
    return Object.keys(this._events);
  }
};
function _addListener(target, type, listener, prepend) {
  _checkListener(listener);
  if (target._events.newListener !== void 0) {
    target.emit("newListener", type, listener.listener || listener);
  }
  if (!target._events[type]) {
    target._events[type] = [];
  }
  if (prepend) {
    target._events[type].unshift(listener);
  } else {
    target._events[type].push(listener);
  }
  const maxListeners = _getMaxListeners(target);
  if (maxListeners > 0 && target._events[type].length > maxListeners && !target._events[type].warned) {
    target._events[type].warned = true;
    const warning = new Error(
      `[unenv] Possible EventEmitter memory leak detected. ${target._events[type].length} ${type} listeners added. Use emitter.setMaxListeners() to increase limit`
    );
    warning.name = "MaxListenersExceededWarning";
    warning.emitter = target;
    warning.type = type;
    warning.count = target._events[type]?.length;
    console.warn(warning);
  }
  return target;
}
function _removeListener(target, type, listener) {
  _checkListener(listener);
  if (!target._events[type] || target._events[type].length === 0) {
    return target;
  }
  const lenBeforeFilter = target._events[type].length;
  target._events[type] = target._events[type].filter((fn) => fn !== listener);
  if (lenBeforeFilter === target._events[type].length) {
    return target;
  }
  if (target._events.removeListener) {
    target.emit("removeListener", type, listener.listener || listener);
  }
  if (target._events[type].length === 0) {
    delete target._events[type];
  }
  return target;
}
function _removeAllListeners(target, type) {
  if (!target._events[type] || target._events[type].length === 0) {
    return target;
  }
  if (target._events.removeListener) {
    for (const _listener of target._events[type]) {
      target.emit("removeListener", type, _listener.listener || _listener);
    }
  }
  delete target._events[type];
  return target;
}
function _wrapOnce(target, type, listener) {
  let fired = false;
  const wrapper = (...args) => {
    if (fired) {
      return;
    }
    target.removeListener(type, wrapper);
    fired = true;
    return args.length === 0 ? listener.call(target) : listener.apply(target, args);
  };
  wrapper.listener = listener;
  return wrapper;
}
function _getMaxListeners(target) {
  return target._maxListeners ?? EventEmitter$1.defaultMaxListeners;
}
function _listeners(target, type, unwrap) {
  let listeners = target._events[type];
  if (typeof listeners === "function") {
    listeners = [listeners];
  }
  return unwrap ? listeners.map((l) => l.listener || l) : listeners;
}
function _checkListener(listener) {
  if (typeof listener !== "function") {
    throw new TypeError(
      'The "listener" argument must be of type Function. Received type ' + typeof listener
    );
  }
}

const EventEmitter = globalThis.EventEmitter || EventEmitter$1;

class _Readable extends EventEmitter {
  __unenv__ = true;
  readableEncoding = null;
  readableEnded = true;
  readableFlowing = false;
  readableHighWaterMark = 0;
  readableLength = 0;
  readableObjectMode = false;
  readableAborted = false;
  readableDidRead = false;
  closed = false;
  errored = null;
  readable = false;
  destroyed = false;
  static from(_iterable, options) {
    return new _Readable(options);
  }
  constructor(_opts) {
    super();
  }
  _read(_size) {
  }
  read(_size) {
  }
  setEncoding(_encoding) {
    return this;
  }
  pause() {
    return this;
  }
  resume() {
    return this;
  }
  isPaused() {
    return true;
  }
  unpipe(_destination) {
    return this;
  }
  unshift(_chunk, _encoding) {
  }
  wrap(_oldStream) {
    return this;
  }
  push(_chunk, _encoding) {
    return false;
  }
  _destroy(_error, _callback) {
    this.removeAllListeners();
  }
  destroy(error) {
    this.destroyed = true;
    this._destroy(error);
    return this;
  }
  pipe(_destenition, _options) {
    return {};
  }
  compose(stream, options) {
    throw new Error("[unenv] Method not implemented.");
  }
  [Symbol.asyncDispose]() {
    this.destroy();
    return Promise.resolve();
  }
  async *[Symbol.asyncIterator]() {
    throw createNotImplementedError("Readable.asyncIterator");
  }
  iterator(options) {
    throw createNotImplementedError("Readable.iterator");
  }
  map(fn, options) {
    throw createNotImplementedError("Readable.map");
  }
  filter(fn, options) {
    throw createNotImplementedError("Readable.filter");
  }
  forEach(fn, options) {
    throw createNotImplementedError("Readable.forEach");
  }
  reduce(fn, initialValue, options) {
    throw createNotImplementedError("Readable.reduce");
  }
  find(fn, options) {
    throw createNotImplementedError("Readable.find");
  }
  findIndex(fn, options) {
    throw createNotImplementedError("Readable.findIndex");
  }
  some(fn, options) {
    throw createNotImplementedError("Readable.some");
  }
  toArray(options) {
    throw createNotImplementedError("Readable.toArray");
  }
  every(fn, options) {
    throw createNotImplementedError("Readable.every");
  }
  flatMap(fn, options) {
    throw createNotImplementedError("Readable.flatMap");
  }
  drop(limit, options) {
    throw createNotImplementedError("Readable.drop");
  }
  take(limit, options) {
    throw createNotImplementedError("Readable.take");
  }
  asIndexedPairs(options) {
    throw createNotImplementedError("Readable.asIndexedPairs");
  }
}
const Readable = globalThis.Readable || _Readable;

class _Writable extends EventEmitter {
  __unenv__ = true;
  writable = true;
  writableEnded = false;
  writableFinished = false;
  writableHighWaterMark = 0;
  writableLength = 0;
  writableObjectMode = false;
  writableCorked = 0;
  closed = false;
  errored = null;
  writableNeedDrain = false;
  destroyed = false;
  _data;
  _encoding = "utf-8";
  constructor(_opts) {
    super();
  }
  pipe(_destenition, _options) {
    return {};
  }
  _write(chunk, encoding, callback) {
    if (this.writableEnded) {
      if (callback) {
        callback();
      }
      return;
    }
    if (this._data === void 0) {
      this._data = chunk;
    } else {
      const a = typeof this._data === "string" ? Buffer.from(this._data, this._encoding || encoding || "utf8") : this._data;
      const b = typeof chunk === "string" ? Buffer.from(chunk, encoding || this._encoding || "utf8") : chunk;
      this._data = Buffer.concat([a, b]);
    }
    this._encoding = encoding;
    if (callback) {
      callback();
    }
  }
  _writev(_chunks, _callback) {
  }
  _destroy(_error, _callback) {
  }
  _final(_callback) {
  }
  write(chunk, arg2, arg3) {
    const encoding = typeof arg2 === "string" ? this._encoding : "utf-8";
    const cb = typeof arg2 === "function" ? arg2 : typeof arg3 === "function" ? arg3 : void 0;
    this._write(chunk, encoding, cb);
    return true;
  }
  setDefaultEncoding(_encoding) {
    return this;
  }
  end(arg1, arg2, arg3) {
    const callback = typeof arg1 === "function" ? arg1 : typeof arg2 === "function" ? arg2 : typeof arg3 === "function" ? arg3 : void 0;
    if (this.writableEnded) {
      if (callback) {
        callback();
      }
      return this;
    }
    const data = arg1 === callback ? void 0 : arg1;
    if (data) {
      const encoding = arg2 === callback ? void 0 : arg2;
      this.write(data, encoding, callback);
    }
    this.writableEnded = true;
    this.writableFinished = true;
    this.emit("close");
    this.emit("finish");
    return this;
  }
  cork() {
  }
  uncork() {
  }
  destroy(_error) {
    this.destroyed = true;
    delete this._data;
    this.removeAllListeners();
    return this;
  }
  compose(stream, options) {
    throw new Error("[h3] Method not implemented.");
  }
}
const Writable = globalThis.Writable || _Writable;

const __Duplex = class {
  allowHalfOpen = true;
  _destroy;
  constructor(readable = new Readable(), writable = new Writable()) {
    Object.assign(this, readable);
    Object.assign(this, writable);
    this._destroy = mergeFns(readable._destroy, writable._destroy);
  }
};
function getDuplex() {
  Object.assign(__Duplex.prototype, Readable.prototype);
  Object.assign(__Duplex.prototype, Writable.prototype);
  return __Duplex;
}
const _Duplex = /* @__PURE__ */ getDuplex();
const Duplex = globalThis.Duplex || _Duplex;

class Socket extends Duplex {
  __unenv__ = true;
  bufferSize = 0;
  bytesRead = 0;
  bytesWritten = 0;
  connecting = false;
  destroyed = false;
  pending = false;
  localAddress = "";
  localPort = 0;
  remoteAddress = "";
  remoteFamily = "";
  remotePort = 0;
  autoSelectFamilyAttemptedAddresses = [];
  readyState = "readOnly";
  constructor(_options) {
    super();
  }
  write(_buffer, _arg1, _arg2) {
    return false;
  }
  connect(_arg1, _arg2, _arg3) {
    return this;
  }
  end(_arg1, _arg2, _arg3) {
    return this;
  }
  setEncoding(_encoding) {
    return this;
  }
  pause() {
    return this;
  }
  resume() {
    return this;
  }
  setTimeout(_timeout, _callback) {
    return this;
  }
  setNoDelay(_noDelay) {
    return this;
  }
  setKeepAlive(_enable, _initialDelay) {
    return this;
  }
  address() {
    return {};
  }
  unref() {
    return this;
  }
  ref() {
    return this;
  }
  destroySoon() {
    this.destroy();
  }
  resetAndDestroy() {
    const err = new Error("ERR_SOCKET_CLOSED");
    err.code = "ERR_SOCKET_CLOSED";
    this.destroy(err);
    return this;
  }
}

class IncomingMessage extends Readable {
  __unenv__ = {};
  aborted = false;
  httpVersion = "1.1";
  httpVersionMajor = 1;
  httpVersionMinor = 1;
  complete = true;
  connection;
  socket;
  headers = {};
  trailers = {};
  method = "GET";
  url = "/";
  statusCode = 200;
  statusMessage = "";
  closed = false;
  errored = null;
  readable = false;
  constructor(socket) {
    super();
    this.socket = this.connection = socket || new Socket();
  }
  get rawHeaders() {
    return rawHeaders(this.headers);
  }
  get rawTrailers() {
    return [];
  }
  setTimeout(_msecs, _callback) {
    return this;
  }
  get headersDistinct() {
    return _distinct(this.headers);
  }
  get trailersDistinct() {
    return _distinct(this.trailers);
  }
}
function _distinct(obj) {
  const d = {};
  for (const [key, value] of Object.entries(obj)) {
    if (key) {
      d[key] = (Array.isArray(value) ? value : [value]).filter(
        Boolean
      );
    }
  }
  return d;
}

class ServerResponse extends Writable {
  __unenv__ = true;
  statusCode = 200;
  statusMessage = "";
  upgrading = false;
  chunkedEncoding = false;
  shouldKeepAlive = false;
  useChunkedEncodingByDefault = false;
  sendDate = false;
  finished = false;
  headersSent = false;
  strictContentLength = false;
  connection = null;
  socket = null;
  req;
  _headers = {};
  constructor(req) {
    super();
    this.req = req;
  }
  assignSocket(socket) {
    socket._httpMessage = this;
    this.socket = socket;
    this.connection = socket;
    this.emit("socket", socket);
    this._flush();
  }
  _flush() {
    this.flushHeaders();
  }
  detachSocket(_socket) {
  }
  writeContinue(_callback) {
  }
  writeHead(statusCode, arg1, arg2) {
    if (statusCode) {
      this.statusCode = statusCode;
    }
    if (typeof arg1 === "string") {
      this.statusMessage = arg1;
      arg1 = void 0;
    }
    const headers = arg2 || arg1;
    if (headers) {
      if (Array.isArray(headers)) ; else {
        for (const key in headers) {
          this.setHeader(key, headers[key]);
        }
      }
    }
    this.headersSent = true;
    return this;
  }
  writeProcessing() {
  }
  setTimeout(_msecs, _callback) {
    return this;
  }
  appendHeader(name, value) {
    name = name.toLowerCase();
    const current = this._headers[name];
    const all = [
      ...Array.isArray(current) ? current : [current],
      ...Array.isArray(value) ? value : [value]
    ].filter(Boolean);
    this._headers[name] = all.length > 1 ? all : all[0];
    return this;
  }
  setHeader(name, value) {
    this._headers[name.toLowerCase()] = value;
    return this;
  }
  getHeader(name) {
    return this._headers[name.toLowerCase()];
  }
  getHeaders() {
    return this._headers;
  }
  getHeaderNames() {
    return Object.keys(this._headers);
  }
  hasHeader(name) {
    return name.toLowerCase() in this._headers;
  }
  removeHeader(name) {
    delete this._headers[name.toLowerCase()];
  }
  addTrailers(_headers) {
  }
  flushHeaders() {
  }
  writeEarlyHints(_headers, cb) {
    if (typeof cb === "function") {
      cb();
    }
  }
}

function useBase(base, handler) {
  base = withoutTrailingSlash(base);
  if (!base || base === "/") {
    return handler;
  }
  return eventHandler(async (event) => {
    event.node.req.originalUrl = event.node.req.originalUrl || event.node.req.url || "/";
    const _path = event._path || event.node.req.url || "/";
    event._path = withoutBase(event.path || "/", base);
    event.node.req.url = event._path;
    try {
      return await handler(event);
    } finally {
      event._path = event.node.req.url = _path;
    }
  });
}

function hasProp(obj, prop) {
  try {
    return prop in obj;
  } catch {
    return false;
  }
}

var __defProp$1 = Object.defineProperty;
var __defNormalProp$1 = (obj, key, value) => key in obj ? __defProp$1(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField$1 = (obj, key, value) => {
  __defNormalProp$1(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
class H3Error extends Error {
  constructor(message, opts = {}) {
    super(message, opts);
    __publicField$1(this, "statusCode", 500);
    __publicField$1(this, "fatal", false);
    __publicField$1(this, "unhandled", false);
    __publicField$1(this, "statusMessage");
    __publicField$1(this, "data");
    __publicField$1(this, "cause");
    if (opts.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
  toJSON() {
    const obj = {
      message: this.message,
      statusCode: sanitizeStatusCode(this.statusCode, 500)
    };
    if (this.statusMessage) {
      obj.statusMessage = sanitizeStatusMessage(this.statusMessage);
    }
    if (this.data !== void 0) {
      obj.data = this.data;
    }
    return obj;
  }
}
__publicField$1(H3Error, "__h3_error__", true);
function createError$1(input) {
  if (typeof input === "string") {
    return new H3Error(input);
  }
  if (isError(input)) {
    return input;
  }
  const err = new H3Error(input.message ?? input.statusMessage ?? "", {
    cause: input.cause || input
  });
  if (hasProp(input, "stack")) {
    try {
      Object.defineProperty(err, "stack", {
        get() {
          return input.stack;
        }
      });
    } catch {
      try {
        err.stack = input.stack;
      } catch {
      }
    }
  }
  if (input.data) {
    err.data = input.data;
  }
  if (input.statusCode) {
    err.statusCode = sanitizeStatusCode(input.statusCode, err.statusCode);
  } else if (input.status) {
    err.statusCode = sanitizeStatusCode(input.status, err.statusCode);
  }
  if (input.statusMessage) {
    err.statusMessage = input.statusMessage;
  } else if (input.statusText) {
    err.statusMessage = input.statusText;
  }
  if (err.statusMessage) {
    const originalMessage = err.statusMessage;
    const sanitizedMessage = sanitizeStatusMessage(err.statusMessage);
    if (sanitizedMessage !== originalMessage) {
      console.warn(
        "[h3] Please prefer using `message` for longer error messages instead of `statusMessage`. In the future, `statusMessage` will be sanitized by default."
      );
    }
  }
  if (input.fatal !== void 0) {
    err.fatal = input.fatal;
  }
  if (input.unhandled !== void 0) {
    err.unhandled = input.unhandled;
  }
  return err;
}
function sendError(event, error, debug) {
  if (event.handled) {
    return;
  }
  const h3Error = isError(error) ? error : createError$1(error);
  const responseBody = {
    statusCode: h3Error.statusCode,
    statusMessage: h3Error.statusMessage,
    stack: [],
    data: h3Error.data
  };
  if (debug) {
    responseBody.stack = (h3Error.stack || "").split("\n").map((l) => l.trim());
  }
  if (event.handled) {
    return;
  }
  const _code = Number.parseInt(h3Error.statusCode);
  setResponseStatus(event, _code, h3Error.statusMessage);
  event.node.res.setHeader("content-type", MIMES.json);
  event.node.res.end(JSON.stringify(responseBody, void 0, 2));
}
function isError(input) {
  return input?.constructor?.__h3_error__ === true;
}

function getQuery(event) {
  return getQuery$1(event.path || "");
}
function isMethod(event, expected, allowHead) {
  if (allowHead && event.method === "HEAD") {
    return true;
  }
  if (typeof expected === "string") {
    if (event.method === expected) {
      return true;
    }
  } else if (expected.includes(event.method)) {
    return true;
  }
  return false;
}
function assertMethod(event, expected, allowHead) {
  if (!isMethod(event, expected, allowHead)) {
    throw createError$1({
      statusCode: 405,
      statusMessage: "HTTP method is not allowed."
    });
  }
}
function getRequestHeaders(event) {
  const _headers = {};
  for (const key in event.node.req.headers) {
    const val = event.node.req.headers[key];
    _headers[key] = Array.isArray(val) ? val.filter(Boolean).join(", ") : val;
  }
  return _headers;
}
function getRequestHeader(event, name) {
  const headers = getRequestHeaders(event);
  const value = headers[name.toLowerCase()];
  return value;
}
const getHeader = getRequestHeader;
function getRequestHost(event, opts = {}) {
  if (opts.xForwardedHost) {
    const xForwardedHost = event.node.req.headers["x-forwarded-host"];
    if (xForwardedHost) {
      return xForwardedHost;
    }
  }
  return event.node.req.headers.host || "localhost";
}
function getRequestProtocol(event, opts = {}) {
  if (opts.xForwardedProto !== false && event.node.req.headers["x-forwarded-proto"] === "https") {
    return "https";
  }
  return event.node.req.connection?.encrypted ? "https" : "http";
}

const RawBodySymbol = Symbol.for("h3RawBody");
const PayloadMethods$1 = ["PATCH", "POST", "PUT", "DELETE"];
function readRawBody(event, encoding = "utf8") {
  assertMethod(event, PayloadMethods$1);
  const _rawBody = event._requestBody || event.web?.request?.body || event.node.req[RawBodySymbol] || event.node.req.rawBody || event.node.req.body;
  if (_rawBody) {
    const promise2 = Promise.resolve(_rawBody).then((_resolved) => {
      if (Buffer.isBuffer(_resolved)) {
        return _resolved;
      }
      if (typeof _resolved.pipeTo === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.pipeTo(
            new WritableStream({
              write(chunk) {
                chunks.push(chunk);
              },
              close() {
                resolve(Buffer.concat(chunks));
              },
              abort(reason) {
                reject(reason);
              }
            })
          ).catch(reject);
        });
      } else if (typeof _resolved.pipe === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.on("data", (chunk) => {
            chunks.push(chunk);
          }).on("end", () => {
            resolve(Buffer.concat(chunks));
          }).on("error", reject);
        });
      }
      if (_resolved.constructor === Object) {
        return Buffer.from(JSON.stringify(_resolved));
      }
      return Buffer.from(_resolved);
    });
    return encoding ? promise2.then((buff) => buff.toString(encoding)) : promise2;
  }
  if (!Number.parseInt(event.node.req.headers["content-length"] || "")) {
    return Promise.resolve(void 0);
  }
  const promise = event.node.req[RawBodySymbol] = new Promise(
    (resolve, reject) => {
      const bodyData = [];
      event.node.req.on("error", (err) => {
        reject(err);
      }).on("data", (chunk) => {
        bodyData.push(chunk);
      }).on("end", () => {
        resolve(Buffer.concat(bodyData));
      });
    }
  );
  const result = encoding ? promise.then((buff) => buff.toString(encoding)) : promise;
  return result;
}
function getRequestWebStream(event) {
  if (!PayloadMethods$1.includes(event.method)) {
    return;
  }
  const bodyStream = event.web?.request?.body || event._requestBody;
  if (bodyStream) {
    return bodyStream;
  }
  const _hasRawBody = RawBodySymbol in event.node.req || "rawBody" in event.node.req || "body" in event.node.req || "__unenv__" in event.node.req;
  if (_hasRawBody) {
    return new ReadableStream({
      async start(controller) {
        const _rawBody = await readRawBody(event, false);
        if (_rawBody) {
          controller.enqueue(_rawBody);
        }
        controller.close();
      }
    });
  }
  return new ReadableStream({
    start: (controller) => {
      event.node.req.on("data", (chunk) => {
        controller.enqueue(chunk);
      });
      event.node.req.on("end", () => {
        controller.close();
      });
      event.node.req.on("error", (err) => {
        controller.error(err);
      });
    }
  });
}

function handleCacheHeaders(event, opts) {
  const cacheControls = ["public", ...opts.cacheControls || []];
  let cacheMatched = false;
  if (opts.maxAge !== void 0) {
    cacheControls.push(`max-age=${+opts.maxAge}`, `s-maxage=${+opts.maxAge}`);
  }
  if (opts.modifiedTime) {
    const modifiedTime = new Date(opts.modifiedTime);
    const ifModifiedSince = event.node.req.headers["if-modified-since"];
    event.node.res.setHeader("last-modified", modifiedTime.toUTCString());
    if (ifModifiedSince && new Date(ifModifiedSince) >= opts.modifiedTime) {
      cacheMatched = true;
    }
  }
  if (opts.etag) {
    event.node.res.setHeader("etag", opts.etag);
    const ifNonMatch = event.node.req.headers["if-none-match"];
    if (ifNonMatch === opts.etag) {
      cacheMatched = true;
    }
  }
  event.node.res.setHeader("cache-control", cacheControls.join(", "));
  if (cacheMatched) {
    event.node.res.statusCode = 304;
    if (!event.handled) {
      event.node.res.end();
    }
    return true;
  }
  return false;
}

const MIMES = {
  html: "text/html",
  json: "application/json"
};

const DISALLOWED_STATUS_CHARS = /[^\u0009\u0020-\u007E]/g;
function sanitizeStatusMessage(statusMessage = "") {
  return statusMessage.replace(DISALLOWED_STATUS_CHARS, "");
}
function sanitizeStatusCode(statusCode, defaultStatusCode = 200) {
  if (!statusCode) {
    return defaultStatusCode;
  }
  if (typeof statusCode === "string") {
    statusCode = Number.parseInt(statusCode, 10);
  }
  if (statusCode < 100 || statusCode > 999) {
    return defaultStatusCode;
  }
  return statusCode;
}

function parseCookies(event) {
  return parse(event.node.req.headers.cookie || "");
}
function getCookie(event, name) {
  return parseCookies(event)[name];
}
function setCookie(event, name, value, serializeOptions) {
  serializeOptions = { path: "/", ...serializeOptions };
  const cookieStr = serialize(name, value, serializeOptions);
  let setCookies = event.node.res.getHeader("set-cookie");
  if (!Array.isArray(setCookies)) {
    setCookies = [setCookies];
  }
  const _optionsHash = objectHash(serializeOptions);
  setCookies = setCookies.filter((cookieValue) => {
    return cookieValue && _optionsHash !== objectHash(parse(cookieValue));
  });
  event.node.res.setHeader("set-cookie", [...setCookies, cookieStr]);
}
function deleteCookie(event, name, serializeOptions) {
  setCookie(event, name, "", {
    ...serializeOptions,
    maxAge: 0
  });
}
function splitCookiesString(cookiesString) {
  if (Array.isArray(cookiesString)) {
    return cookiesString.flatMap((c) => splitCookiesString(c));
  }
  if (typeof cookiesString !== "string") {
    return [];
  }
  const cookiesStrings = [];
  let pos = 0;
  let start;
  let ch;
  let lastComma;
  let nextStart;
  let cookiesSeparatorFound;
  const skipWhitespace = () => {
    while (pos < cookiesString.length && /\s/.test(cookiesString.charAt(pos))) {
      pos += 1;
    }
    return pos < cookiesString.length;
  };
  const notSpecialChar = () => {
    ch = cookiesString.charAt(pos);
    return ch !== "=" && ch !== ";" && ch !== ",";
  };
  while (pos < cookiesString.length) {
    start = pos;
    cookiesSeparatorFound = false;
    while (skipWhitespace()) {
      ch = cookiesString.charAt(pos);
      if (ch === ",") {
        lastComma = pos;
        pos += 1;
        skipWhitespace();
        nextStart = pos;
        while (pos < cookiesString.length && notSpecialChar()) {
          pos += 1;
        }
        if (pos < cookiesString.length && cookiesString.charAt(pos) === "=") {
          cookiesSeparatorFound = true;
          pos = nextStart;
          cookiesStrings.push(cookiesString.slice(start, lastComma));
          start = pos;
        } else {
          pos = lastComma + 1;
        }
      } else {
        pos += 1;
      }
    }
    if (!cookiesSeparatorFound || pos >= cookiesString.length) {
      cookiesStrings.push(cookiesString.slice(start, cookiesString.length));
    }
  }
  return cookiesStrings;
}

const defer = typeof setImmediate === "undefined" ? (fn) => fn() : setImmediate;
function send(event, data, type) {
  if (type) {
    defaultContentType(event, type);
  }
  return new Promise((resolve) => {
    defer(() => {
      if (!event.handled) {
        event.node.res.end(data);
      }
      resolve();
    });
  });
}
function sendNoContent(event, code) {
  if (event.handled) {
    return;
  }
  if (!code && event.node.res.statusCode !== 200) {
    code = event.node.res.statusCode;
  }
  const _code = sanitizeStatusCode(code, 204);
  if (_code === 204) {
    event.node.res.removeHeader("content-length");
  }
  event.node.res.writeHead(_code);
  event.node.res.end();
}
function setResponseStatus(event, code, text) {
  if (code) {
    event.node.res.statusCode = sanitizeStatusCode(
      code,
      event.node.res.statusCode
    );
  }
  if (text) {
    event.node.res.statusMessage = sanitizeStatusMessage(text);
  }
}
function getResponseStatus(event) {
  return event.node.res.statusCode;
}
function getResponseStatusText(event) {
  return event.node.res.statusMessage;
}
function defaultContentType(event, type) {
  if (type && event.node.res.statusCode !== 304 && !event.node.res.getHeader("content-type")) {
    event.node.res.setHeader("content-type", type);
  }
}
function sendRedirect(event, location, code = 302) {
  event.node.res.statusCode = sanitizeStatusCode(
    code,
    event.node.res.statusCode
  );
  event.node.res.setHeader("location", location);
  const encodedLoc = location.replace(/"/g, "%22");
  const html = `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0; url=${encodedLoc}"></head></html>`;
  return send(event, html, MIMES.html);
}
function getResponseHeader(event, name) {
  return event.node.res.getHeader(name);
}
function setResponseHeaders(event, headers) {
  for (const [name, value] of Object.entries(headers)) {
    event.node.res.setHeader(name, value);
  }
}
const setHeaders = setResponseHeaders;
function setResponseHeader(event, name, value) {
  event.node.res.setHeader(name, value);
}
const setHeader = setResponseHeader;
function removeResponseHeader(event, name) {
  return event.node.res.removeHeader(name);
}
function isStream(data) {
  if (!data || typeof data !== "object") {
    return false;
  }
  if (typeof data.pipe === "function") {
    if (typeof data._read === "function") {
      return true;
    }
    if (typeof data.abort === "function") {
      return true;
    }
  }
  if (typeof data.pipeTo === "function") {
    return true;
  }
  return false;
}
function isWebResponse(data) {
  return typeof Response !== "undefined" && data instanceof Response;
}
function sendStream(event, stream) {
  if (!stream || typeof stream !== "object") {
    throw new Error("[h3] Invalid stream provided.");
  }
  event.node.res._data = stream;
  if (!event.node.res.socket) {
    event._handled = true;
    return Promise.resolve();
  }
  if (hasProp(stream, "pipeTo") && typeof stream.pipeTo === "function") {
    return stream.pipeTo(
      new WritableStream({
        write(chunk) {
          event.node.res.write(chunk);
        }
      })
    ).then(() => {
      event.node.res.end();
    });
  }
  if (hasProp(stream, "pipe") && typeof stream.pipe === "function") {
    return new Promise((resolve, reject) => {
      stream.pipe(event.node.res);
      if (stream.on) {
        stream.on("end", () => {
          event.node.res.end();
          resolve();
        });
        stream.on("error", (error) => {
          reject(error);
        });
      }
      event.node.res.on("close", () => {
        if (stream.abort) {
          stream.abort();
        }
      });
    });
  }
  throw new Error("[h3] Invalid or incompatible stream provided.");
}
function sendWebResponse(event, response) {
  for (const [key, value] of response.headers) {
    if (key === "set-cookie") {
      event.node.res.appendHeader(key, splitCookiesString(value));
    } else {
      event.node.res.setHeader(key, value);
    }
  }
  if (response.status) {
    event.node.res.statusCode = sanitizeStatusCode(
      response.status,
      event.node.res.statusCode
    );
  }
  if (response.statusText) {
    event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  }
  if (response.redirected) {
    event.node.res.setHeader("location", response.url);
  }
  if (!response.body) {
    event.node.res.end();
    return;
  }
  return sendStream(event, response.body);
}

const PayloadMethods = /* @__PURE__ */ new Set(["PATCH", "POST", "PUT", "DELETE"]);
const ignoredHeaders = /* @__PURE__ */ new Set([
  "transfer-encoding",
  "connection",
  "keep-alive",
  "upgrade",
  "expect",
  "host"
]);
async function proxyRequest(event, target, opts = {}) {
  let body;
  let duplex;
  if (PayloadMethods.has(event.method)) {
    if (opts.streamRequest) {
      body = getRequestWebStream(event);
      duplex = "half";
    } else {
      body = await readRawBody(event, false).catch(() => void 0);
    }
  }
  const method = opts.fetchOptions?.method || event.method;
  const fetchHeaders = mergeHeaders(
    getProxyRequestHeaders(event),
    opts.fetchOptions?.headers,
    opts.headers
  );
  return sendProxy(event, target, {
    ...opts,
    fetchOptions: {
      method,
      body,
      duplex,
      ...opts.fetchOptions,
      headers: fetchHeaders
    }
  });
}
async function sendProxy(event, target, opts = {}) {
  const response = await _getFetch(opts.fetch)(target, {
    headers: opts.headers,
    ignoreResponseError: true,
    // make $ofetch.raw transparent
    ...opts.fetchOptions
  });
  event.node.res.statusCode = sanitizeStatusCode(
    response.status,
    event.node.res.statusCode
  );
  event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  const cookies = [];
  for (const [key, value] of response.headers.entries()) {
    if (key === "content-encoding") {
      continue;
    }
    if (key === "content-length") {
      continue;
    }
    if (key === "set-cookie") {
      cookies.push(...splitCookiesString(value));
      continue;
    }
    event.node.res.setHeader(key, value);
  }
  if (cookies.length > 0) {
    event.node.res.setHeader(
      "set-cookie",
      cookies.map((cookie) => {
        if (opts.cookieDomainRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookieDomainRewrite,
            "domain"
          );
        }
        if (opts.cookiePathRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookiePathRewrite,
            "path"
          );
        }
        return cookie;
      })
    );
  }
  if (opts.onResponse) {
    await opts.onResponse(event, response);
  }
  if (response._data !== void 0) {
    return response._data;
  }
  if (event.handled) {
    return;
  }
  if (opts.sendStream === false) {
    const data = new Uint8Array(await response.arrayBuffer());
    return event.node.res.end(data);
  }
  if (response.body) {
    for await (const chunk of response.body) {
      event.node.res.write(chunk);
    }
  }
  return event.node.res.end();
}
function getProxyRequestHeaders(event) {
  const headers = /* @__PURE__ */ Object.create(null);
  const reqHeaders = getRequestHeaders(event);
  for (const name in reqHeaders) {
    if (!ignoredHeaders.has(name)) {
      headers[name] = reqHeaders[name];
    }
  }
  return headers;
}
function fetchWithEvent(event, req, init, options) {
  return _getFetch(options?.fetch)(req, {
    ...init,
    context: init?.context || event.context,
    headers: {
      ...getProxyRequestHeaders(event),
      ...init?.headers
    }
  });
}
function _getFetch(_fetch) {
  if (_fetch) {
    return _fetch;
  }
  if (globalThis.fetch) {
    return globalThis.fetch;
  }
  throw new Error(
    "fetch is not available. Try importing `node-fetch-native/polyfill` for Node.js."
  );
}
function rewriteCookieProperty(header, map, property) {
  const _map = typeof map === "string" ? { "*": map } : map;
  return header.replace(
    new RegExp(`(;\\s*${property}=)([^;]+)`, "gi"),
    (match, prefix, previousValue) => {
      let newValue;
      if (previousValue in _map) {
        newValue = _map[previousValue];
      } else if ("*" in _map) {
        newValue = _map["*"];
      } else {
        return match;
      }
      return newValue ? prefix + newValue : "";
    }
  );
}
function mergeHeaders(defaults, ...inputs) {
  const _inputs = inputs.filter(Boolean);
  if (_inputs.length === 0) {
    return defaults;
  }
  const merged = new Headers(defaults);
  for (const input of _inputs) {
    for (const [key, value] of Object.entries(input)) {
      if (value !== void 0) {
        merged.set(key, value);
      }
    }
  }
  return merged;
}

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
class H3Event {
  constructor(req, res) {
    __publicField(this, "__is_event__", true);
    // Context
    __publicField(this, "node");
    // Node
    __publicField(this, "web");
    // Web
    __publicField(this, "context", {});
    // Shared
    // Request
    __publicField(this, "_method");
    __publicField(this, "_path");
    __publicField(this, "_headers");
    __publicField(this, "_requestBody");
    // Response
    __publicField(this, "_handled", false);
    this.node = { req, res };
  }
  // --- Request ---
  get method() {
    if (!this._method) {
      this._method = (this.node.req.method || "GET").toUpperCase();
    }
    return this._method;
  }
  get path() {
    return this._path || this.node.req.url || "/";
  }
  get headers() {
    if (!this._headers) {
      this._headers = _normalizeNodeHeaders(this.node.req.headers);
    }
    return this._headers;
  }
  // --- Respoonse ---
  get handled() {
    return this._handled || this.node.res.writableEnded || this.node.res.headersSent;
  }
  respondWith(response) {
    return Promise.resolve(response).then(
      (_response) => sendWebResponse(this, _response)
    );
  }
  // --- Utils ---
  toString() {
    return `[${this.method}] ${this.path}`;
  }
  toJSON() {
    return this.toString();
  }
  // --- Deprecated ---
  /** @deprecated Please use `event.node.req` instead. **/
  get req() {
    return this.node.req;
  }
  /** @deprecated Please use `event.node.res` instead. **/
  get res() {
    return this.node.res;
  }
}
function isEvent(input) {
  return hasProp(input, "__is_event__");
}
function createEvent(req, res) {
  return new H3Event(req, res);
}
function _normalizeNodeHeaders(nodeHeaders) {
  const headers = new Headers();
  for (const [name, value] of Object.entries(nodeHeaders)) {
    if (Array.isArray(value)) {
      for (const item of value) {
        headers.append(name, item);
      }
    } else if (value) {
      headers.set(name, value);
    }
  }
  return headers;
}

function defineEventHandler(handler) {
  if (typeof handler === "function") {
    return Object.assign(handler, { __is_handler__: true });
  }
  const _hooks = {
    onRequest: _normalizeArray(handler.onRequest),
    onBeforeResponse: _normalizeArray(handler.onBeforeResponse)
  };
  const _handler = (event) => {
    return _callHandler(event, handler.handler, _hooks);
  };
  return Object.assign(_handler, { __is_handler__: true });
}
function _normalizeArray(input) {
  return input ? Array.isArray(input) ? input : [input] : void 0;
}
async function _callHandler(event, handler, hooks) {
  if (hooks.onRequest) {
    for (const hook of hooks.onRequest) {
      await hook(event);
      if (event.handled) {
        return;
      }
    }
  }
  const body = await handler(event);
  const response = { body };
  if (hooks.onBeforeResponse) {
    for (const hook of hooks.onBeforeResponse) {
      await hook(event, response);
    }
  }
  return response.body;
}
const eventHandler = defineEventHandler;
function isEventHandler(input) {
  return hasProp(input, "__is_handler__");
}
function toEventHandler(input, _, _route) {
  if (!isEventHandler(input)) {
    console.warn(
      "[h3] Implicit event handler conversion is deprecated. Use `eventHandler()` or `fromNodeMiddleware()` to define event handlers.",
      _route && _route !== "/" ? `
     Route: ${_route}` : "",
      `
     Handler: ${input}`
    );
  }
  return input;
}
function defineLazyEventHandler(factory) {
  let _promise;
  let _resolved;
  const resolveHandler = () => {
    if (_resolved) {
      return Promise.resolve(_resolved);
    }
    if (!_promise) {
      _promise = Promise.resolve(factory()).then((r) => {
        const handler = r.default || r;
        if (typeof handler !== "function") {
          throw new TypeError(
            "Invalid lazy handler result. It should be a function:",
            handler
          );
        }
        _resolved = toEventHandler(r.default || r);
        return _resolved;
      });
    }
    return _promise;
  };
  return eventHandler((event) => {
    if (_resolved) {
      return _resolved(event);
    }
    return resolveHandler().then((handler) => handler(event));
  });
}
const lazyEventHandler = defineLazyEventHandler;

function createApp(options = {}) {
  const stack = [];
  const handler = createAppEventHandler(stack, options);
  const app = {
    // @ts-ignore
    use: (arg1, arg2, arg3) => use(app, arg1, arg2, arg3),
    handler,
    stack,
    options
  };
  return app;
}
function use(app, arg1, arg2, arg3) {
  if (Array.isArray(arg1)) {
    for (const i of arg1) {
      use(app, i, arg2, arg3);
    }
  } else if (Array.isArray(arg2)) {
    for (const i of arg2) {
      use(app, arg1, i, arg3);
    }
  } else if (typeof arg1 === "string") {
    app.stack.push(
      normalizeLayer({ ...arg3, route: arg1, handler: arg2 })
    );
  } else if (typeof arg1 === "function") {
    app.stack.push(
      normalizeLayer({ ...arg2, route: "/", handler: arg1 })
    );
  } else {
    app.stack.push(normalizeLayer({ ...arg1 }));
  }
  return app;
}
function createAppEventHandler(stack, options) {
  const spacing = options.debug ? 2 : void 0;
  return eventHandler(async (event) => {
    event.node.req.originalUrl = event.node.req.originalUrl || event.node.req.url || "/";
    const _reqPath = event._path || event.node.req.url || "/";
    let _layerPath;
    if (options.onRequest) {
      await options.onRequest(event);
    }
    for (const layer of stack) {
      if (layer.route.length > 1) {
        if (!_reqPath.startsWith(layer.route)) {
          continue;
        }
        _layerPath = _reqPath.slice(layer.route.length) || "/";
      } else {
        _layerPath = _reqPath;
      }
      if (layer.match && !layer.match(_layerPath, event)) {
        continue;
      }
      event._path = _layerPath;
      event.node.req.url = _layerPath;
      const val = await layer.handler(event);
      const _body = val === void 0 ? void 0 : await val;
      if (_body !== void 0) {
        const _response = { body: _body };
        if (options.onBeforeResponse) {
          await options.onBeforeResponse(event, _response);
        }
        await handleHandlerResponse(event, _response.body, spacing);
        if (options.onAfterResponse) {
          await options.onAfterResponse(event, _response);
        }
        return;
      }
      if (event.handled) {
        if (options.onAfterResponse) {
          await options.onAfterResponse(event, void 0);
        }
        return;
      }
    }
    if (!event.handled) {
      throw createError$1({
        statusCode: 404,
        statusMessage: `Cannot find any path matching ${event.path || "/"}.`
      });
    }
    if (options.onAfterResponse) {
      await options.onAfterResponse(event, void 0);
    }
  });
}
function normalizeLayer(input) {
  let handler = input.handler;
  if (handler.handler) {
    handler = handler.handler;
  }
  if (input.lazy) {
    handler = lazyEventHandler(handler);
  } else if (!isEventHandler(handler)) {
    handler = toEventHandler(handler, void 0, input.route);
  }
  return {
    route: withoutTrailingSlash(input.route),
    match: input.match,
    handler
  };
}
function handleHandlerResponse(event, val, jsonSpace) {
  if (val === null) {
    return sendNoContent(event);
  }
  if (val) {
    if (isWebResponse(val)) {
      return sendWebResponse(event, val);
    }
    if (isStream(val)) {
      return sendStream(event, val);
    }
    if (val.buffer) {
      return send(event, val);
    }
    if (val.arrayBuffer && typeof val.arrayBuffer === "function") {
      return val.arrayBuffer().then((arrayBuffer) => {
        return send(event, Buffer.from(arrayBuffer), val.type);
      });
    }
    if (val instanceof Error) {
      throw createError$1(val);
    }
    if (typeof val.end === "function") {
      return true;
    }
  }
  const valType = typeof val;
  if (valType === "string") {
    return send(event, val, MIMES.html);
  }
  if (valType === "object" || valType === "boolean" || valType === "number") {
    return send(event, JSON.stringify(val, void 0, jsonSpace), MIMES.json);
  }
  if (valType === "bigint") {
    return send(event, val.toString(), MIMES.json);
  }
  throw createError$1({
    statusCode: 500,
    statusMessage: `[h3] Cannot send ${valType} as response.`
  });
}

const RouterMethods = [
  "connect",
  "delete",
  "get",
  "head",
  "options",
  "post",
  "put",
  "trace",
  "patch"
];
function createRouter(opts = {}) {
  const _router = createRouter$1({});
  const routes = {};
  let _matcher;
  const router = {};
  const addRoute = (path, handler, method) => {
    let route = routes[path];
    if (!route) {
      routes[path] = route = { path, handlers: {} };
      _router.insert(path, route);
    }
    if (Array.isArray(method)) {
      for (const m of method) {
        addRoute(path, handler, m);
      }
    } else {
      route.handlers[method] = toEventHandler(handler, void 0, path);
    }
    return router;
  };
  router.use = router.add = (path, handler, method) => addRoute(path, handler, method || "all");
  for (const method of RouterMethods) {
    router[method] = (path, handle) => router.add(path, handle, method);
  }
  router.handler = eventHandler((event) => {
    let path = event.path || "/";
    const qIndex = path.indexOf("?");
    if (qIndex !== -1) {
      path = path.slice(0, Math.max(0, qIndex));
    }
    const matched = _router.lookup(path);
    if (!matched || !matched.handlers) {
      if (opts.preemptive || opts.preemtive) {
        throw createError$1({
          statusCode: 404,
          name: "Not Found",
          statusMessage: `Cannot find any route matching ${event.path || "/"}.`
        });
      } else {
        return;
      }
    }
    const method = (event.node.req.method || "get").toLowerCase();
    let handler = matched.handlers[method] || matched.handlers.all;
    if (!handler) {
      if (!_matcher) {
        _matcher = toRouteMatcher(_router);
      }
      const _matches = _matcher.matchAll(path).reverse();
      for (const _match of _matches) {
        if (_match.handlers[method]) {
          handler = _match.handlers[method];
          matched.handlers[method] = matched.handlers[method] || handler;
          break;
        }
        if (_match.handlers.all) {
          handler = _match.handlers.all;
          matched.handlers.all = matched.handlers.all || handler;
          break;
        }
      }
    }
    if (!handler) {
      if (opts.preemptive || opts.preemtive) {
        throw createError$1({
          statusCode: 405,
          name: "Method Not Allowed",
          statusMessage: `Method ${method} is not allowed on this route.`
        });
      } else {
        return;
      }
    }
    event.context.matchedRoute = matched;
    const params = matched.params || {};
    event.context.params = params;
    return Promise.resolve(handler(event)).then((res) => {
      if (res === void 0 && (opts.preemptive || opts.preemtive)) {
        return null;
      }
      return res;
    });
  });
  return router;
}
function toNodeListener(app) {
  const toNodeHandle = async function(req, res) {
    const event = createEvent(req, res);
    try {
      await app.handler(event);
    } catch (_error) {
      const error = createError$1(_error);
      if (!isError(_error)) {
        error.unhandled = true;
      }
      if (app.options.onError) {
        await app.options.onError(error, event);
      }
      if (event.handled) {
        return;
      }
      if (error.unhandled || error.fatal) {
        console.error("[h3]", error.fatal ? "[fatal]" : "[unhandled]", error);
      }
      await sendError(event, error, !!app.options.debug);
    }
  };
  return toNodeHandle;
}

const s=globalThis.Headers,i=globalThis.AbortController,l=globalThis.fetch||(()=>{throw new Error("[node-fetch-native] Failed to fetch: `globalThis.fetch` is not available!")});

class FetchError extends Error {
  constructor(message, opts) {
    super(message, opts);
    this.name = "FetchError";
    if (opts?.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
}
function createFetchError(ctx) {
  const errorMessage = ctx.error?.message || ctx.error?.toString() || "";
  const method = ctx.request?.method || ctx.options?.method || "GET";
  const url = ctx.request?.url || String(ctx.request) || "/";
  const requestStr = `[${method}] ${JSON.stringify(url)}`;
  const statusStr = ctx.response ? `${ctx.response.status} ${ctx.response.statusText}` : "<no response>";
  const message = `${requestStr}: ${statusStr}${errorMessage ? ` ${errorMessage}` : ""}`;
  const fetchError = new FetchError(
    message,
    ctx.error ? { cause: ctx.error } : void 0
  );
  for (const key of ["request", "options", "response"]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx[key];
      }
    });
  }
  for (const [key, refKey] of [
    ["data", "_data"],
    ["status", "status"],
    ["statusCode", "status"],
    ["statusText", "statusText"],
    ["statusMessage", "statusText"]
  ]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx.response && ctx.response[refKey];
      }
    });
  }
  return fetchError;
}

const payloadMethods = new Set(
  Object.freeze(["PATCH", "POST", "PUT", "DELETE"])
);
function isPayloadMethod(method = "GET") {
  return payloadMethods.has(method.toUpperCase());
}
function isJSONSerializable(value) {
  if (value === void 0) {
    return false;
  }
  const t = typeof value;
  if (t === "string" || t === "number" || t === "boolean" || t === null) {
    return true;
  }
  if (t !== "object") {
    return false;
  }
  if (Array.isArray(value)) {
    return true;
  }
  if (value.buffer) {
    return false;
  }
  return value.constructor && value.constructor.name === "Object" || typeof value.toJSON === "function";
}
const textTypes = /* @__PURE__ */ new Set([
  "image/svg",
  "application/xml",
  "application/xhtml",
  "application/html"
]);
const JSON_RE = /^application\/(?:[\w!#$%&*.^`~-]*\+)?json(;.+)?$/i;
function detectResponseType(_contentType = "") {
  if (!_contentType) {
    return "json";
  }
  const contentType = _contentType.split(";").shift() || "";
  if (JSON_RE.test(contentType)) {
    return "json";
  }
  if (textTypes.has(contentType) || contentType.startsWith("text/")) {
    return "text";
  }
  return "blob";
}
function mergeFetchOptions(input, defaults, Headers = globalThis.Headers) {
  const merged = {
    ...defaults,
    ...input
  };
  if (defaults?.params && input?.params) {
    merged.params = {
      ...defaults?.params,
      ...input?.params
    };
  }
  if (defaults?.query && input?.query) {
    merged.query = {
      ...defaults?.query,
      ...input?.query
    };
  }
  if (defaults?.headers && input?.headers) {
    merged.headers = new Headers(defaults?.headers || {});
    for (const [key, value] of new Headers(input?.headers || {})) {
      merged.headers.set(key, value);
    }
  }
  return merged;
}

const retryStatusCodes = /* @__PURE__ */ new Set([
  408,
  // Request Timeout
  409,
  // Conflict
  425,
  // Too Early
  429,
  // Too Many Requests
  500,
  // Internal Server Error
  502,
  // Bad Gateway
  503,
  // Service Unavailable
  504
  //  Gateway Timeout
]);
const nullBodyResponses$1 = /* @__PURE__ */ new Set([101, 204, 205, 304]);
function createFetch$1(globalOptions = {}) {
  const {
    fetch = globalThis.fetch,
    Headers = globalThis.Headers,
    AbortController = globalThis.AbortController
  } = globalOptions;
  async function onError(context) {
    const isAbort = context.error && context.error.name === "AbortError" && !context.options.timeout || false;
    if (context.options.retry !== false && !isAbort) {
      let retries;
      if (typeof context.options.retry === "number") {
        retries = context.options.retry;
      } else {
        retries = isPayloadMethod(context.options.method) ? 0 : 1;
      }
      const responseCode = context.response && context.response.status || 500;
      if (retries > 0 && (Array.isArray(context.options.retryStatusCodes) ? context.options.retryStatusCodes.includes(responseCode) : retryStatusCodes.has(responseCode))) {
        const retryDelay = context.options.retryDelay || 0;
        if (retryDelay > 0) {
          await new Promise((resolve) => setTimeout(resolve, retryDelay));
        }
        return $fetchRaw(context.request, {
          ...context.options,
          retry: retries - 1,
          timeout: context.options.timeout
        });
      }
    }
    const error = createFetchError(context);
    if (Error.captureStackTrace) {
      Error.captureStackTrace(error, $fetchRaw);
    }
    throw error;
  }
  const $fetchRaw = async function $fetchRaw2(_request, _options = {}) {
    const context = {
      request: _request,
      options: mergeFetchOptions(_options, globalOptions.defaults, Headers),
      response: void 0,
      error: void 0
    };
    context.options.method = context.options.method?.toUpperCase();
    if (context.options.onRequest) {
      await context.options.onRequest(context);
    }
    if (typeof context.request === "string") {
      if (context.options.baseURL) {
        context.request = withBase(context.request, context.options.baseURL);
      }
      if (context.options.query || context.options.params) {
        context.request = withQuery(context.request, {
          ...context.options.params,
          ...context.options.query
        });
      }
    }
    if (context.options.body && isPayloadMethod(context.options.method)) {
      if (isJSONSerializable(context.options.body)) {
        context.options.body = typeof context.options.body === "string" ? context.options.body : JSON.stringify(context.options.body);
        context.options.headers = new Headers(context.options.headers || {});
        if (!context.options.headers.has("content-type")) {
          context.options.headers.set("content-type", "application/json");
        }
        if (!context.options.headers.has("accept")) {
          context.options.headers.set("accept", "application/json");
        }
      } else if (
        // ReadableStream Body
        "pipeTo" in context.options.body && typeof context.options.body.pipeTo === "function" || // Node.js Stream Body
        typeof context.options.body.pipe === "function"
      ) {
        if (!("duplex" in context.options)) {
          context.options.duplex = "half";
        }
      }
    }
    if (!context.options.signal && context.options.timeout) {
      const controller = new AbortController();
      setTimeout(() => controller.abort(), context.options.timeout);
      context.options.signal = controller.signal;
    }
    try {
      context.response = await fetch(
        context.request,
        context.options
      );
    } catch (error) {
      context.error = error;
      if (context.options.onRequestError) {
        await context.options.onRequestError(context);
      }
      return await onError(context);
    }
    const hasBody = context.response.body && !nullBodyResponses$1.has(context.response.status) && context.options.method !== "HEAD";
    if (hasBody) {
      const responseType = (context.options.parseResponse ? "json" : context.options.responseType) || detectResponseType(context.response.headers.get("content-type") || "");
      switch (responseType) {
        case "json": {
          const data = await context.response.text();
          const parseFunction = context.options.parseResponse || destr;
          context.response._data = parseFunction(data);
          break;
        }
        case "stream": {
          context.response._data = context.response.body;
          break;
        }
        default: {
          context.response._data = await context.response[responseType]();
        }
      }
    }
    if (context.options.onResponse) {
      await context.options.onResponse(context);
    }
    if (!context.options.ignoreResponseError && context.response.status >= 400 && context.response.status < 600) {
      if (context.options.onResponseError) {
        await context.options.onResponseError(context);
      }
      return await onError(context);
    }
    return context.response;
  };
  const $fetch = async function $fetch2(request, options) {
    const r = await $fetchRaw(request, options);
    return r._data;
  };
  $fetch.raw = $fetchRaw;
  $fetch.native = (...args) => fetch(...args);
  $fetch.create = (defaultOptions = {}) => createFetch$1({
    ...globalOptions,
    defaults: {
      ...globalOptions.defaults,
      ...defaultOptions
    }
  });
  return $fetch;
}

function createNodeFetch() {
  const useKeepAlive = JSON.parse(process.env.FETCH_KEEP_ALIVE || "false");
  if (!useKeepAlive) {
    return l;
  }
  const agentOptions = { keepAlive: true };
  const httpAgent = new http.Agent(agentOptions);
  const httpsAgent = new https.Agent(agentOptions);
  const nodeFetchOptions = {
    agent(parsedURL) {
      return parsedURL.protocol === "http:" ? httpAgent : httpsAgent;
    }
  };
  return function nodeFetchWithKeepAlive(input, init) {
    return l(input, { ...nodeFetchOptions, ...init });
  };
}
const fetch = globalThis.fetch || createNodeFetch();
const Headers$1 = globalThis.Headers || s;
const AbortController$1 = globalThis.AbortController || i;
const ofetch = createFetch$1({ fetch, Headers: Headers$1, AbortController: AbortController$1 });
const $fetch = ofetch;

const nullBodyResponses = /* @__PURE__ */ new Set([101, 204, 205, 304]);
function createCall(handle) {
  return function callHandle(context) {
    const req = new IncomingMessage();
    const res = new ServerResponse(req);
    req.url = context.url || "/";
    req.method = context.method || "GET";
    req.headers = {};
    if (context.headers) {
      const headerEntries = typeof context.headers.entries === "function" ? context.headers.entries() : Object.entries(context.headers);
      for (const [name, value] of headerEntries) {
        if (!value) {
          continue;
        }
        req.headers[name.toLowerCase()] = value;
      }
    }
    req.headers.host = req.headers.host || context.host || "localhost";
    req.connection.encrypted = // @ts-ignore
    req.connection.encrypted || context.protocol === "https";
    req.body = context.body || null;
    req.__unenv__ = context.context;
    return handle(req, res).then(() => {
      let body = res._data;
      if (nullBodyResponses.has(res.statusCode) || req.method.toUpperCase() === "HEAD") {
        body = null;
        delete res._headers["content-length"];
      }
      const r = {
        body,
        headers: res._headers,
        status: res.statusCode,
        statusText: res.statusMessage
      };
      req.destroy();
      res.destroy();
      return r;
    });
  };
}

function createFetch(call, _fetch = global.fetch) {
  return async function ufetch(input, init) {
    const url = input.toString();
    if (!url.startsWith("/")) {
      return _fetch(url, init);
    }
    try {
      const r = await call({ url, ...init });
      return new Response(r.body, {
        status: r.status,
        statusText: r.statusText,
        headers: Object.fromEntries(
          Object.entries(r.headers).map(([name, value]) => [
            name,
            Array.isArray(value) ? value.join(",") : String(value) || ""
          ])
        )
      });
    } catch (error) {
      return new Response(error.toString(), {
        status: Number.parseInt(error.statusCode || error.code) || 500,
        statusText: error.statusText
      });
    }
  };
}

function flatHooks(configHooks, hooks = {}, parentName) {
  for (const key in configHooks) {
    const subHook = configHooks[key];
    const name = parentName ? `${parentName}:${key}` : key;
    if (typeof subHook === "object" && subHook !== null) {
      flatHooks(subHook, hooks, name);
    } else if (typeof subHook === "function") {
      hooks[name] = subHook;
    }
  }
  return hooks;
}
const defaultTask = { run: (function_) => function_() };
const _createTask = () => defaultTask;
const createTask = typeof console.createTask !== "undefined" ? console.createTask : _createTask;
function serialTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return hooks.reduce(
    (promise, hookFunction) => promise.then(() => task.run(() => hookFunction(...args))),
    Promise.resolve()
  );
}
function parallelTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return Promise.all(hooks.map((hook) => task.run(() => hook(...args))));
}
function callEachWith(callbacks, arg0) {
  for (const callback of [...callbacks]) {
    callback(arg0);
  }
}

class Hookable {
  constructor() {
    this._hooks = {};
    this._before = void 0;
    this._after = void 0;
    this._deprecatedMessages = void 0;
    this._deprecatedHooks = {};
    this.hook = this.hook.bind(this);
    this.callHook = this.callHook.bind(this);
    this.callHookWith = this.callHookWith.bind(this);
  }
  hook(name, function_, options = {}) {
    if (!name || typeof function_ !== "function") {
      return () => {
      };
    }
    const originalName = name;
    let dep;
    while (this._deprecatedHooks[name]) {
      dep = this._deprecatedHooks[name];
      name = dep.to;
    }
    if (dep && !options.allowDeprecated) {
      let message = dep.message;
      if (!message) {
        message = `${originalName} hook has been deprecated` + (dep.to ? `, please use ${dep.to}` : "");
      }
      if (!this._deprecatedMessages) {
        this._deprecatedMessages = /* @__PURE__ */ new Set();
      }
      if (!this._deprecatedMessages.has(message)) {
        console.warn(message);
        this._deprecatedMessages.add(message);
      }
    }
    if (!function_.name) {
      try {
        Object.defineProperty(function_, "name", {
          get: () => "_" + name.replace(/\W+/g, "_") + "_hook_cb",
          configurable: true
        });
      } catch {
      }
    }
    this._hooks[name] = this._hooks[name] || [];
    this._hooks[name].push(function_);
    return () => {
      if (function_) {
        this.removeHook(name, function_);
        function_ = void 0;
      }
    };
  }
  hookOnce(name, function_) {
    let _unreg;
    let _function = (...arguments_) => {
      if (typeof _unreg === "function") {
        _unreg();
      }
      _unreg = void 0;
      _function = void 0;
      return function_(...arguments_);
    };
    _unreg = this.hook(name, _function);
    return _unreg;
  }
  removeHook(name, function_) {
    if (this._hooks[name]) {
      const index = this._hooks[name].indexOf(function_);
      if (index !== -1) {
        this._hooks[name].splice(index, 1);
      }
      if (this._hooks[name].length === 0) {
        delete this._hooks[name];
      }
    }
  }
  deprecateHook(name, deprecated) {
    this._deprecatedHooks[name] = typeof deprecated === "string" ? { to: deprecated } : deprecated;
    const _hooks = this._hooks[name] || [];
    delete this._hooks[name];
    for (const hook of _hooks) {
      this.hook(name, hook);
    }
  }
  deprecateHooks(deprecatedHooks) {
    Object.assign(this._deprecatedHooks, deprecatedHooks);
    for (const name in deprecatedHooks) {
      this.deprecateHook(name, deprecatedHooks[name]);
    }
  }
  addHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    const removeFns = Object.keys(hooks).map(
      (key) => this.hook(key, hooks[key])
    );
    return () => {
      for (const unreg of removeFns.splice(0, removeFns.length)) {
        unreg();
      }
    };
  }
  removeHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    for (const key in hooks) {
      this.removeHook(key, hooks[key]);
    }
  }
  removeAllHooks() {
    for (const key in this._hooks) {
      delete this._hooks[key];
    }
  }
  callHook(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(serialTaskCaller, name, ...arguments_);
  }
  callHookParallel(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(parallelTaskCaller, name, ...arguments_);
  }
  callHookWith(caller, name, ...arguments_) {
    const event = this._before || this._after ? { name, args: arguments_, context: {} } : void 0;
    if (this._before) {
      callEachWith(this._before, event);
    }
    const result = caller(
      name in this._hooks ? [...this._hooks[name]] : [],
      arguments_
    );
    if (result instanceof Promise) {
      return result.finally(() => {
        if (this._after && event) {
          callEachWith(this._after, event);
        }
      });
    }
    if (this._after && event) {
      callEachWith(this._after, event);
    }
    return result;
  }
  beforeEach(function_) {
    this._before = this._before || [];
    this._before.push(function_);
    return () => {
      if (this._before !== void 0) {
        const index = this._before.indexOf(function_);
        if (index !== -1) {
          this._before.splice(index, 1);
        }
      }
    };
  }
  afterEach(function_) {
    this._after = this._after || [];
    this._after.push(function_);
    return () => {
      if (this._after !== void 0) {
        const index = this._after.indexOf(function_);
        if (index !== -1) {
          this._after.splice(index, 1);
        }
      }
    };
  }
}
function createHooks() {
  return new Hookable();
}

const NUMBER_CHAR_RE = /\d/;
const STR_SPLITTERS = ["-", "_", "/", "."];
function isUppercase(char = "") {
  if (NUMBER_CHAR_RE.test(char)) {
    return void 0;
  }
  return char !== char.toLowerCase();
}
function splitByCase(str, separators) {
  const splitters = separators ?? STR_SPLITTERS;
  const parts = [];
  if (!str || typeof str !== "string") {
    return parts;
  }
  let buff = "";
  let previousUpper;
  let previousSplitter;
  for (const char of str) {
    const isSplitter = splitters.includes(char);
    if (isSplitter === true) {
      parts.push(buff);
      buff = "";
      previousUpper = void 0;
      continue;
    }
    const isUpper = isUppercase(char);
    if (previousSplitter === false) {
      if (previousUpper === false && isUpper === true) {
        parts.push(buff);
        buff = char;
        previousUpper = isUpper;
        continue;
      }
      if (previousUpper === true && isUpper === false && buff.length > 1) {
        const lastChar = buff.at(-1);
        parts.push(buff.slice(0, Math.max(0, buff.length - 1)));
        buff = lastChar + char;
        previousUpper = isUpper;
        continue;
      }
    }
    buff += char;
    previousUpper = isUpper;
    previousSplitter = isSplitter;
  }
  parts.push(buff);
  return parts;
}
function kebabCase(str, joiner) {
  return str ? (Array.isArray(str) ? str : splitByCase(str)).map((p) => p.toLowerCase()).join(joiner ?? "-") : "";
}
function snakeCase(str) {
  return kebabCase(str || "", "_");
}

function klona(x) {
	if (typeof x !== 'object') return x;

	var k, tmp, str=Object.prototype.toString.call(x);

	if (str === '[object Object]') {
		if (x.constructor !== Object && typeof x.constructor === 'function') {
			tmp = new x.constructor();
			for (k in x) {
				if (x.hasOwnProperty(k) && tmp[k] !== x[k]) {
					tmp[k] = klona(x[k]);
				}
			}
		} else {
			tmp = {}; // null
			for (k in x) {
				if (k === '__proto__') {
					Object.defineProperty(tmp, k, {
						value: klona(x[k]),
						configurable: true,
						enumerable: true,
						writable: true,
					});
				} else {
					tmp[k] = klona(x[k]);
				}
			}
		}
		return tmp;
	}

	if (str === '[object Array]') {
		k = x.length;
		for (tmp=Array(k); k--;) {
			tmp[k] = klona(x[k]);
		}
		return tmp;
	}

	if (str === '[object Set]') {
		tmp = new Set;
		x.forEach(function (val) {
			tmp.add(klona(val));
		});
		return tmp;
	}

	if (str === '[object Map]') {
		tmp = new Map;
		x.forEach(function (val, key) {
			tmp.set(klona(key), klona(val));
		});
		return tmp;
	}

	if (str === '[object Date]') {
		return new Date(+x);
	}

	if (str === '[object RegExp]') {
		tmp = new RegExp(x.source, x.flags);
		tmp.lastIndex = x.lastIndex;
		return tmp;
	}

	if (str === '[object DataView]') {
		return new x.constructor( klona(x.buffer) );
	}

	if (str === '[object ArrayBuffer]') {
		return x.slice(0);
	}

	// ArrayBuffer.isView(x)
	// ~> `new` bcuz `Buffer.slice` => ref
	if (str.slice(-6) === 'Array]') {
		return new x.constructor(x);
	}

	return x;
}

const inlineAppConfig = {
  "nuxt": {
    "buildId": "41103305-d016-4eb8-a874-8ee625bd32d2"
  }
};



const appConfig = defuFn(inlineAppConfig);

const _inlineRuntimeConfig = {
  "app": {
    "baseURL": "/",
    "buildAssetsDir": "/_nuxt/",
    "cdnURL": ""
  },
  "nitro": {
    "envPrefix": "NUXT_",
    "routeRules": {
      "/__nuxt_error": {
        "cache": false
      },
      "/sitemap.xsl": {
        "headers": {
          "Content-Type": "application/xslt+xml"
        }
      },
      "/sitemap_index.xml": {
        "swr": 600,
        "cache": {
          "varies": [
            "X-Forwarded-Host",
            "X-Forwarded-Proto",
            "Host"
          ],
          "swr": true,
          "maxAge": 600
        }
      },
      "/index-sitemap.xml": {
        "swr": 600,
        "cache": {
          "varies": [
            "X-Forwarded-Host",
            "X-Forwarded-Proto",
            "Host"
          ],
          "swr": true,
          "maxAge": 600
        }
      },
      "/_nuxt/builds/meta/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      },
      "/_nuxt/builds/**": {
        "headers": {
          "cache-control": "public, max-age=1, immutable"
        }
      },
      "/_nuxt/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      }
    }
  },
  "public": {
    "backUrl": "http://37.140.216.137:3000/",
    "i18n": {
      "baseUrl": "",
      "locales": {}
    }
  },
  "nuxt-simple-sitemap": {
    "isI18nMapped": true,
    "sitemapName": "sitemap.xml",
    "isMultiSitemap": true,
    "excludeAppSources": [],
    "autoLastmod": false,
    "defaultSitemapsChunkSize": 1000,
    "sortEntries": true,
    "debug": false,
    "discoverImages": true,
    "isNuxtContentDocumentDriven": false,
    "xsl": "/__sitemap__/style.xsl",
    "xslTips": true,
    "xslColumns": [
      {
        "label": "URL",
        "width": "50%"
      },
      {
        "label": "Images",
        "width": "25%",
        "select": "count(image:image)"
      },
      {
        "label": "Last Updated",
        "width": "25%",
        "select": "concat(substring(sitemap:lastmod,0,11),concat(' ', substring(sitemap:lastmod,12,5)),concat(' ', substring(sitemap:lastmod,20,6)))"
      }
    ],
    "credits": true,
    "version": "4.4.0",
    "sitemaps": {
      "index": {
        "sitemapName": "index",
        "_route": "sitemap_index.xml",
        "sitemaps": [],
        "include": [],
        "exclude": []
      }
    },
    "autoI18n": {
      "differentDomains": false,
      "defaultLocale": "",
      "locales": [],
      "strategy": "prefix_except_default"
    }
  },
  "nuxt-site-config": {
    "stack": [
      {
        "_context": "system",
        "_priority": -15,
        "name": "keshmed-ssr",
        "env": "production"
      },
      {
        "_context": "package.json",
        "_priority": -10,
        "name": "nuxt-app"
      }
    ],
    "version": "2.2.9",
    "debug": false
  },
  "ipx": {
    "baseURL": "/_ipx",
    "alias": {},
    "fs": {
      "dir": "../public"
    },
    "http": {
      "domains": []
    }
  }
};
const ENV_PREFIX = "NITRO_";
const ENV_PREFIX_ALT = _inlineRuntimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_";
const _sharedRuntimeConfig = _deepFreeze(
  _applyEnv(klona(_inlineRuntimeConfig))
);
function useRuntimeConfig(event) {
  if (!event) {
    return _sharedRuntimeConfig;
  }
  if (event.context.nitro.runtimeConfig) {
    return event.context.nitro.runtimeConfig;
  }
  const runtimeConfig = klona(_inlineRuntimeConfig);
  _applyEnv(runtimeConfig);
  event.context.nitro.runtimeConfig = runtimeConfig;
  return runtimeConfig;
}
const _sharedAppConfig = _deepFreeze(klona(appConfig));
function useAppConfig(event) {
  if (!event) {
    return _sharedAppConfig;
  }
  if (event.context.nitro.appConfig) {
    return event.context.nitro.appConfig;
  }
  const appConfig$1 = klona(appConfig);
  event.context.nitro.appConfig = appConfig$1;
  return appConfig$1;
}
function _getEnv(key) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[ENV_PREFIX + envKey] ?? process.env[ENV_PREFIX_ALT + envKey]
  );
}
function _isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function _applyEnv(obj, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = _getEnv(subKey);
    if (_isObject(obj[key])) {
      if (_isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
      }
      _applyEnv(obj[key], subKey);
    } else {
      obj[key] = envValue ?? obj[key];
    }
  }
  return obj;
}
function _deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      _deepFreeze(value);
    }
  }
  return Object.freeze(object);
}
new Proxy(/* @__PURE__ */ Object.create(null), {
  get: (_, prop) => {
    console.warn(
      "Please use `useRuntimeConfig()` instead of accessing config directly."
    );
    const runtimeConfig = useRuntimeConfig();
    if (prop in runtimeConfig) {
      return runtimeConfig[prop];
    }
    return void 0;
  }
});

function wrapToPromise(value) {
  if (!value || typeof value.then !== "function") {
    return Promise.resolve(value);
  }
  return value;
}
function asyncCall(function_, ...arguments_) {
  try {
    return wrapToPromise(function_(...arguments_));
  } catch (error) {
    return Promise.reject(error);
  }
}
function isPrimitive$1(value) {
  const type = typeof value;
  return value === null || type !== "object" && type !== "function";
}
function isPureObject(value) {
  const proto = Object.getPrototypeOf(value);
  return !proto || proto.isPrototypeOf(Object);
}
function stringify(value) {
  if (isPrimitive$1(value)) {
    return String(value);
  }
  if (isPureObject(value) || Array.isArray(value)) {
    return JSON.stringify(value);
  }
  if (typeof value.toJSON === "function") {
    return stringify(value.toJSON());
  }
  throw new Error("[unstorage] Cannot stringify value!");
}
function checkBufferSupport() {
  if (typeof Buffer === void 0) {
    throw new TypeError("[unstorage] Buffer is not supported!");
  }
}
const BASE64_PREFIX = "base64:";
function serializeRaw(value) {
  if (typeof value === "string") {
    return value;
  }
  checkBufferSupport();
  const base64 = Buffer.from(value).toString("base64");
  return BASE64_PREFIX + base64;
}
function deserializeRaw(value) {
  if (typeof value !== "string") {
    return value;
  }
  if (!value.startsWith(BASE64_PREFIX)) {
    return value;
  }
  checkBufferSupport();
  return Buffer.from(value.slice(BASE64_PREFIX.length), "base64");
}

const storageKeyProperties = [
  "hasItem",
  "getItem",
  "getItemRaw",
  "setItem",
  "setItemRaw",
  "removeItem",
  "getMeta",
  "setMeta",
  "removeMeta",
  "getKeys",
  "clear",
  "mount",
  "unmount"
];
function prefixStorage(storage, base) {
  base = normalizeBaseKey(base);
  if (!base) {
    return storage;
  }
  const nsStorage = { ...storage };
  for (const property of storageKeyProperties) {
    nsStorage[property] = (key = "", ...args) => (
      // @ts-ignore
      storage[property](base + key, ...args)
    );
  }
  nsStorage.getKeys = (key = "", ...arguments_) => storage.getKeys(base + key, ...arguments_).then((keys) => keys.map((key2) => key2.slice(base.length)));
  return nsStorage;
}
function normalizeKey$1(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0].replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "");
}
function joinKeys(...keys) {
  return normalizeKey$1(keys.join(":"));
}
function normalizeBaseKey(base) {
  base = normalizeKey$1(base);
  return base ? base + ":" : "";
}

function defineDriver$1(factory) {
  return factory;
}

const DRIVER_NAME$1 = "memory";
const memory = defineDriver$1(() => {
  const data = /* @__PURE__ */ new Map();
  return {
    name: DRIVER_NAME$1,
    options: {},
    hasItem(key) {
      return data.has(key);
    },
    getItem(key) {
      return data.get(key) ?? null;
    },
    getItemRaw(key) {
      return data.get(key) ?? null;
    },
    setItem(key, value) {
      data.set(key, value);
    },
    setItemRaw(key, value) {
      data.set(key, value);
    },
    removeItem(key) {
      data.delete(key);
    },
    getKeys() {
      return Array.from(data.keys());
    },
    clear() {
      data.clear();
    },
    dispose() {
      data.clear();
    }
  };
});

function createStorage(options = {}) {
  const context = {
    mounts: { "": options.driver || memory() },
    mountpoints: [""],
    watching: false,
    watchListeners: [],
    unwatch: {}
  };
  const getMount = (key) => {
    for (const base of context.mountpoints) {
      if (key.startsWith(base)) {
        return {
          base,
          relativeKey: key.slice(base.length),
          driver: context.mounts[base]
        };
      }
    }
    return {
      base: "",
      relativeKey: key,
      driver: context.mounts[""]
    };
  };
  const getMounts = (base, includeParent) => {
    return context.mountpoints.filter(
      (mountpoint) => mountpoint.startsWith(base) || includeParent && base.startsWith(mountpoint)
    ).map((mountpoint) => ({
      relativeBase: base.length > mountpoint.length ? base.slice(mountpoint.length) : void 0,
      mountpoint,
      driver: context.mounts[mountpoint]
    }));
  };
  const onChange = (event, key) => {
    if (!context.watching) {
      return;
    }
    key = normalizeKey$1(key);
    for (const listener of context.watchListeners) {
      listener(event, key);
    }
  };
  const startWatch = async () => {
    if (context.watching) {
      return;
    }
    context.watching = true;
    for (const mountpoint in context.mounts) {
      context.unwatch[mountpoint] = await watch(
        context.mounts[mountpoint],
        onChange,
        mountpoint
      );
    }
  };
  const stopWatch = async () => {
    if (!context.watching) {
      return;
    }
    for (const mountpoint in context.unwatch) {
      await context.unwatch[mountpoint]();
    }
    context.unwatch = {};
    context.watching = false;
  };
  const runBatch = (items, commonOptions, cb) => {
    const batches = /* @__PURE__ */ new Map();
    const getBatch = (mount) => {
      let batch = batches.get(mount.base);
      if (!batch) {
        batch = {
          driver: mount.driver,
          base: mount.base,
          items: []
        };
        batches.set(mount.base, batch);
      }
      return batch;
    };
    for (const item of items) {
      const isStringItem = typeof item === "string";
      const key = normalizeKey$1(isStringItem ? item : item.key);
      const value = isStringItem ? void 0 : item.value;
      const options2 = isStringItem || !item.options ? commonOptions : { ...commonOptions, ...item.options };
      const mount = getMount(key);
      getBatch(mount).items.push({
        key,
        value,
        relativeKey: mount.relativeKey,
        options: options2
      });
    }
    return Promise.all([...batches.values()].map((batch) => cb(batch))).then(
      (r) => r.flat()
    );
  };
  const storage = {
    // Item
    hasItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.hasItem, relativeKey, opts);
    },
    getItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => destr(value)
      );
    },
    getItems(items, commonOptions) {
      return runBatch(items, commonOptions, (batch) => {
        if (batch.driver.getItems) {
          return asyncCall(
            batch.driver.getItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              options: item.options
            })),
            commonOptions
          ).then(
            (r) => r.map((item) => ({
              key: joinKeys(batch.base, item.key),
              value: destr(item.value)
            }))
          );
        }
        return Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.getItem,
              item.relativeKey,
              item.options
            ).then((value) => ({
              key: item.key,
              value: destr(value)
            }));
          })
        );
      });
    },
    getItemRaw(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.getItemRaw) {
        return asyncCall(driver.getItemRaw, relativeKey, opts);
      }
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => deserializeRaw(value)
      );
    },
    async setItem(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.setItem) {
        return;
      }
      await asyncCall(driver.setItem, relativeKey, stringify(value), opts);
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async setItems(items, commonOptions) {
      await runBatch(items, commonOptions, async (batch) => {
        if (batch.driver.setItems) {
          await asyncCall(
            batch.driver.setItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              value: stringify(item.value),
              options: item.options
            })),
            commonOptions
          );
        }
        if (!batch.driver.setItem) {
          return;
        }
        await Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.setItem,
              item.relativeKey,
              stringify(item.value),
              item.options
            );
          })
        );
      });
    },
    async setItemRaw(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key, opts);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.setItemRaw) {
        await asyncCall(driver.setItemRaw, relativeKey, value, opts);
      } else if (driver.setItem) {
        await asyncCall(driver.setItem, relativeKey, serializeRaw(value), opts);
      } else {
        return;
      }
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async removeItem(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { removeMeta: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.removeItem) {
        return;
      }
      await asyncCall(driver.removeItem, relativeKey, opts);
      if (opts.removeMeta || opts.removeMata) {
        await asyncCall(driver.removeItem, relativeKey + "$", opts);
      }
      if (!driver.watch) {
        onChange("remove", key);
      }
    },
    // Meta
    async getMeta(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { nativeOnly: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      const meta = /* @__PURE__ */ Object.create(null);
      if (driver.getMeta) {
        Object.assign(meta, await asyncCall(driver.getMeta, relativeKey, opts));
      }
      if (!opts.nativeOnly) {
        const value = await asyncCall(
          driver.getItem,
          relativeKey + "$",
          opts
        ).then((value_) => destr(value_));
        if (value && typeof value === "object") {
          if (typeof value.atime === "string") {
            value.atime = new Date(value.atime);
          }
          if (typeof value.mtime === "string") {
            value.mtime = new Date(value.mtime);
          }
          Object.assign(meta, value);
        }
      }
      return meta;
    },
    setMeta(key, value, opts = {}) {
      return this.setItem(key + "$", value, opts);
    },
    removeMeta(key, opts = {}) {
      return this.removeItem(key + "$", opts);
    },
    // Keys
    async getKeys(base, opts = {}) {
      base = normalizeBaseKey(base);
      const mounts = getMounts(base, true);
      let maskedMounts = [];
      const allKeys = [];
      for (const mount of mounts) {
        const rawKeys = await asyncCall(
          mount.driver.getKeys,
          mount.relativeBase,
          opts
        );
        const keys = rawKeys.map((key) => mount.mountpoint + normalizeKey$1(key)).filter((key) => !maskedMounts.some((p) => key.startsWith(p)));
        allKeys.push(...keys);
        maskedMounts = [
          mount.mountpoint,
          ...maskedMounts.filter((p) => !p.startsWith(mount.mountpoint))
        ];
      }
      return base ? allKeys.filter((key) => key.startsWith(base) && !key.endsWith("$")) : allKeys.filter((key) => !key.endsWith("$"));
    },
    // Utils
    async clear(base, opts = {}) {
      base = normalizeBaseKey(base);
      await Promise.all(
        getMounts(base, false).map(async (m) => {
          if (m.driver.clear) {
            return asyncCall(m.driver.clear, m.relativeBase, opts);
          }
          if (m.driver.removeItem) {
            const keys = await m.driver.getKeys(m.relativeBase || "", opts);
            return Promise.all(
              keys.map((key) => m.driver.removeItem(key, opts))
            );
          }
        })
      );
    },
    async dispose() {
      await Promise.all(
        Object.values(context.mounts).map((driver) => dispose(driver))
      );
    },
    async watch(callback) {
      await startWatch();
      context.watchListeners.push(callback);
      return async () => {
        context.watchListeners = context.watchListeners.filter(
          (listener) => listener !== callback
        );
        if (context.watchListeners.length === 0) {
          await stopWatch();
        }
      };
    },
    async unwatch() {
      context.watchListeners = [];
      await stopWatch();
    },
    // Mount
    mount(base, driver) {
      base = normalizeBaseKey(base);
      if (base && context.mounts[base]) {
        throw new Error(`already mounted at ${base}`);
      }
      if (base) {
        context.mountpoints.push(base);
        context.mountpoints.sort((a, b) => b.length - a.length);
      }
      context.mounts[base] = driver;
      if (context.watching) {
        Promise.resolve(watch(driver, onChange, base)).then((unwatcher) => {
          context.unwatch[base] = unwatcher;
        }).catch(console.error);
      }
      return storage;
    },
    async unmount(base, _dispose = true) {
      base = normalizeBaseKey(base);
      if (!base || !context.mounts[base]) {
        return;
      }
      if (context.watching && base in context.unwatch) {
        context.unwatch[base]();
        delete context.unwatch[base];
      }
      if (_dispose) {
        await dispose(context.mounts[base]);
      }
      context.mountpoints = context.mountpoints.filter((key) => key !== base);
      delete context.mounts[base];
    },
    getMount(key = "") {
      key = normalizeKey$1(key) + ":";
      const m = getMount(key);
      return {
        driver: m.driver,
        base: m.base
      };
    },
    getMounts(base = "", opts = {}) {
      base = normalizeKey$1(base);
      const mounts = getMounts(base, opts.parents);
      return mounts.map((m) => ({
        driver: m.driver,
        base: m.mountpoint
      }));
    }
  };
  return storage;
}
function watch(driver, onChange, base) {
  return driver.watch ? driver.watch((event, key) => onChange(event, base + key)) : () => {
  };
}
async function dispose(driver) {
  if (typeof driver.dispose === "function") {
    await asyncCall(driver.dispose);
  }
}

const _assets = {

};

const normalizeKey = function normalizeKey(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0].replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "");
};

const assets$1 = {
  getKeys() {
    return Promise.resolve(Object.keys(_assets))
  },
  hasItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(id in _assets)
  },
  getItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].import() : null)
  },
  getMeta (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].meta : {})
  }
};

function defineDriver(factory) {
  return factory;
}
function createError(driver, message, opts) {
  const err = new Error(`[unstorage] [${driver}] ${message}`, opts);
  return err;
}
function createRequiredError(driver, name) {
  if (Array.isArray(name)) {
    return createError(
      driver,
      `Missing some of the required options ${name.map((n) => "`" + n + "`").join(", ")}`
    );
  }
  return createError(driver, `Missing required option \`${name}\`.`);
}

function ignoreNotfound(err) {
  return err.code === "ENOENT" || err.code === "EISDIR" ? null : err;
}
function ignoreExists(err) {
  return err.code === "EEXIST" ? null : err;
}
async function writeFile(path, data, encoding) {
  await ensuredir(dirname$1(path));
  return promises.writeFile(path, data, encoding);
}
function readFile(path, encoding) {
  return promises.readFile(path, encoding).catch(ignoreNotfound);
}
function unlink(path) {
  return promises.unlink(path).catch(ignoreNotfound);
}
function readdir(dir) {
  return promises.readdir(dir, { withFileTypes: true }).catch(ignoreNotfound).then((r) => r || []);
}
async function ensuredir(dir) {
  if (existsSync(dir)) {
    return;
  }
  await ensuredir(dirname$1(dir)).catch(ignoreExists);
  await promises.mkdir(dir).catch(ignoreExists);
}
async function readdirRecursive(dir, ignore) {
  if (ignore && ignore(dir)) {
    return [];
  }
  const entries = await readdir(dir);
  const files = [];
  await Promise.all(
    entries.map(async (entry) => {
      const entryPath = resolve$2(dir, entry.name);
      if (entry.isDirectory()) {
        const dirFiles = await readdirRecursive(entryPath, ignore);
        files.push(...dirFiles.map((f) => entry.name + "/" + f));
      } else {
        if (!(ignore && ignore(entry.name))) {
          files.push(entry.name);
        }
      }
    })
  );
  return files;
}
async function rmRecursive(dir) {
  const entries = await readdir(dir);
  await Promise.all(
    entries.map((entry) => {
      const entryPath = resolve$2(dir, entry.name);
      if (entry.isDirectory()) {
        return rmRecursive(entryPath).then(() => promises.rmdir(entryPath));
      } else {
        return promises.unlink(entryPath);
      }
    })
  );
}

const PATH_TRAVERSE_RE = /\.\.\:|\.\.$/;
const DRIVER_NAME = "fs-lite";
const unstorage_47drivers_47fs_45lite = defineDriver((opts = {}) => {
  if (!opts.base) {
    throw createRequiredError(DRIVER_NAME, "base");
  }
  opts.base = resolve$2(opts.base);
  const r = (key) => {
    if (PATH_TRAVERSE_RE.test(key)) {
      throw createError(
        DRIVER_NAME,
        `Invalid key: ${JSON.stringify(key)}. It should not contain .. segments`
      );
    }
    const resolved = join(opts.base, key.replace(/:/g, "/"));
    return resolved;
  };
  return {
    name: DRIVER_NAME,
    options: opts,
    hasItem(key) {
      return existsSync(r(key));
    },
    getItem(key) {
      return readFile(r(key), "utf8");
    },
    getItemRaw(key) {
      return readFile(r(key));
    },
    async getMeta(key) {
      const { atime, mtime, size, birthtime, ctime } = await promises.stat(r(key)).catch(() => ({}));
      return { atime, mtime, size, birthtime, ctime };
    },
    setItem(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value, "utf8");
    },
    setItemRaw(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value);
    },
    removeItem(key) {
      if (opts.readOnly) {
        return;
      }
      return unlink(r(key));
    },
    getKeys() {
      return readdirRecursive(r("."), opts.ignore);
    },
    async clear() {
      if (opts.readOnly || opts.noClear) {
        return;
      }
      await rmRecursive(r("."));
    }
  };
});

const storage = createStorage({});

storage.mount('/assets', assets$1);

storage.mount('data', unstorage_47drivers_47fs_45lite({"driver":"fsLite","base":"D:\\project_learning\\keshmed-ssr\\.data\\kv"}));

function useStorage(base = "") {
  return base ? prefixStorage(storage, base) : storage;
}

const defaultCacheOptions = {
  name: "_",
  base: "/cache",
  swr: true,
  maxAge: 1
};
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions, ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = opts.integrity || hash([fn, opts]);
  const validate = opts.validate || ((entry) => entry.value !== void 0);
  async function get(key, resolver, shouldInvalidateCache, event) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    const entry = await useStorage().getItem(cacheKey) || {};
    const ttl = (opts.maxAge ?? opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || validate(entry) === false;
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry) !== false) {
          const promise = useStorage().setItem(cacheKey, entry).catch((error) => {
            console.error(`[nitro] [cache] Cache write error.`, error);
            useNitroApp().captureError(error, { event, tags: ["cache"] });
          });
          if (event && event.waitUntil) {
            event.waitUntil(promise);
          }
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (entry.value === void 0) {
      await _resolvePromise;
    } else if (expired && event && event.waitUntil) {
      event.waitUntil(_resolvePromise);
    }
    if (opts.swr && validate(entry) !== false) {
      _resolvePromise.catch((error) => {
        console.error(`[nitro] [cache] SWR handler error.`, error);
        useNitroApp().captureError(error, { event, tags: ["cache"] });
      });
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = opts.shouldInvalidateCache?.(...args);
    const entry = await get(
      key,
      () => fn(...args),
      shouldInvalidateCache,
      args[0] && isEvent(args[0]) ? args[0] : void 0
    );
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
const cachedFunction = defineCachedFunction;
function getKey(...args) {
  return args.length > 0 ? hash(args, {}) : "";
}
function escapeKey(key) {
  return String(key).replace(/\W/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions) {
  const variableHeaderNames = (opts.varies || []).filter(Boolean).map((h) => h.toLowerCase()).sort();
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const customKey = await opts.getKey?.(event);
      if (customKey) {
        return escapeKey(customKey);
      }
      const _path = event.node.req.originalUrl || event.node.req.url || event.path;
      const _pathname = escapeKey(decodeURI(parseURL(_path).pathname)).slice(0, 16) || "index";
      const _hashedPath = `${_pathname}.${hash(_path)}`;
      const _headers = variableHeaderNames.map((header) => [header, event.node.req.headers[header]]).map(([name, value]) => `${escapeKey(name)}.${hash(value)}`);
      return [_hashedPath, ..._headers].join(":");
    },
    validate: (entry) => {
      if (!entry.value) {
        return false;
      }
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      if (entry.value.headers.etag === "undefined" || entry.value.headers["last-modified"] === "undefined") {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: opts.integrity || hash([handler, opts])
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const variableHeaders = {};
      for (const header of variableHeaderNames) {
        variableHeaders[header] = incomingEvent.node.req.headers[header];
      }
      const reqProxy = cloneWithProxy(incomingEvent.node.req, {
        headers: variableHeaders
      });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        writableEnded: false,
        writableFinished: false,
        headersSent: false,
        closed: false,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            for (const header in headers2) {
              this.setHeader(header, headers2[header]);
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.context = incomingEvent.context;
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = String(
        headers.Etag || headers.etag || `W/"${hash(body)}"`
      );
      headers["last-modified"] = String(
        headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString()
      );
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(event);
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      const value = response.headers[name];
      if (name === "set-cookie") {
        event.node.res.appendHeader(
          name,
          splitCookiesString(value)
        );
      } else {
        event.node.res.setHeader(name, value);
      }
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

function hasReqHeader(event, name, includes) {
  const value = getRequestHeader(event, name);
  return value && typeof value === "string" && value.toLowerCase().includes(includes);
}
function isJsonRequest(event) {
  if (hasReqHeader(event, "accept", "text/html")) {
    return false;
  }
  return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || hasReqHeader(event, "sec-fetch-mode", "cors") || event.path.startsWith("/api/") || event.path.endsWith(".json");
}
function normalizeError(error) {
  const cwd = typeof process.cwd === "function" ? process.cwd() : "/";
  const stack = (error.stack || "").split("\n").splice(1).filter((line) => line.includes("at ")).map((line) => {
    const text = line.replace(cwd + "/", "./").replace("webpack:/", "").replace("file://", "").trim();
    return {
      text,
      internal: line.includes("node_modules") && !line.includes(".cache") || line.includes("internal") || line.includes("new Promise")
    };
  });
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage ?? (statusCode === 404 ? "Not Found" : "");
  const message = error.message || error.toString();
  return {
    stack,
    statusCode,
    statusMessage,
    message
  };
}
function _captureError(error, type) {
  console.error(`[nitro] [${type}]`, error);
  useNitroApp().captureError(error, { tags: [type] });
}
function trapUnhandledNodeErrors() {
  process.on(
    "unhandledRejection",
    (error) => _captureError(error, "unhandledRejection")
  );
  process.on(
    "uncaughtException",
    (error) => _captureError(error, "uncaughtException")
  );
}
function joinHeaders(value) {
  return Array.isArray(value) ? value.join(", ") : String(value);
}
function normalizeFetchResponse(response) {
  if (!response.headers.has("set-cookie")) {
    return response;
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: normalizeCookieHeaders(response.headers)
  });
}
function normalizeCookieHeader(header = "") {
  return splitCookiesString(joinHeaders(header));
}
function normalizeCookieHeaders(headers) {
  const outgoingHeaders = new Headers();
  for (const [name, header] of headers) {
    if (name === "set-cookie") {
      for (const cookie of normalizeCookieHeader(header)) {
        outgoingHeaders.append("set-cookie", cookie);
      }
    } else {
      outgoingHeaders.set(name, joinHeaders(header));
    }
  }
  return outgoingHeaders;
}

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter$1({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler(ctx) {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      return sendRedirect(
        event,
        routeRules.redirect.to,
        routeRules.redirect.statusCode
      );
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return proxyRequest(event, target, {
        fetch: ctx.localFetch,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(event.path.split("?")[0], useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

function createFilter$1(options = {}) {
  const include = options.include || [];
  const exclude = options.exclude || [];
  return function(path) {
    for (const v of [{ rules: exclude, result: false }, { rules: include, result: true }]) {
      const regexRules = v.rules.filter((r) => r instanceof RegExp);
      if (regexRules.some((r) => r.test(path)))
        return v.result;
      const stringRules = v.rules.filter((r) => typeof r === "string");
      if (stringRules.length > 0) {
        const routes = {};
        for (const r of stringRules) {
          if (r === path)
            return v.result;
          routes[r] = true;
        }
        const routeRulesMatcher = toRouteMatcher(createRouter$1({ routes, ...options }));
        if (routeRulesMatcher.matchAll(path).length > 0)
          return Boolean(v.result);
      }
    }
    return include.length === 0;
  };
}

const script = "if (!(\"requestIdleCallback\" in w) || !(\"requestAnimationFrame\" in w))\n  return new Promise((resolve) => resolve(\"not supported\"));\nfunction eventListeners() {\n  const c = new AbortController();\n  const p = new Promise((resolve) => {\n    const hydrateOnEvents = \"mousemove,scroll,keydown,click,touchstart,wheel\".split(\",\");\n    function handler(e) {\n      hydrateOnEvents.forEach((e2) => w.removeEventListener(e2, handler));\n      requestAnimationFrame(() => resolve(e));\n    }\n    hydrateOnEvents.forEach((e) => {\n      w.addEventListener(e, handler, {\n        capture: true,\n        once: true,\n        passive: true,\n        signal: c.signal\n      });\n    });\n  });\n  return { c: () => c.abort(), p };\n}\nfunction idleListener() {\n  let id;\n  const p = new Promise((resolve) => {\n    const isMobile = w.innerWidth < 640;\n    const timeout = isMobile ? Number.parseInt(\"5000\") : Number.parseInt(\"4000\");\n    const timeoutDelay = () => setTimeout(\n      () => requestAnimationFrame(() => resolve(\"timeout\")),\n      timeout\n    );\n    id = w.requestIdleCallback(timeoutDelay, { timeout: Number.parseInt(\"7000\") });\n  });\n  return { c: () => window.cancelIdleCallback(id), p };\n}\nconst triggers = [idleListener(), eventListeners()];\nconst hydrationPromise = Promise.race(\n  triggers.map((t) => t.p)\n).finally(() => {\n  triggers.forEach((t) => t.c());\n});\nreturn hydrationPromise;\n";
const replayScript = "(() => {\n  w._$delayHydration.then((e) => {\n    if (!(e instanceof PointerEvent) && !(e instanceof MouseEvent) && !(window.TouchEvent && e instanceof TouchEvent))\n      return;\n    if (e instanceof MouseEvent && e.type !== \"click\")\n      return;\n    setTimeout(() => w.requestIdleCallback(\n      () => setTimeout(() => e.target?.click(), 500)\n    ), 50);\n  });\n})();\n";
const mode = "mount";
const include = [];
const exclude = ["/_nuxt/**","/api/**"];

function normalizeSiteConfig(config) {
  if (typeof config.indexable !== "undefined")
    config.indexable = String(config.indexable) !== "false";
  if (typeof config.trailingSlash !== "undefined" && !config.trailingSlash)
    config.trailingSlash = String(config.trailingSlash) !== "false";
  if (config.url && !hasProtocol(config.url, { acceptRelative: true, strict: false }))
    config.url = withHttps(config.url);
  const keys = Object.keys(config).sort((a, b) => a.localeCompare(b));
  const newConfig = {};
  for (const k of keys)
    newConfig[k] = config[k];
  return newConfig;
}
function createSiteConfigStack(options) {
  const debug = options?.debug || false;
  const stack = [];
  function push(input) {
    if (!input || typeof input !== "object" || Object.keys(input).length === 0)
      return;
    if (!input._context && debug) {
      let lastFunctionName = new Error("tmp").stack?.split("\n")[2].split(" ")[5];
      if (lastFunctionName?.includes("/"))
        lastFunctionName = "anonymous";
      input._context = lastFunctionName;
    }
    const entry = {};
    for (const k in input) {
      const val = input[k];
      if (typeof val !== "undefined" && val !== "")
        entry[k] = val;
    }
    if (Object.keys(entry).filter((k) => !k.startsWith("_")).length > 0)
      stack.push(entry);
  }
  function get(options2) {
    const siteConfig = {};
    if (options2?.debug)
      siteConfig._context = {};
    for (const o in stack.sort((a, b) => (a._priority || 0) - (b._priority || 0))) {
      for (const k in stack[o]) {
        const key = k;
        const val = options2?.resolveRefs ? toValue(stack[o][k]) : stack[o][k];
        if (!k.startsWith("_") && typeof val !== "undefined") {
          siteConfig[k] = val;
          if (options2?.debug)
            siteConfig._context[key] = stack[o]._context?.[key] || stack[o]._context || "anonymous";
        }
      }
    }
    return options2?.skipNormalize ? siteConfig : normalizeSiteConfig(siteConfig);
  }
  return {
    stack,
    push,
    get
  };
}

function envSiteConfig(env) {
  return Object.fromEntries(Object.entries(env).filter(([k]) => k.startsWith("NUXT_SITE_") || k.startsWith("NUXT_PUBLIC_SITE_")).map(([k, v]) => [
    k.replace(/^NUXT_(PUBLIC_)?SITE_/, "").split("_").map((s, i) => i === 0 ? s.toLowerCase() : s[0].toUpperCase() + s.slice(1).toLowerCase()).join(""),
    v
  ]));
}

function useSiteConfig(e, _options) {
  e.context.siteConfig = e.context.siteConfig || createSiteConfigStack();
  const options = defu(_options, useRuntimeConfig(e)["nuxt-site-config"], { debug: false });
  return e.context.siteConfig.get(options);
}

function useNitroOrigin(e) {
  const cert = process.env.NITRO_SSL_CERT;
  const key = process.env.NITRO_SSL_KEY;
  let host = process.env.NITRO_HOST || process.env.HOST || false;
  let port = false;
  let protocol = cert && key || !false ? "https" : "http";
  if (!e) ; else {
    host = getRequestHost(e, { xForwardedHost: true }) || host;
    protocol = getRequestProtocol(e, { xForwardedProto: true }) || protocol;
  }
  if (typeof host === "string" && host.includes(":")) {
    port = host.split(":").pop();
    host = host.split(":")[0];
  }
  port = port ? `:${port}` : "";
  return `${protocol}://${host}${port}/`;
}

function resolveSitePath(pathOrUrl, options) {
  let path = pathOrUrl;
  if (hasProtocol(pathOrUrl, { strict: false, acceptRelative: true })) {
    const parsed = parseURL(pathOrUrl);
    path = parsed.pathname;
  }
  const base = withLeadingSlash(options.base || "/");
  if (base !== "/" && path.startsWith(base)) {
    path = path.slice(base.length);
  }
  const origin = options.absolute ? options.siteUrl : "";
  const baseWithOrigin = options.withBase ? withBase(base, origin || "/") : origin;
  const resolvedUrl = withBase(path, baseWithOrigin);
  return path === "/" && !options.withBase ? withTrailingSlash(resolvedUrl) : fixSlashes(options.trailingSlash, resolvedUrl);
}
function fixSlashes(trailingSlash, pathOrUrl) {
  const $url = parseURL(pathOrUrl);
  const isFileUrl = $url.pathname.includes(".");
  if (isFileUrl)
    return pathOrUrl;
  const fixedPath = trailingSlash ? withTrailingSlash($url.pathname) : withoutTrailingSlash($url.pathname);
  return `${$url.protocol ? `${$url.protocol}//` : ""}${$url.host || ""}${fixedPath}${$url.search || ""}${$url.hash || ""}`;
}

function createSitePathResolver(e, options = {}) {
  const siteConfig = useSiteConfig(e);
  const nitroOrigin = useNitroOrigin(e);
  const nuxtBase = useRuntimeConfig(e).app.baseURL || "/";
  return (path) => {
    return resolveSitePath(path, {
      ...options,
      siteUrl: options.canonical !== false || false ? siteConfig.url : nitroOrigin,
      trailingSlash: siteConfig.trailingSlash,
      base: nuxtBase
    });
  };
}

function defineNitroPlugin(def) {
  return def;
}

const SCRIPT_REGEX = /<script(.*?)>/gm;
const _k5BvT3aOj0 = defineNitroPlugin$1((nitro) => {
  const filter = createFilter$1({ include, exclude });
  const config = useRuntimeConfig();
  const _routeRulesMatcher = toRouteMatcher(
    createRouter$1({ routes: config.nitro?.routeRules })
  );
  nitro.hooks.hook("render:html", (htmlContext, { event }) => {
    if (!filter(event.path))
      return;
    const routeRules = defu({}, ..._routeRulesMatcher.matchAll(
      withoutBase(event.path.split("?")[0], useRuntimeConfig().app.baseURL)
    ).reverse());
    let currentMode = mode;
    if (typeof routeRules.delayHydration !== "undefined")
      currentMode = routeRules.delayHydration;
    if (!currentMode)
      return;
    let extraScripts = "";
    if (currentMode === "init") {
      const ASSET_RE = new RegExp(`<script[^>]*src="${config.app.buildAssetsDir}[^>]+><\\/script>`);
      const LINK_ASSET_RE = new RegExp(`<link rel="modulepreload" as="script" [^>]*href="${config.app.buildAssetsDir}[^>]+>`, "g");
      htmlContext.head = htmlContext.head.map((head) => head.replaceAll(LINK_ASSET_RE, ""));
      const toLoad = [];
      const isPageSSR = htmlContext.bodyAppend.some((b) => b.includes("$snuxt-delay-hydration-mode"));
      if (!isPageSSR)
        return;
      htmlContext.bodyAppend = htmlContext.bodyAppend.filter(
        (b) => {
          if (b.includes("window.__NUXT__") || !ASSET_RE.test(b))
            return true;
          let match;
          while ((match = SCRIPT_REGEX.exec(b)) !== null) {
            if (match.index === SCRIPT_REGEX.lastIndex)
              SCRIPT_REGEX.lastIndex++;
            if (match)
              toLoad.push(packString(match[1]));
          }
          return false;
        }
      );
      extraScripts = `_$delayHydration.then(e => {
  ;(${JSON.stringify(toLoad)}).forEach(s => {
    const script = document.createElement('script')
    Object.entries(s).forEach(([k, v]) => script.setAttribute(k, v))
    document.body.appendChild(script)
  })
})`;
    }
    extraScripts += `;${replayScript}`;
    htmlContext.bodyAppend.push(`<script>
(function() {
  const w = window;
  w._$delayHydration = (() => {
    ${script}}
  )();
  ${""}
  ${extraScripts}
})();
<\/script>`);
  });
});

const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_$";
const unsafeChars = /[<>\b\f\n\r\t\0\u2028\u2029]/g;
const reserved = /^(?:do|if|in|for|int|let|new|try|var|byte|case|char|else|enum|goto|long|this|void|with|await|break|catch|class|const|final|float|short|super|throw|while|yield|delete|double|export|import|native|return|switch|throws|typeof|boolean|default|extends|finally|package|private|abstract|continue|debugger|function|volatile|interface|protected|transient|implements|instanceof|synchronized)$/;
const escaped = {
  "<": "\\u003C",
  ">": "\\u003E",
  "/": "\\u002F",
  "\\": "\\\\",
  "\b": "\\b",
  "\f": "\\f",
  "\n": "\\n",
  "\r": "\\r",
  "	": "\\t",
  "\0": "\\0",
  "\u2028": "\\u2028",
  "\u2029": "\\u2029"
};
const objectProtoOwnPropertyNames = Object.getOwnPropertyNames(Object.prototype).sort().join("\0");
function devalue(value) {
  const counts = /* @__PURE__ */ new Map();
  let logNum = 0;
  function log(message) {
    if (logNum < 100) {
      console.warn(message);
      logNum += 1;
    }
  }
  function walk(thing) {
    if (typeof thing === "function") {
      log(`Cannot stringify a function ${thing.name}`);
      return;
    }
    if (counts.has(thing)) {
      counts.set(thing, counts.get(thing) + 1);
      return;
    }
    counts.set(thing, 1);
    if (!isPrimitive(thing)) {
      const type = getType(thing);
      switch (type) {
        case "Number":
        case "String":
        case "Boolean":
        case "Date":
        case "RegExp":
          return;
        case "Array":
          thing.forEach(walk);
          break;
        case "Set":
        case "Map":
          Array.from(thing).forEach(walk);
          break;
        default:
          const proto = Object.getPrototypeOf(thing);
          if (proto !== Object.prototype && proto !== null && Object.getOwnPropertyNames(proto).sort().join("\0") !== objectProtoOwnPropertyNames) {
            if (typeof thing.toJSON !== "function") {
              log(`Cannot stringify arbitrary non-POJOs ${thing.constructor.name}`);
            }
          } else if (Object.getOwnPropertySymbols(thing).length > 0) {
            log(`Cannot stringify POJOs with symbolic keys ${Object.getOwnPropertySymbols(thing).map((symbol) => symbol.toString())}`);
          } else {
            Object.keys(thing).forEach((key) => walk(thing[key]));
          }
      }
    }
  }
  walk(value);
  const names = /* @__PURE__ */ new Map();
  Array.from(counts).filter((entry) => entry[1] > 1).sort((a, b) => b[1] - a[1]).forEach((entry, i) => {
    names.set(entry[0], getName(i));
  });
  function stringify(thing) {
    if (names.has(thing)) {
      return names.get(thing);
    }
    if (isPrimitive(thing)) {
      return stringifyPrimitive(thing);
    }
    const type = getType(thing);
    switch (type) {
      case "Number":
      case "String":
      case "Boolean":
        return `Object(${stringify(thing.valueOf())})`;
      case "RegExp":
        return thing.toString();
      case "Date":
        return `new Date(${thing.getTime()})`;
      case "Array":
        const members = thing.map((v, i) => i in thing ? stringify(v) : "");
        const tail = thing.length === 0 || thing.length - 1 in thing ? "" : ",";
        return `[${members.join(",")}${tail}]`;
      case "Set":
      case "Map":
        return `new ${type}([${Array.from(thing).map(stringify).join(",")}])`;
      default:
        if (thing.toJSON) {
          let json = thing.toJSON();
          if (getType(json) === "String") {
            try {
              json = JSON.parse(json);
            } catch (e) {
            }
          }
          return stringify(json);
        }
        if (Object.getPrototypeOf(thing) === null) {
          if (Object.keys(thing).length === 0) {
            return "Object.create(null)";
          }
          return `Object.create(null,{${Object.keys(thing).map((key) => `${safeKey(key)}:{writable:true,enumerable:true,value:${stringify(thing[key])}}`).join(",")}})`;
        }
        return `{${Object.keys(thing).map((key) => `${safeKey(key)}:${stringify(thing[key])}`).join(",")}}`;
    }
  }
  const str = stringify(value);
  if (names.size) {
    const params = [];
    const statements = [];
    const values = [];
    names.forEach((name, thing) => {
      params.push(name);
      if (isPrimitive(thing)) {
        values.push(stringifyPrimitive(thing));
        return;
      }
      const type = getType(thing);
      switch (type) {
        case "Number":
        case "String":
        case "Boolean":
          values.push(`Object(${stringify(thing.valueOf())})`);
          break;
        case "RegExp":
          values.push(thing.toString());
          break;
        case "Date":
          values.push(`new Date(${thing.getTime()})`);
          break;
        case "Array":
          values.push(`Array(${thing.length})`);
          thing.forEach((v, i) => {
            statements.push(`${name}[${i}]=${stringify(v)}`);
          });
          break;
        case "Set":
          values.push("new Set");
          statements.push(`${name}.${Array.from(thing).map((v) => `add(${stringify(v)})`).join(".")}`);
          break;
        case "Map":
          values.push("new Map");
          statements.push(`${name}.${Array.from(thing).map(([k, v]) => `set(${stringify(k)}, ${stringify(v)})`).join(".")}`);
          break;
        default:
          values.push(Object.getPrototypeOf(thing) === null ? "Object.create(null)" : "{}");
          Object.keys(thing).forEach((key) => {
            statements.push(`${name}${safeProp(key)}=${stringify(thing[key])}`);
          });
      }
    });
    statements.push(`return ${str}`);
    return `(function(${params.join(",")}){${statements.join(";")}}(${values.join(",")}))`;
  } else {
    return str;
  }
}
function getName(num) {
  let name = "";
  do {
    name = chars[num % chars.length] + name;
    num = ~~(num / chars.length) - 1;
  } while (num >= 0);
  return reserved.test(name) ? `${name}0` : name;
}
function isPrimitive(thing) {
  return Object(thing) !== thing;
}
function stringifyPrimitive(thing) {
  if (typeof thing === "string") {
    return stringifyString(thing);
  }
  if (thing === void 0) {
    return "void 0";
  }
  if (thing === 0 && 1 / thing < 0) {
    return "-0";
  }
  const str = String(thing);
  if (typeof thing === "number") {
    return str.replace(/^(-)?0\./, "$1.");
  }
  return str;
}
function getType(thing) {
  return Object.prototype.toString.call(thing).slice(8, -1);
}
function escapeUnsafeChar(c) {
  return escaped[c] || c;
}
function escapeUnsafeChars(str) {
  return str.replace(unsafeChars, escapeUnsafeChar);
}
function safeKey(key) {
  return /^[_$a-zA-Z][_$a-zA-Z0-9]*$/.test(key) ? key : escapeUnsafeChars(JSON.stringify(key));
}
function safeProp(key) {
  return /^[_$a-zA-Z][_$a-zA-Z0-9]*$/.test(key) ? `.${key}` : `[${escapeUnsafeChars(JSON.stringify(key))}]`;
}
function stringifyString(str) {
  let result = '"';
  for (let i = 0; i < str.length; i += 1) {
    const char = str.charAt(i);
    const code = char.charCodeAt(0);
    if (char === '"') {
      result += '\\"';
    } else if (char in escaped) {
      result += escaped[char];
    } else if (code >= 55296 && code <= 57343) {
      const next = str.charCodeAt(i + 1);
      if (code <= 56319 && (next >= 56320 && next <= 57343)) {
        result += char + str[++i];
      } else {
        result += `\\u${code.toString(16).toUpperCase()}`;
      }
    } else {
      result += char;
    }
  }
  result += '"';
  return result;
}

const _GKplefXilg = defineNitroPlugin(async (nitroApp) => {
  nitroApp.hooks.hook("render:html", async (ctx, { event }) => {
    const routeOptions = getRouteRules(event);
    const isIsland = false ;
    event.path;
    const noSSR = event.context.nuxt?.noSSR || routeOptions.ssr === false && !isIsland || (false);
    if (noSSR) {
      const siteConfig = Object.fromEntries(
        Object.entries(useSiteConfig(event)).map(([k, v]) => [k, toValue(v)])
      );
      ctx.body.push(`<script>window.__NUXT_SITE_CONFIG__=${devalue(siteConfig)}<\/script>`);
    }
  });
});

const plugins = [
  _k5BvT3aOj0,
_GKplefXilg
];

const errorHandler = (async function errorhandler(error, event) {
  const { stack, statusCode, statusMessage, message } = normalizeError(error);
  const errorObject = {
    url: event.path,
    statusCode,
    statusMessage,
    message,
    stack: "",
    // TODO: check and validate error.data for serialisation into query
    data: error.data
  };
  if (error.unhandled || error.fatal) {
    const tags = [
      "[nuxt]",
      "[request error]",
      error.unhandled && "[unhandled]",
      error.fatal && "[fatal]",
      Number(errorObject.statusCode) !== 200 && `[${errorObject.statusCode}]`
    ].filter(Boolean).join(" ");
    console.error(tags, errorObject.message + "\n" + stack.map((l) => "  " + l.text).join("  \n"));
  }
  if (event.handled) {
    return;
  }
  setResponseStatus(event, errorObject.statusCode !== 200 && errorObject.statusCode || 500, errorObject.statusMessage);
  if (isJsonRequest(event)) {
    setResponseHeader(event, "Content-Type", "application/json");
    return send(event, JSON.stringify(errorObject));
  }
  const reqHeaders = getRequestHeaders(event);
  const isRenderingError = event.path.startsWith("/__nuxt_error") || !!reqHeaders["x-nuxt-error"];
  const res = isRenderingError ? null : await useNitroApp().localFetch(
    withQuery(joinURL(useRuntimeConfig().app.baseURL, "/__nuxt_error"), errorObject),
    {
      headers: { ...reqHeaders, "x-nuxt-error": "true" },
      redirect: "manual"
    }
  ).catch(() => null);
  if (!res) {
    const { template } = await import('../error-500.mjs');
    if (event.handled) {
      return;
    }
    setResponseHeader(event, "Content-Type", "text/html;charset=UTF-8");
    return send(event, template(errorObject));
  }
  const html = await res.text();
  if (event.handled) {
    return;
  }
  for (const [header, value] of res.headers.entries()) {
    setResponseHeader(event, header, value);
  }
  setResponseStatus(event, res.status && res.status !== 200 ? res.status : void 0, res.statusText);
  return send(event, html);
});

const assets = {
  "/keshmed-logo-cut.png": {
    "type": "image/png",
    "etag": "\"17c2e-6++0svIjqbqyn8LIvOO3pICHB/E\"",
    "mtime": "2024-02-02T04:18:49.349Z",
    "size": 97326,
    "path": "../public/keshmed-logo-cut.png"
  },
  "/keshmed-logo.png": {
    "type": "image/png",
    "etag": "\"ce44-byTyp5VfZSebeQegyfQaqavXd8c\"",
    "mtime": "2024-02-03T05:04:23.231Z",
    "size": 52804,
    "path": "../public/keshmed-logo.png"
  },
  "/keshmed.svg": {
    "type": "image/svg+xml",
    "etag": "\"c72-+ZG+BgHBHoVuC1D4Bh/0vLN10pI\"",
    "mtime": "2024-01-26T12:19:55.778Z",
    "size": 3186,
    "path": "../public/keshmed.svg"
  },
  "/login-logo.jpg": {
    "type": "image/jpeg",
    "etag": "\"d0b1-T/NoUNyNt/ybJ331bqBOtKotESU\"",
    "mtime": "2024-01-31T09:40:05.928Z",
    "size": 53425,
    "path": "../public/login-logo.jpg"
  },
  "/logo-ico.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"4203e-zT//lPmh14gy5/jRMXkGxCIcWjs\"",
    "mtime": "2024-01-30T11:35:24.820Z",
    "size": 270398,
    "path": "../public/logo-ico.ico"
  },
  "/logo-white.png": {
    "type": "image/png",
    "etag": "\"5222-03N8AssbEM9o1ePLbS+XC37oAUY\"",
    "mtime": "2024-01-27T17:46:46.019Z",
    "size": 21026,
    "path": "../public/logo-white.png"
  },
  "/logo.jpg": {
    "type": "image/jpeg",
    "etag": "\"d377-lGpn9aDbn091kLxUGG39JylBYeY\"",
    "mtime": "2024-01-26T09:45:09.954Z",
    "size": 54135,
    "path": "../public/logo.jpg"
  },
  "/logo1.jpg": {
    "type": "image/jpeg",
    "etag": "\"9fb5-vDXYe66ruFy0wij3RxItakL0ec8\"",
    "mtime": "2024-01-26T09:42:09.715Z",
    "size": 40885,
    "path": "../public/logo1.jpg"
  },
  "/carousel/image-1.jpg": {
    "type": "image/jpeg",
    "etag": "\"d49e-ueULy56Pbj0cLs7O0Ro8uzKYO+c\"",
    "mtime": "2024-01-15T13:44:52.573Z",
    "size": 54430,
    "path": "../public/carousel/image-1.jpg"
  },
  "/carousel/image-2.jpg": {
    "type": "image/jpeg",
    "etag": "\"144370-nJgfzlbFM8JZkV7eW5vN8/8Atrw\"",
    "mtime": "2024-01-15T13:44:52.599Z",
    "size": 1327984,
    "path": "../public/carousel/image-2.jpg"
  },
  "/carousel/image-3.jpg": {
    "type": "image/jpeg",
    "etag": "\"10e2f6-Q/6a8yYWOJfFiZZBQ427GEkFy1M\"",
    "mtime": "2024-01-15T13:44:52.621Z",
    "size": 1106678,
    "path": "../public/carousel/image-3.jpg"
  },
  "/carousel/image-4.jpg": {
    "type": "image/jpeg",
    "etag": "\"10401-rWEHjVazfyDXy1p/OwEmhoJmPCg\"",
    "mtime": "2024-01-15T13:44:52.636Z",
    "size": 66561,
    "path": "../public/carousel/image-4.jpg"
  },
  "/images/nophoto.jpg": {
    "type": "image/jpeg",
    "etag": "\"1d80-/dUPKKQYSbleRJa0nndm/gEJZkE\"",
    "mtime": "2024-01-06T12:18:40.687Z",
    "size": 7552,
    "path": "../public/images/nophoto.jpg"
  },
  "/flag/ad.svg": {
    "type": "image/svg+xml",
    "etag": "\"84b4-hYipFko7xlM7gzhEJr/2v0reHYQ\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 33972,
    "path": "../public/flag/ad.svg"
  },
  "/flag/ae.svg": {
    "type": "image/svg+xml",
    "etag": "\"101-etRpZ6UpJ5xxmF7KjGHuVYW8I0A\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 257,
    "path": "../public/flag/ae.svg"
  },
  "/flag/af.svg": {
    "type": "image/svg+xml",
    "etag": "\"531f-evDZNWUfhGh0LMgHGxorDPNbxj0\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 21279,
    "path": "../public/flag/af.svg"
  },
  "/flag/ag.svg": {
    "type": "image/svg+xml",
    "etag": "\"2ec-rBzCUU8LcrbJ4vr6z6e37hXAyoo\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 748,
    "path": "../public/flag/ag.svg"
  },
  "/flag/ai.svg": {
    "type": "image/svg+xml",
    "etag": "\"a4e0-JxqT+YQ+ZCh6ODA8LxdOKvBZMKA\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 42208,
    "path": "../public/flag/ai.svg"
  },
  "/flag/al.svg": {
    "type": "image/svg+xml",
    "etag": "\"c95-8JEsxvlu7wzaf1UsrNsXHKYxq6w\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 3221,
    "path": "../public/flag/al.svg"
  },
  "/flag/am.svg": {
    "type": "image/svg+xml",
    "etag": "\"e2-lqBJPNu5PJnQEiGA+Q8rx22ykTk\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 226,
    "path": "../public/flag/am.svg"
  },
  "/flag/ao.svg": {
    "type": "image/svg+xml",
    "etag": "\"648-WGNRZYhVKvCGiKBAUQuIhQygRBo\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1608,
    "path": "../public/flag/ao.svg"
  },
  "/flag/aq.svg": {
    "type": "image/svg+xml",
    "etag": "\"b9e-m2CSFz6ycQg+UYZqjCY5LEGkzSc\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 2974,
    "path": "../public/flag/aq.svg"
  },
  "/flag/ar.svg": {
    "type": "image/svg+xml",
    "etag": "\"d66-wLLZiNPOxLnipzF6C58W3EJBBnc\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 3430,
    "path": "../public/flag/ar.svg"
  },
  "/flag/as.svg": {
    "type": "image/svg+xml",
    "etag": "\"1fa2-dk55mDQNayelCPXtOzM060GBlkE\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 8098,
    "path": "../public/flag/as.svg"
  },
  "/flag/at.svg": {
    "type": "image/svg+xml",
    "etag": "\"f3-Mn5gDOjrnEMSr0XiTCJiSXDCnkI\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 243,
    "path": "../public/flag/at.svg"
  },
  "/flag/au.svg": {
    "type": "image/svg+xml",
    "etag": "\"537-iQ7RJRaCemNVWhDXCPBq5p0sXQY\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1335,
    "path": "../public/flag/au.svg"
  },
  "/flag/aw.svg": {
    "type": "image/svg+xml",
    "etag": "\"26dc-R5pB6E1mMgkiT+53hedHGD2aaSI\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 9948,
    "path": "../public/flag/aw.svg"
  },
  "/flag/ax.svg": {
    "type": "image/svg+xml",
    "etag": "\"22c-Ln8W5GpR4iCuXUR/YgR+CqR0EVI\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 556,
    "path": "../public/flag/ax.svg"
  },
  "/flag/az.svg": {
    "type": "image/svg+xml",
    "etag": "\"203-GO7jiGInyB0FRTTXSISsw8YZqvs\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 515,
    "path": "../public/flag/az.svg"
  },
  "/flag/ba.svg": {
    "type": "image/svg+xml",
    "etag": "\"51a-p9SxRh3nDJqF6NLSL7yD5QEWXEA\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1306,
    "path": "../public/flag/ba.svg"
  },
  "/flag/bb.svg": {
    "type": "image/svg+xml",
    "etag": "\"265-7k0PsC/qKqDxKSXHaODUAQQSXuA\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 613,
    "path": "../public/flag/bb.svg"
  },
  "/flag/bd.svg": {
    "type": "image/svg+xml",
    "etag": "\"c1-Br5fK77DLbNfPul7b4Q2YDOvOsw\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 193,
    "path": "../public/flag/bd.svg"
  },
  "/flag/be.svg": {
    "type": "image/svg+xml",
    "etag": "\"125-OleM9HvSbY8czN/Dfm+75HOnYgY\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 293,
    "path": "../public/flag/be.svg"
  },
  "/flag/bf.svg": {
    "type": "image/svg+xml",
    "etag": "\"168-OHDUqWeCsIVUu4GceRBhZuCCu68\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 360,
    "path": "../public/flag/bf.svg"
  },
  "/flag/bg.svg": {
    "type": "image/svg+xml",
    "etag": "\"121-ytwi0pTyKeJMxuNsNH6yqSJQ6SU\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 289,
    "path": "../public/flag/bg.svg"
  },
  "/flag/bh.svg": {
    "type": "image/svg+xml",
    "etag": "\"222-mF8VxeB3EuFvaGgg3tTI9F6svms\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 546,
    "path": "../public/flag/bh.svg"
  },
  "/flag/bi.svg": {
    "type": "image/svg+xml",
    "etag": "\"432-7t1qFvMxeKTnMAAsiQL1oTiyAbM\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1074,
    "path": "../public/flag/bi.svg"
  },
  "/flag/bj.svg": {
    "type": "image/svg+xml",
    "etag": "\"1f3-bcNN851xciO2C6VwFyJrx029ulM\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 499,
    "path": "../public/flag/bj.svg"
  },
  "/flag/bl.svg": {
    "type": "image/svg+xml",
    "etag": "\"127-zaB8yv+pvBiPm1mGoOURWVr3tVE\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 295,
    "path": "../public/flag/bl.svg"
  },
  "/flag/bm.svg": {
    "type": "image/svg+xml",
    "etag": "\"587a-isHzIOPqeTQqxxhbi6xRiCNUulI\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 22650,
    "path": "../public/flag/bm.svg"
  },
  "/flag/bn.svg": {
    "type": "image/svg+xml",
    "etag": "\"3833-+BwdnZtJgNLoPIxQZNSJui838rI\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 14387,
    "path": "../public/flag/bn.svg"
  },
  "/flag/bo.svg": {
    "type": "image/svg+xml",
    "etag": "\"1ce00-HbVBt0OOS9VhlMMOAGtTdIY3Qqg\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 118272,
    "path": "../public/flag/bo.svg"
  },
  "/flag/bq.svg": {
    "type": "image/svg+xml",
    "etag": "\"e3-II8RS8Kt+rXrMGqC1OnU6579UoA\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 227,
    "path": "../public/flag/bq.svg"
  },
  "/flag/br.svg": {
    "type": "image/svg+xml",
    "etag": "\"2034-dh9Qt6uXulIssC88I/Am2ACeH50\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 8244,
    "path": "../public/flag/br.svg"
  },
  "/flag/bs.svg": {
    "type": "image/svg+xml",
    "etag": "\"225-dy/27ancgVhTxtJLXgpALuMGoqQ\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 549,
    "path": "../public/flag/bs.svg"
  },
  "/flag/bt.svg": {
    "type": "image/svg+xml",
    "etag": "\"6301-vfEIh2fMgojNy0L7dffILonXp7Q\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 25345,
    "path": "../public/flag/bt.svg"
  },
  "/flag/bv.svg": {
    "type": "image/svg+xml",
    "etag": "\"246-Hi3sSFn4aBcfDv9HnpV11N/QLh4\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 582,
    "path": "../public/flag/bv.svg"
  },
  "/flag/bw.svg": {
    "type": "image/svg+xml",
    "etag": "\"ff-QctFhDpxtl3nSA6iw6yL8uw4v/k\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 255,
    "path": "../public/flag/bw.svg"
  },
  "/flag/by.svg": {
    "type": "image/svg+xml",
    "etag": "\"176e-fyU/6YFyfz+E5T8cmVAxHyXU8Ng\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 5998,
    "path": "../public/flag/by.svg"
  },
  "/flag/bz.svg": {
    "type": "image/svg+xml",
    "etag": "\"b744-vQvdHKw6KF9Jb8A/yA2CR1lMn1w\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 46916,
    "path": "../public/flag/bz.svg"
  },
  "/flag/ca.svg": {
    "type": "image/svg+xml",
    "etag": "\"2db-iHjEnHUpDW0BSwabngrxd7lyjno\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 731,
    "path": "../public/flag/ca.svg"
  },
  "/flag/cc.svg": {
    "type": "image/svg+xml",
    "etag": "\"c48-2HZ4PE1I+jBMEIPAHVBk+RKHlBA\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 3144,
    "path": "../public/flag/cc.svg"
  },
  "/flag/cd.svg": {
    "type": "image/svg+xml",
    "etag": "\"160-03NoTuC2iU1DPugQSPVqqp747FY\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 352,
    "path": "../public/flag/cd.svg"
  },
  "/flag/cf.svg": {
    "type": "image/svg+xml",
    "etag": "\"2b1-SPRafINglEzJHNem+6j575lzxB0\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 689,
    "path": "../public/flag/cf.svg"
  },
  "/flag/cg.svg": {
    "type": "image/svg+xml",
    "etag": "\"1e4-xL9qN3M8F9PiB908EhJWLi00Flo\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 484,
    "path": "../public/flag/cg.svg"
  },
  "/flag/ch.svg": {
    "type": "image/svg+xml",
    "etag": "\"12c-NMgX7TKYonB0aXRhOWFKHDZWNZ0\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 300,
    "path": "../public/flag/ch.svg"
  },
  "/flag/ci.svg": {
    "type": "image/svg+xml",
    "etag": "\"11b-R8AbHqrJ0faHGBrzM6ncc9LW7Eg\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 283,
    "path": "../public/flag/ci.svg"
  },
  "/flag/ck.svg": {
    "type": "image/svg+xml",
    "etag": "\"75f-Bc7FCLhU72+e7yVGvDbxqUiTup8\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1887,
    "path": "../public/flag/ck.svg"
  },
  "/flag/cl.svg": {
    "type": "image/svg+xml",
    "etag": "\"230-CI3tHrzJZJ4/WOGs3G3Nq1iLGYY\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 560,
    "path": "../public/flag/cl.svg"
  },
  "/flag/cm.svg": {
    "type": "image/svg+xml",
    "etag": "\"33b-TWdGwCU+/h5vZcy0OksgB/kG9tk\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 827,
    "path": "../public/flag/cm.svg"
  },
  "/flag/cn.svg": {
    "type": "image/svg+xml",
    "etag": "\"324-B4JLt8cFwZq6iIWPb9F6UeCiK78\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 804,
    "path": "../public/flag/cn.svg"
  },
  "/flag/co.svg": {
    "type": "image/svg+xml",
    "etag": "\"124-ETVqDz7/xJU28hVXJCGJ/Jgs/TI\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 292,
    "path": "../public/flag/co.svg"
  },
  "/flag/cr.svg": {
    "type": "image/svg+xml",
    "etag": "\"128-njemhOlJt5ONrLqouep0smRNIvI\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 296,
    "path": "../public/flag/cr.svg"
  },
  "/flag/cu.svg": {
    "type": "image/svg+xml",
    "etag": "\"26b-CS4+uJXMcxb96PpYvZ7z4Xc4Alw\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 619,
    "path": "../public/flag/cu.svg"
  },
  "/flag/cv.svg": {
    "type": "image/svg+xml",
    "etag": "\"586-lRO6zLJ9hOVlS1X0abyyqt6SVn8\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1414,
    "path": "../public/flag/cv.svg"
  },
  "/flag/cw.svg": {
    "type": "image/svg+xml",
    "etag": "\"2a6-0rKOpxoYgc06Yo1Qg8adonWfqVc\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 678,
    "path": "../public/flag/cw.svg"
  },
  "/flag/cx.svg": {
    "type": "image/svg+xml",
    "etag": "\"9a5-4P+IdonGM1WqN3+BoJ+ehqed1UE\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 2469,
    "path": "../public/flag/cx.svg"
  },
  "/flag/cy.svg": {
    "type": "image/svg+xml",
    "etag": "\"173d-jWtEJmB5uk8AwiCR7xmhpnoE1ZQ\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 5949,
    "path": "../public/flag/cy.svg"
  },
  "/flag/cz.svg": {
    "type": "image/svg+xml",
    "etag": "\"1e1-oM4o7lNLRl1AL/bx/ruUSuArEn0\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 481,
    "path": "../public/flag/cz.svg"
  },
  "/flag/de.svg": {
    "type": "image/svg+xml",
    "etag": "\"d8-kGHg60kFQXp68RQ5oVzqyl7mms0\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 216,
    "path": "../public/flag/de.svg"
  },
  "/flag/dj.svg": {
    "type": "image/svg+xml",
    "etag": "\"24c-8W8n1Cov3PhhvgD27/ak31pBp6Y\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 588,
    "path": "../public/flag/dj.svg"
  },
  "/flag/dk.svg": {
    "type": "image/svg+xml",
    "etag": "\"f2-OJgdCzEC5TIBc6S+CztAKMaAngk\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 242,
    "path": "../public/flag/dk.svg"
  },
  "/flag/dm.svg": {
    "type": "image/svg+xml",
    "etag": "\"3e9a-W21BfbHVp3/Qa+5VnUlo1FJh5JY\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 16026,
    "path": "../public/flag/dm.svg"
  },
  "/flag/do.svg": {
    "type": "image/svg+xml",
    "etag": "\"603a2-zVWiEPIcqJEYzCQYBcrQMLXEE8o\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 394146,
    "path": "../public/flag/do.svg"
  },
  "/flag/dz.svg": {
    "type": "image/svg+xml",
    "etag": "\"12d-UcNn++PDqwNbq8YRA5SnwRIxSqE\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 301,
    "path": "../public/flag/dz.svg"
  },
  "/flag/ec.svg": {
    "type": "image/svg+xml",
    "etag": "\"72e9-GdwdPasfQZujK8w4optQcThc3ts\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 29417,
    "path": "../public/flag/ec.svg"
  },
  "/flag/ee.svg": {
    "type": "image/svg+xml",
    "etag": "\"144-cCByNJX8aNf3+5BWdURhRVbkijE\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 324,
    "path": "../public/flag/ee.svg"
  },
  "/flag/eg.svg": {
    "type": "image/svg+xml",
    "etag": "\"26fa-/watjxV7mtU3auz0X0uX08DGs0A\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 9978,
    "path": "../public/flag/eg.svg"
  },
  "/flag/eh.svg": {
    "type": "image/svg+xml",
    "etag": "\"36e-BxO0qdaRiFJb9mS10p7BN6+82zM\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 878,
    "path": "../public/flag/eh.svg"
  },
  "/flag/er.svg": {
    "type": "image/svg+xml",
    "etag": "\"c87-wHBKx/RzvQ9EuGAN08JAt4jUvZo\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 3207,
    "path": "../public/flag/er.svg"
  },
  "/flag/es-ct.svg": {
    "type": "image/svg+xml",
    "etag": "\"105-lAcI+AowfO0/FhkhrtrXgyyFvCk\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 261,
    "path": "../public/flag/es-ct.svg"
  },
  "/flag/es.svg": {
    "type": "image/svg+xml",
    "etag": "\"1699e-lCpaN9NFXnDKm2s3ENOjK2sTeCI\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 92574,
    "path": "../public/flag/es.svg"
  },
  "/flag/et.svg": {
    "type": "image/svg+xml",
    "etag": "\"4db-nowen6aSAU/zcmlVGE98USRRv/w\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1243,
    "path": "../public/flag/et.svg"
  },
  "/flag/eu.svg": {
    "type": "image/svg+xml",
    "etag": "\"4e4-5ZT3ltdhSX7NyEQIpb7/Zr0KqJ0\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1252,
    "path": "../public/flag/eu.svg"
  },
  "/flag/fi.svg": {
    "type": "image/svg+xml",
    "etag": "\"f0-aLxRnrzJuuN0DQak/XuO53EHD80\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 240,
    "path": "../public/flag/fi.svg"
  },
  "/flag/fj.svg": {
    "type": "image/svg+xml",
    "etag": "\"6afc-HnGXx6lgiT6Wb91yUi4frSxqfS0\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 27388,
    "path": "../public/flag/fj.svg"
  },
  "/flag/fk.svg": {
    "type": "image/svg+xml",
    "etag": "\"76f5-tZZKTxqrEX2A0XM4C1NBrTAeY+A\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 30453,
    "path": "../public/flag/fk.svg"
  },
  "/flag/fm.svg": {
    "type": "image/svg+xml",
    "etag": "\"305-+NuVIFllnzNOvouROurXK10Q+xY\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 773,
    "path": "../public/flag/fm.svg"
  },
  "/flag/fo.svg": {
    "type": "image/svg+xml",
    "etag": "\"237-N/TmBVLK27czTK3iZ3NrNfKvQEI\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 567,
    "path": "../public/flag/fo.svg"
  },
  "/flag/fr.svg": {
    "type": "image/svg+xml",
    "etag": "\"127-3R539yiryg5d/9HdIl5wDSBbRfc\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 295,
    "path": "../public/flag/fr.svg"
  },
  "/flag/ga.svg": {
    "type": "image/svg+xml",
    "etag": "\"115-VNWSaHYrJ9TfD1Ms/CTPl/Hm4Z4\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 277,
    "path": "../public/flag/ga.svg"
  },
  "/flag/gb-eng.svg": {
    "type": "image/svg+xml",
    "etag": "\"f5-LRLNWvWwSYSL0KdDzaH28huXLis\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 245,
    "path": "../public/flag/gb-eng.svg"
  },
  "/flag/gb-nir.svg": {
    "type": "image/svg+xml",
    "etag": "\"5cba-PHk+R4H6ifA08QJXisBdLL65I3Q\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 23738,
    "path": "../public/flag/gb-nir.svg"
  },
  "/flag/gb-sct.svg": {
    "type": "image/svg+xml",
    "etag": "\"ea-pWtbgrBqhSh8l8Qpb+gbXwwd4zs\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 234,
    "path": "../public/flag/gb-sct.svg"
  },
  "/flag/gb-wls.svg": {
    "type": "image/svg+xml",
    "etag": "\"23e4-OFyX29ZnsvovBi+pxxwb2cMxnTk\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 9188,
    "path": "../public/flag/gb-wls.svg"
  },
  "/flag/gb.svg": {
    "type": "image/svg+xml",
    "etag": "\"342-BeMlwm91J/PuuVfuX0JjGPRLXmc\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 834,
    "path": "../public/flag/gb.svg"
  },
  "/flag/gd.svg": {
    "type": "image/svg+xml",
    "etag": "\"69e-59XhW+2CG5Hr5aTqlNV6SNu5K3I\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1694,
    "path": "../public/flag/gd.svg"
  },
  "/flag/ge.svg": {
    "type": "image/svg+xml",
    "etag": "\"578-B+Ewy0jBV8V/kSc4biQcsVMjnTs\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1400,
    "path": "../public/flag/ge.svg"
  },
  "/flag/gf.svg": {
    "type": "image/svg+xml",
    "etag": "\"105-dfLmaW9jSIwnifZLz8P36B8WXw4\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 261,
    "path": "../public/flag/gf.svg"
  },
  "/flag/gg.svg": {
    "type": "image/svg+xml",
    "etag": "\"256-Pi0OwHTDQeqPv6UkAphDKUJQ6Os\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 598,
    "path": "../public/flag/gg.svg"
  },
  "/flag/gh.svg": {
    "type": "image/svg+xml",
    "etag": "\"11e-L9j1PPVAEW4v/aFtpNEmmOwCv0k\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 286,
    "path": "../public/flag/gh.svg"
  },
  "/flag/gi.svg": {
    "type": "image/svg+xml",
    "etag": "\"b9c-RllDjvsS5L4m8ukx52sPC/tM2Hg\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 2972,
    "path": "../public/flag/gi.svg"
  },
  "/flag/gl.svg": {
    "type": "image/svg+xml",
    "etag": "\"e5-9bbfk2iNjUdHc9OsleRe7pQEOhA\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 229,
    "path": "../public/flag/gl.svg"
  },
  "/flag/gm.svg": {
    "type": "image/svg+xml",
    "etag": "\"21f-wpgZeACkuDWbVxDB9GLnwHr8XsA\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 543,
    "path": "../public/flag/gm.svg"
  },
  "/flag/gn.svg": {
    "type": "image/svg+xml",
    "etag": "\"12a-2rr4NP8/YwG+wlxd8+WkSAiQMvM\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 298,
    "path": "../public/flag/gn.svg"
  },
  "/flag/gp.svg": {
    "type": "image/svg+xml",
    "etag": "\"127-PSC9ru83lOenn4CBrqw0tegK/+w\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 295,
    "path": "../public/flag/gp.svg"
  },
  "/flag/gq.svg": {
    "type": "image/svg+xml",
    "etag": "\"1444-tZVZ6c5GKa7AUkqCFYAAgIYC8DA\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 5188,
    "path": "../public/flag/gq.svg"
  },
  "/flag/gr.svg": {
    "type": "image/svg+xml",
    "etag": "\"332-EEgQvRl3bBvSLrnkmIgl0c6j7w4\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 818,
    "path": "../public/flag/gr.svg"
  },
  "/flag/gs.svg": {
    "type": "image/svg+xml",
    "etag": "\"8762-3lIkvZufImOjBMebCkU3UAWgHSE\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 34658,
    "path": "../public/flag/gs.svg"
  },
  "/flag/gt.svg": {
    "type": "image/svg+xml",
    "etag": "\"93e1-o/nL4m7W2CWvu1LHauzEEogocQY\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 37857,
    "path": "../public/flag/gt.svg"
  },
  "/flag/gu.svg": {
    "type": "image/svg+xml",
    "etag": "\"12fb-2zQA+6j7KGtolq2TnvMjb0w7OIU\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 4859,
    "path": "../public/flag/gu.svg"
  },
  "/flag/gw.svg": {
    "type": "image/svg+xml",
    "etag": "\"330-F2ywViRCVoHuGgni2IgG9C8KuNY\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 816,
    "path": "../public/flag/gw.svg"
  },
  "/flag/gy.svg": {
    "type": "image/svg+xml",
    "etag": "\"1eb-7usl7bIcFkE3w5prwi4O5E3UNik\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 491,
    "path": "../public/flag/gy.svg"
  },
  "/flag/hk.svg": {
    "type": "image/svg+xml",
    "etag": "\"db7-jzMWfNZkCVS5dKpAsycraqgZ/uY\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 3511,
    "path": "../public/flag/hk.svg"
  },
  "/flag/hm.svg": {
    "type": "image/svg+xml",
    "etag": "\"530-TAvI1tLiwRo+LGuB5fNL4Q/DjOw\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1328,
    "path": "../public/flag/hm.svg"
  },
  "/flag/hn.svg": {
    "type": "image/svg+xml",
    "etag": "\"45b-gMQmroZMAhm0R2PQNZUbEuGU7rk\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1115,
    "path": "../public/flag/hn.svg"
  },
  "/flag/hr.svg": {
    "type": "image/svg+xml",
    "etag": "\"a291-6wG9Y6sDciQNDLsJ5TGfD3vWGj4\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 41617,
    "path": "../public/flag/hr.svg"
  },
  "/flag/ht.svg": {
    "type": "image/svg+xml",
    "etag": "\"3b7f-4sNEvaEZNjp//KRIMvCcekvwc6w\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 15231,
    "path": "../public/flag/ht.svg"
  },
  "/flag/hu.svg": {
    "type": "image/svg+xml",
    "etag": "\"115-clc6uzrmqPjJaQDUyjNr4AxDfos\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 277,
    "path": "../public/flag/hu.svg"
  },
  "/flag/id.svg": {
    "type": "image/svg+xml",
    "etag": "\"f0-UkpnklEA2ZwRiSNTpXGpflYWIjI\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 240,
    "path": "../public/flag/id.svg"
  },
  "/flag/ie.svg": {
    "type": "image/svg+xml",
    "etag": "\"127-GbjIBWDngDmI9WxMlyGECRsVYzU\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 295,
    "path": "../public/flag/ie.svg"
  },
  "/flag/il.svg": {
    "type": "image/svg+xml",
    "etag": "\"382-tIMxgXM2U7FPdaQZ4F2YDnik624\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 898,
    "path": "../public/flag/il.svg"
  },
  "/flag/im.svg": {
    "type": "image/svg+xml",
    "etag": "\"26dc-n9Ui1zgo0mA6HI/A3XFMdI3NMoM\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 9948,
    "path": "../public/flag/im.svg"
  },
  "/flag/in.svg": {
    "type": "image/svg+xml",
    "etag": "\"435-36I75AEBTaetZUS41ULbl8Rc3T0\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1077,
    "path": "../public/flag/in.svg"
  },
  "/flag/io.svg": {
    "type": "image/svg+xml",
    "etag": "\"6b36-56oP5l+gX6TF/yrGsUQPC2ZdI/A\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 27446,
    "path": "../public/flag/io.svg"
  },
  "/flag/iq.svg": {
    "type": "image/svg+xml",
    "etag": "\"5c7-+S/tViCqaAuKLUzW3zFhSfJ64Sw\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1479,
    "path": "../public/flag/iq.svg"
  },
  "/flag/ir.svg": {
    "type": "image/svg+xml",
    "etag": "\"3c7c-ZUw7bu6t01m/MukoPjlGpAUvhk8\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 15484,
    "path": "../public/flag/ir.svg"
  },
  "/flag/is.svg": {
    "type": "image/svg+xml",
    "etag": "\"209-FR1q8qO+YagmsQdbeHiux5uzaEY\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 521,
    "path": "../public/flag/is.svg"
  },
  "/flag/it.svg": {
    "type": "image/svg+xml",
    "etag": "\"127-jxH0E9sHeHc1cN3tZzx5ySJcMdo\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 295,
    "path": "../public/flag/it.svg"
  },
  "/flag/je.svg": {
    "type": "image/svg+xml",
    "etag": "\"12a8-F4yb+NukcLvVI5DY95q8H43puhI\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 4776,
    "path": "../public/flag/je.svg"
  },
  "/flag/jm.svg": {
    "type": "image/svg+xml",
    "etag": "\"188-WTBJI99Dbg8mrVySEugMUW87uKg\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 392,
    "path": "../public/flag/jm.svg"
  },
  "/flag/jo.svg": {
    "type": "image/svg+xml",
    "etag": "\"2cd-aYDwB8OY/1h7ybSK5n5E0ecEpAU\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 717,
    "path": "../public/flag/jo.svg"
  },
  "/flag/jp.svg": {
    "type": "image/svg+xml",
    "etag": "\"1e4-zyhLiIBQPschQE7lGI/N2M/S8wk\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 484,
    "path": "../public/flag/jp.svg"
  },
  "/flag/ke.svg": {
    "type": "image/svg+xml",
    "etag": "\"567-43+FMiQHlfncoLji/cMLqdXyYQw\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1383,
    "path": "../public/flag/ke.svg"
  },
  "/flag/kg.svg": {
    "type": "image/svg+xml",
    "etag": "\"d3b-QRjHxeeOnR1zy3U9mA08MoeJztM\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 3387,
    "path": "../public/flag/kg.svg"
  },
  "/flag/kh.svg": {
    "type": "image/svg+xml",
    "etag": "\"1c7f-a1QUsR0MMy/XedvgFIeGZmSkF30\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 7295,
    "path": "../public/flag/kh.svg"
  },
  "/flag/ki.svg": {
    "type": "image/svg+xml",
    "etag": "\"16ba-IZQAXrOz4udYSRyFSbh/sZgwacI\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 5818,
    "path": "../public/flag/ki.svg"
  },
  "/flag/km.svg": {
    "type": "image/svg+xml",
    "etag": "\"425-ByZiWGICOorEzsEQZ+PZglM5VYE\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1061,
    "path": "../public/flag/km.svg"
  },
  "/flag/kn.svg": {
    "type": "image/svg+xml",
    "etag": "\"330-jb8dGEWR5D+ZBO1VrWnFiWvXOhE\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 816,
    "path": "../public/flag/kn.svg"
  },
  "/flag/kp.svg": {
    "type": "image/svg+xml",
    "etag": "\"318-K2ecuE0U/5ov+A9zYruu0dZLXaM\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 792,
    "path": "../public/flag/kp.svg"
  },
  "/flag/kr.svg": {
    "type": "image/svg+xml",
    "etag": "\"723-pLfjL0pP9Z5qhDk35A699HIPDas\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1827,
    "path": "../public/flag/kr.svg"
  },
  "/flag/kw.svg": {
    "type": "image/svg+xml",
    "etag": "\"1fa-/l4pG+ZKQVhGlPkI/Pr+NS0I/jg\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 506,
    "path": "../public/flag/kw.svg"
  },
  "/flag/ky.svg": {
    "type": "image/svg+xml",
    "etag": "\"557e-c2TiEuPulVKbZXP9UkwmLMVsJ1w\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 21886,
    "path": "../public/flag/ky.svg"
  },
  "/flag/kz.svg": {
    "type": "image/svg+xml",
    "etag": "\"2c4b-gNCf0QLB7IZPt+soxcbklizKzxM\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 11339,
    "path": "../public/flag/kz.svg"
  },
  "/flag/la.svg": {
    "type": "image/svg+xml",
    "etag": "\"1c9-GL4Yltn0hElqERB3GEwoHfUYCNg\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 457,
    "path": "../public/flag/la.svg"
  },
  "/flag/lb.svg": {
    "type": "image/svg+xml",
    "etag": "\"afe-5mhFO8D7ZQw0W7DiRqC22BFzs9U\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 2814,
    "path": "../public/flag/lb.svg"
  },
  "/flag/lc.svg": {
    "type": "image/svg+xml",
    "etag": "\"175-FwhKNbTEJBvqMOsYz0uiMaS+Ui0\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 373,
    "path": "../public/flag/lc.svg"
  },
  "/flag/li.svg": {
    "type": "image/svg+xml",
    "etag": "\"2087-uZT3atpgbSXH9AfORTNQTkLU0OU\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 8327,
    "path": "../public/flag/li.svg"
  },
  "/flag/lk.svg": {
    "type": "image/svg+xml",
    "etag": "\"2c45-4bR+k11lSbkjEiD5HQZ5btSS1lA\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 11333,
    "path": "../public/flag/lk.svg"
  },
  "/flag/lr.svg": {
    "type": "image/svg+xml",
    "etag": "\"2d4-rJzjhuQ2m9iTnd99lqx+eTzhbn8\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 724,
    "path": "../public/flag/lr.svg"
  },
  "/flag/ls.svg": {
    "type": "image/svg+xml",
    "etag": "\"4c6-2d6/A1gEtaVXIkiWgWSQ1i1XmBc\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1222,
    "path": "../public/flag/ls.svg"
  },
  "/flag/lt.svg": {
    "type": "image/svg+xml",
    "etag": "\"1bd-8mnofnqSZqtK6rQ7NwjlCNNQFTM\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 445,
    "path": "../public/flag/lt.svg"
  },
  "/flag/lu.svg": {
    "type": "image/svg+xml",
    "etag": "\"e7-42+WqAt272k5LQcsNQjDrG9X4o0\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 231,
    "path": "../public/flag/lu.svg"
  },
  "/flag/lv.svg": {
    "type": "image/svg+xml",
    "etag": "\"ec-YZjP/MMIFXQMVq7Qcl3OayRGMfY\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 236,
    "path": "../public/flag/lv.svg"
  },
  "/flag/ly.svg": {
    "type": "image/svg+xml",
    "etag": "\"216-9aQCsgXx6ysD1Rpssf8bNXYlzFY\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 534,
    "path": "../public/flag/ly.svg"
  },
  "/flag/ma.svg": {
    "type": "image/svg+xml",
    "etag": "\"fd-YzdLgjqEn3n4tzjAE/hgjf5Gg2k\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 253,
    "path": "../public/flag/ma.svg"
  },
  "/flag/mc.svg": {
    "type": "image/svg+xml",
    "etag": "\"f0-kj3jXzMS990KovzmO7UZViR9aus\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 240,
    "path": "../public/flag/mc.svg"
  },
  "/flag/md.svg": {
    "type": "image/svg+xml",
    "etag": "\"2c13-E4yflU+KqcyxodgQBfrtO+qjAuk\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 11283,
    "path": "../public/flag/md.svg"
  },
  "/flag/me.svg": {
    "type": "image/svg+xml",
    "etag": "\"f6c9-EpN0WlhPJk3A7Y91IK8K31pQUg0\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 63177,
    "path": "../public/flag/me.svg"
  },
  "/flag/mf.svg": {
    "type": "image/svg+xml",
    "etag": "\"127-DMIQjqI267KYBO9/EtZnDuM/J9I\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 295,
    "path": "../public/flag/mf.svg"
  },
  "/flag/mg.svg": {
    "type": "image/svg+xml",
    "etag": "\"131-KrL+wRMeO/3QsX+hPJLVOEtMPew\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 305,
    "path": "../public/flag/mg.svg"
  },
  "/flag/mh.svg": {
    "type": "image/svg+xml",
    "etag": "\"2e8-gMMzF0Q4XbhbW7JVhzCm/y440UM\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 744,
    "path": "../public/flag/mh.svg"
  },
  "/flag/mk.svg": {
    "type": "image/svg+xml",
    "etag": "\"181-/ESOXD5LbsqqQZIIxgJ5jKf6Aro\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 385,
    "path": "../public/flag/mk.svg"
  },
  "/flag/ml.svg": {
    "type": "image/svg+xml",
    "etag": "\"117-Eru2Fl5qMYQfaEeMBso5cFn2Lf8\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 279,
    "path": "../public/flag/ml.svg"
  },
  "/flag/mm.svg": {
    "type": "image/svg+xml",
    "etag": "\"353-aJQZzkeUAl8AOlDrbQebxLSyF94\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 851,
    "path": "../public/flag/mm.svg"
  },
  "/flag/mn.svg": {
    "type": "image/svg+xml",
    "etag": "\"4e8-9hlisDo1sna6D0j17RSn3qPcV3s\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1256,
    "path": "../public/flag/mn.svg"
  },
  "/flag/mo.svg": {
    "type": "image/svg+xml",
    "etag": "\"5ec-WdIrVR3d95JrvLvPKIE/gQFOBr4\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1516,
    "path": "../public/flag/mo.svg"
  },
  "/flag/mp.svg": {
    "type": "image/svg+xml",
    "etag": "\"5b81-wm31muYIXRUQNG8gvGcdDgIz5VA\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 23425,
    "path": "../public/flag/mp.svg"
  },
  "/flag/mq.svg": {
    "type": "image/svg+xml",
    "etag": "\"127-Wp5fZC8wUBhTIP0Iob+kJziDM0g\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 295,
    "path": "../public/flag/mq.svg"
  },
  "/flag/mr.svg": {
    "type": "image/svg+xml",
    "etag": "\"1c2-8H+YtMG/kJvNmBAJfEDDoXF+0sI\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 450,
    "path": "../public/flag/mr.svg"
  },
  "/flag/ms.svg": {
    "type": "image/svg+xml",
    "etag": "\"1a88-2K1IfS6ztv2LLBJzNftkihFKS5g\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 6792,
    "path": "../public/flag/ms.svg"
  },
  "/flag/mt.svg": {
    "type": "image/svg+xml",
    "etag": "\"2267-uVHxZJd19vpiB+kDcvNIM1yVHnU\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 8807,
    "path": "../public/flag/mt.svg"
  },
  "/flag/mu.svg": {
    "type": "image/svg+xml",
    "etag": "\"142-K/QShEUlevzZX/4OPuU3M72w8R0\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 322,
    "path": "../public/flag/mu.svg"
  },
  "/flag/mv.svg": {
    "type": "image/svg+xml",
    "etag": "\"124-j+QxBaRmBBode4O9zKlIRdxcQi0\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 292,
    "path": "../public/flag/mv.svg"
  },
  "/flag/mw.svg": {
    "type": "image/svg+xml",
    "etag": "\"e89-sL+PtXwlGmDA/Kl4lPCCylp4UHI\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 3721,
    "path": "../public/flag/mw.svg"
  },
  "/flag/mx.svg": {
    "type": "image/svg+xml",
    "etag": "\"17678-vCuSZjy0G5TXnC0Y7oZ856CPjjk\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 95864,
    "path": "../public/flag/mx.svg"
  },
  "/flag/my.svg": {
    "type": "image/svg+xml",
    "etag": "\"504-2yAdV9Fa4aUX9T0YsxcqIgix2DA\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1284,
    "path": "../public/flag/my.svg"
  },
  "/flag/mz.svg": {
    "type": "image/svg+xml",
    "etag": "\"a3f-W4tKyhTDuxJEPt0Ek5DD7e4cZrI\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 2623,
    "path": "../public/flag/mz.svg"
  },
  "/flag/na.svg": {
    "type": "image/svg+xml",
    "etag": "\"3ed-beFzf5bJtxpQmzusM2wwf2477vk\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1005,
    "path": "../public/flag/na.svg"
  },
  "/flag/nc.svg": {
    "type": "image/svg+xml",
    "etag": "\"127-AIXoIWLa5+mfU7HHrZAv0W+ncR0\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 295,
    "path": "../public/flag/nc.svg"
  },
  "/flag/ne.svg": {
    "type": "image/svg+xml",
    "etag": "\"117-0JlHsaF5wkY+i8AfKdUFM8IHpwM\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 279,
    "path": "../public/flag/ne.svg"
  },
  "/flag/nf.svg": {
    "type": "image/svg+xml",
    "etag": "\"16d5-sDtzZf/i9/a/4rQoFFblfyWvS3M\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 5845,
    "path": "../public/flag/nf.svg"
  },
  "/flag/ng.svg": {
    "type": "image/svg+xml",
    "etag": "\"107-3ZzwPLs4tcb/SvOoEMFigfgkGr8\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 263,
    "path": "../public/flag/ng.svg"
  },
  "/flag/ni.svg": {
    "type": "image/svg+xml",
    "etag": "\"4898-z/YzGRNR11Vhd3iI6bBZ3a8wvDk\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 18584,
    "path": "../public/flag/ni.svg"
  },
  "/flag/nl.svg": {
    "type": "image/svg+xml",
    "etag": "\"16f-xyPL0REpKWCnrwn3jqRRTM+eEP4\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 367,
    "path": "../public/flag/nl.svg"
  },
  "/flag/no.svg": {
    "type": "image/svg+xml",
    "etag": "\"144-YW/Zcl5d+WgMiKxwnm+aSiyhHDg\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 324,
    "path": "../public/flag/no.svg"
  },
  "/flag/np.svg": {
    "type": "image/svg+xml",
    "etag": "\"425-1WaUiEOmYLRQn5aP5HTqEKxTVTI\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1061,
    "path": "../public/flag/np.svg"
  },
  "/flag/nr.svg": {
    "type": "image/svg+xml",
    "etag": "\"288-QyhlBKyX7yb2UHtshCyo75G02Po\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 648,
    "path": "../public/flag/nr.svg"
  },
  "/flag/nu.svg": {
    "type": "image/svg+xml",
    "etag": "\"6d4-yRzcEqNPIfnGlKoldIE7c5/R+xw\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1748,
    "path": "../public/flag/nu.svg"
  },
  "/flag/nz.svg": {
    "type": "image/svg+xml",
    "etag": "\"bcb-8vI4AJ4hXnM7mviPLR//OWnm5UU\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 3019,
    "path": "../public/flag/nz.svg"
  },
  "/flag/om.svg": {
    "type": "image/svg+xml",
    "etag": "\"596b-L4sOjP5MzsyiLcwb8Xzxxe3BMuQ\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 22891,
    "path": "../public/flag/om.svg"
  },
  "/flag/pa.svg": {
    "type": "image/svg+xml",
    "etag": "\"2ea-OABkXLssnNlahbgXqdlXQiEpzac\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 746,
    "path": "../public/flag/pa.svg"
  },
  "/flag/pe.svg": {
    "type": "image/svg+xml",
    "etag": "\"12267-dB/tPCcvpjcUz3Lfthcnw3cfBYY\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 74343,
    "path": "../public/flag/pe.svg"
  },
  "/flag/pf.svg": {
    "type": "image/svg+xml",
    "etag": "\"10c4-SYFaIuDAt13lGcQGm5KxKPD/n6k\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 4292,
    "path": "../public/flag/pf.svg"
  },
  "/flag/pg.svg": {
    "type": "image/svg+xml",
    "etag": "\"687-If99n4/zqI6Lc0RU3fuCA3RST8A\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1671,
    "path": "../public/flag/pg.svg"
  },
  "/flag/ph.svg": {
    "type": "image/svg+xml",
    "etag": "\"517-JhKOMHctlht6e/fgYi7eI9G6keI\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1303,
    "path": "../public/flag/ph.svg"
  },
  "/flag/pk.svg": {
    "type": "image/svg+xml",
    "etag": "\"2e7-iC4d8uRRlyHVSKETyrNxLyHEIE8\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 743,
    "path": "../public/flag/pk.svg"
  },
  "/flag/pl.svg": {
    "type": "image/svg+xml",
    "etag": "\"e1-gMJpI+m1kU4905cZZgw4Htie+EA\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 225,
    "path": "../public/flag/pl.svg"
  },
  "/flag/pm.svg": {
    "type": "image/svg+xml",
    "etag": "\"127-AtD/TdOwyRc4OQDXsXpbTXWe/hk\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 295,
    "path": "../public/flag/pm.svg"
  },
  "/flag/pn.svg": {
    "type": "image/svg+xml",
    "etag": "\"2ac9-kQpetUBzV9HNKTpfLq3/Ty7FqB8\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 10953,
    "path": "../public/flag/pn.svg"
  },
  "/flag/pr.svg": {
    "type": "image/svg+xml",
    "etag": "\"27a-2OZaqdsDyz5jeMNFpabaOPcEjnY\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 634,
    "path": "../public/flag/pr.svg"
  },
  "/flag/ps.svg": {
    "type": "image/svg+xml",
    "etag": "\"22e-QLGFo3QmN9lRuON4c3uJVhsBlYI\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 558,
    "path": "../public/flag/ps.svg"
  },
  "/flag/pt.svg": {
    "type": "image/svg+xml",
    "etag": "\"20c9-enWUWqkvej3VrrDMAfP4eY1E4tU\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 8393,
    "path": "../public/flag/pt.svg"
  },
  "/flag/pw.svg": {
    "type": "image/svg+xml",
    "etag": "\"1d3-dTShjzpDoc8x9cO5Y5U1BVx05kE\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 467,
    "path": "../public/flag/pw.svg"
  },
  "/flag/py.svg": {
    "type": "image/svg+xml",
    "etag": "\"43a0-1Ugb2ZCE1pPCCJtfPT1yFJBxxGc\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 17312,
    "path": "../public/flag/py.svg"
  },
  "/flag/qa.svg": {
    "type": "image/svg+xml",
    "etag": "\"16a-SSo61J91sC8+s+A7yeHx0UgT7rQ\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 362,
    "path": "../public/flag/qa.svg"
  },
  "/flag/re.svg": {
    "type": "image/svg+xml",
    "etag": "\"127-mJ59RHPxUGlKe0sULxzbncAS8LE\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 295,
    "path": "../public/flag/re.svg"
  },
  "/flag/ro.svg": {
    "type": "image/svg+xml",
    "etag": "\"134-Vp3hdoEDr9FauCa8MvqL+2VJ4T4\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 308,
    "path": "../public/flag/ro.svg"
  },
  "/flag/rs.svg": {
    "type": "image/svg+xml",
    "etag": "\"2dcf8-/mGDLVMRMhlrXUfKNDESfcNXgbQ\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 187640,
    "path": "../public/flag/rs.svg"
  },
  "/flag/ru.svg": {
    "type": "image/svg+xml",
    "etag": "\"121-dpN4biTmv86mi248mA1w/6xEU6s\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 289,
    "path": "../public/flag/ru.svg"
  },
  "/flag/rw.svg": {
    "type": "image/svg+xml",
    "etag": "\"2ee-bZDn9+iX7pPywvEzkjCwt7O1Yiw\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 750,
    "path": "../public/flag/rw.svg"
  },
  "/flag/sa.svg": {
    "type": "image/svg+xml",
    "etag": "\"283f-q6Jgx2pc99Goi69P7EOkYd2xnPU\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 10303,
    "path": "../public/flag/sa.svg"
  },
  "/flag/sb.svg": {
    "type": "image/svg+xml",
    "etag": "\"3b6-AZ7Po99e5aFLLOTxY3qE7B9V75Y\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 950,
    "path": "../public/flag/sb.svg"
  },
  "/flag/sc.svg": {
    "type": "image/svg+xml",
    "etag": "\"238-6GF+eXr3Uud+X+OZrD+w6A7qfnk\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 568,
    "path": "../public/flag/sc.svg"
  },
  "/flag/sd.svg": {
    "type": "image/svg+xml",
    "etag": "\"1ee-ysVk/1eSy6vpKewLHrZUIahxIqg\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 494,
    "path": "../public/flag/sd.svg"
  },
  "/flag/se.svg": {
    "type": "image/svg+xml",
    "etag": "\"2b0-qKUcVMOt0Z5TQByzIzo7z4tyd0o\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 688,
    "path": "../public/flag/se.svg"
  },
  "/flag/sg.svg": {
    "type": "image/svg+xml",
    "etag": "\"37a-fG+O+m2H9xK5WmJUCmRmd858UU0\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 890,
    "path": "../public/flag/sg.svg"
  },
  "/flag/sh.svg": {
    "type": "image/svg+xml",
    "etag": "\"7406-57+qzS5eJMHKM7Wr88n/5To18h8\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 29702,
    "path": "../public/flag/sh.svg"
  },
  "/flag/si.svg": {
    "type": "image/svg+xml",
    "etag": "\"807-JhPT6glx2ZM1LTqr7emXsuUMG78\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 2055,
    "path": "../public/flag/si.svg"
  },
  "/flag/sj.svg": {
    "type": "image/svg+xml",
    "etag": "\"144-xgT4YxlRC2gwy//uUHPZr5hlZao\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 324,
    "path": "../public/flag/sj.svg"
  },
  "/flag/sk.svg": {
    "type": "image/svg+xml",
    "etag": "\"4b8-XC2oQOpbvAT+3UIynnp+Sxia/5g\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1208,
    "path": "../public/flag/sk.svg"
  },
  "/flag/sl.svg": {
    "type": "image/svg+xml",
    "etag": "\"116-4jQl2Zr8COAZmJ/9Jr/vExtHPEY\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 278,
    "path": "../public/flag/sl.svg"
  },
  "/flag/sm.svg": {
    "type": "image/svg+xml",
    "etag": "\"3e58-GIIwSI95ou5IagzZGJVhpeZn0Cg\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 15960,
    "path": "../public/flag/sm.svg"
  },
  "/flag/sn.svg": {
    "type": "image/svg+xml",
    "etag": "\"1ab-978PDHAb+taOCsp+wBOhdN3u3WQ\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 427,
    "path": "../public/flag/sn.svg"
  },
  "/flag/so.svg": {
    "type": "image/svg+xml",
    "etag": "\"1ee-AFOkXLk3xnH9bUGwbK3iJjNpl24\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 494,
    "path": "../public/flag/so.svg"
  },
  "/flag/sr.svg": {
    "type": "image/svg+xml",
    "etag": "\"13e-hETd/TQI5LOmy9UdrACj9csp8sU\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 318,
    "path": "../public/flag/sr.svg"
  },
  "/flag/ss.svg": {
    "type": "image/svg+xml",
    "etag": "\"185-GFkJf+jyGff+SRModU/SQY6KFLs\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 389,
    "path": "../public/flag/ss.svg"
  },
  "/flag/st.svg": {
    "type": "image/svg+xml",
    "etag": "\"397-lKz33OHBX8hAcImqieeLO3Iu76I\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 919,
    "path": "../public/flag/st.svg"
  },
  "/flag/sv.svg": {
    "type": "image/svg+xml",
    "etag": "\"14845-zflfTDSkkG2wtNOZFED3ZoJBPUg\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 84037,
    "path": "../public/flag/sv.svg"
  },
  "/flag/sx.svg": {
    "type": "image/svg+xml",
    "etag": "\"33fa-hbouZgfFkKmzL0kemjFjWYeosjY\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 13306,
    "path": "../public/flag/sx.svg"
  },
  "/flag/sy.svg": {
    "type": "image/svg+xml",
    "etag": "\"238-plCz0dnWe34D1RMaF4vwnHBLIoI\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 568,
    "path": "../public/flag/sy.svg"
  },
  "/flag/sz.svg": {
    "type": "image/svg+xml",
    "etag": "\"1a63-hPmTG/rwt/BRXduaPsWfgzJUT1w\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 6755,
    "path": "../public/flag/sz.svg"
  },
  "/flag/tc.svg": {
    "type": "image/svg+xml",
    "etag": "\"38f9-etnyWfYY6UNjBEQY4TXfHD1vJlk\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 14585,
    "path": "../public/flag/tc.svg"
  },
  "/flag/td.svg": {
    "type": "image/svg+xml",
    "etag": "\"10e-QXfBog0oT3amtpu8deexDnORsVA\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 270,
    "path": "../public/flag/td.svg"
  },
  "/flag/tf.svg": {
    "type": "image/svg+xml",
    "etag": "\"443-QatEXQxGyk1UI5JT43z8f/CapWA\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1091,
    "path": "../public/flag/tf.svg"
  },
  "/flag/tg.svg": {
    "type": "image/svg+xml",
    "etag": "\"2d5-XP9b0X02j6OpHjnO+cDc46WYosM\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 725,
    "path": "../public/flag/tg.svg"
  },
  "/flag/th.svg": {
    "type": "image/svg+xml",
    "etag": "\"11f-HvSn2mAt4Ycyaq+9lt4TrlAg6XY\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 287,
    "path": "../public/flag/th.svg"
  },
  "/flag/tj.svg": {
    "type": "image/svg+xml",
    "etag": "\"727-mAQlbXtKqBlD8P3tJTS8TqAmj0s\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1831,
    "path": "../public/flag/tj.svg"
  },
  "/flag/tk.svg": {
    "type": "image/svg+xml",
    "etag": "\"317-Hs+KnYe2x+/ZbxTRIhso78UCbbA\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 791,
    "path": "../public/flag/tk.svg"
  },
  "/flag/tl.svg": {
    "type": "image/svg+xml",
    "etag": "\"258-zR+ebtj5GtGsEZAv79j+5L8FDUc\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 600,
    "path": "../public/flag/tl.svg"
  },
  "/flag/tm.svg": {
    "type": "image/svg+xml",
    "etag": "\"7f43-jp+wVDvBiPUk2CqlPTJ3jnGXV3k\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 32579,
    "path": "../public/flag/tm.svg"
  },
  "/flag/tn.svg": {
    "type": "image/svg+xml",
    "etag": "\"2f1-rAQELmJ0vtfJVCW5guv5EfAjI+M\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 753,
    "path": "../public/flag/tn.svg"
  },
  "/flag/to.svg": {
    "type": "image/svg+xml",
    "etag": "\"166-xgIZdNqdtjcR8zf+BIVJm0YAkIs\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 358,
    "path": "../public/flag/to.svg"
  },
  "/flag/tr.svg": {
    "type": "image/svg+xml",
    "etag": "\"22d-UCl0b/ajLFwuROXrm9yMXpQZ3wU\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 557,
    "path": "../public/flag/tr.svg"
  },
  "/flag/tt.svg": {
    "type": "image/svg+xml",
    "etag": "\"144-aOysG3QW1zKMzHQZAu/NF1svZIQ\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 324,
    "path": "../public/flag/tt.svg"
  },
  "/flag/tv.svg": {
    "type": "image/svg+xml",
    "etag": "\"8fb-K5viiHokOs1HvygOljKbLblnMok\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 2299,
    "path": "../public/flag/tv.svg"
  },
  "/flag/tw.svg": {
    "type": "image/svg+xml",
    "etag": "\"3b1-w4eO6ClzUtBqLoNor3Br/yCXDtw\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 945,
    "path": "../public/flag/tw.svg"
  },
  "/flag/tz.svg": {
    "type": "image/svg+xml",
    "etag": "\"222-NBZhOQ6f8iI5ioEaB8ZTmKU4+/M\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 546,
    "path": "../public/flag/tz.svg"
  },
  "/flag/ua.svg": {
    "type": "image/svg+xml",
    "etag": "\"f1-h5ut1gSNdIBv/9acH52seXImTP8\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 241,
    "path": "../public/flag/ua.svg"
  },
  "/flag/ug.svg": {
    "type": "image/svg+xml",
    "etag": "\"f77-Q1ZHzM4aIM9Y4QiThMAXHvPxsXI\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 3959,
    "path": "../public/flag/ug.svg"
  },
  "/flag/um.svg": {
    "type": "image/svg+xml",
    "etag": "\"11ac-i9Qo/pBETc99L2onHLptM+mVdYU\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 4524,
    "path": "../public/flag/um.svg"
  },
  "/flag/un.svg": {
    "type": "image/svg+xml",
    "etag": "\"4f2c-J5B9x5yj7ovRsQP20JzaB85goxo\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 20268,
    "path": "../public/flag/un.svg"
  },
  "/flag/us.svg": {
    "type": "image/svg+xml",
    "etag": "\"1174-jzP6h74DCWsVx2EZBjFB+VIsfxc\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 4468,
    "path": "../public/flag/us.svg"
  },
  "/flag/uy.svg": {
    "type": "image/svg+xml",
    "etag": "\"6b9-TYD7fSONh18p/pSRMXVxdrwJNOo\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1721,
    "path": "../public/flag/uy.svg"
  },
  "/flag/uz.svg": {
    "type": "image/svg+xml",
    "etag": "\"5b1-ul9keAPRui+KtZ5e2MaaDzZ3lhA\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1457,
    "path": "../public/flag/uz.svg"
  },
  "/flag/va.svg": {
    "type": "image/svg+xml",
    "etag": "\"16469-0KdSBg7k35J+9/PuKgbtjL0vzIo\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 91241,
    "path": "../public/flag/va.svg"
  },
  "/flag/vc.svg": {
    "type": "image/svg+xml",
    "etag": "\"1c6-6HHlNFHPZ+flmsEgSUHjruMgz90\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 454,
    "path": "../public/flag/vc.svg"
  },
  "/flag/ve.svg": {
    "type": "image/svg+xml",
    "etag": "\"493-pKEiSAoYFB1PYrIkMUsv4kzOGpU\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 1171,
    "path": "../public/flag/ve.svg"
  },
  "/flag/vg.svg": {
    "type": "image/svg+xml",
    "etag": "\"60f2-7i2leX+jEd/CFKk+vtCd1owVbXk\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 24818,
    "path": "../public/flag/vg.svg"
  },
  "/flag/vi.svg": {
    "type": "image/svg+xml",
    "etag": "\"2247-7RKo6QaOwlSLOP9opg3wcSH0y3k\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 8775,
    "path": "../public/flag/vi.svg"
  },
  "/flag/vn.svg": {
    "type": "image/svg+xml",
    "etag": "\"1ec-nbG+nL05/D/Qs2LNzDGjQ/CTXMw\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 492,
    "path": "../public/flag/vn.svg"
  },
  "/flag/vu.svg": {
    "type": "image/svg+xml",
    "etag": "\"ebb-Di0IOWQbiiTOyc8txngpw/oiKT0\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 3771,
    "path": "../public/flag/vu.svg"
  },
  "/flag/wf.svg": {
    "type": "image/svg+xml",
    "etag": "\"127-D4DxHe3V+suoQA3xn8I9Gobou5I\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 295,
    "path": "../public/flag/wf.svg"
  },
  "/flag/ws.svg": {
    "type": "image/svg+xml",
    "etag": "\"297-4zS3zHo7mmbdIfopQjNfL32s3+w\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 663,
    "path": "../public/flag/ws.svg"
  },
  "/flag/ye.svg": {
    "type": "image/svg+xml",
    "etag": "\"116-6G3AT/HEsiSRQ+IgayJn/gW/d3g\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 278,
    "path": "../public/flag/ye.svg"
  },
  "/flag/yt.svg": {
    "type": "image/svg+xml",
    "etag": "\"127-+8JnuapTh5stzmRG/BL5IyH3hp0\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 295,
    "path": "../public/flag/yt.svg"
  },
  "/flag/za.svg": {
    "type": "image/svg+xml",
    "etag": "\"358-Jtf32uhYbQd8D3FNHoyIqMt1CKc\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 856,
    "path": "../public/flag/za.svg"
  },
  "/flag/zm.svg": {
    "type": "image/svg+xml",
    "etag": "\"1584-TUOJ7BIVeJnOrebPOE4IuC5dFyk\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 5508,
    "path": "../public/flag/zm.svg"
  },
  "/flag/zw.svg": {
    "type": "image/svg+xml",
    "etag": "\"1a87-ZLkZGp/kQpxgd8nTF9jl93OYlaY\"",
    "mtime": "2022-06-28T03:36:46.000Z",
    "size": 6791,
    "path": "../public/flag/zw.svg"
  },
  "/_nuxt/admin-layout.5q5Sre0P.js": {
    "type": "application/javascript",
    "etag": "\"b1f-dUGJdtFS5O4uYTFGmZYq+IuNsaM\"",
    "mtime": "2024-02-27T17:16:37.701Z",
    "size": 2847,
    "path": "../public/_nuxt/admin-layout.5q5Sre0P.js"
  },
  "/_nuxt/admin-layout.5q5Sre0P.js.map": {
    "type": "application/json",
    "etag": "\"11e4-EkhQ94tmmiEOYy+SJ0A2SN4v9SE\"",
    "mtime": "2024-02-27T17:16:37.806Z",
    "size": 4580,
    "path": "../public/_nuxt/admin-layout.5q5Sre0P.js.map"
  },
  "/_nuxt/AppProductCard.vue.MkOdVf8S.js": {
    "type": "application/javascript",
    "etag": "\"6e1-3DGi3VTVzn5zBNrCldICeuOXhoE\"",
    "mtime": "2024-02-27T17:16:37.669Z",
    "size": 1761,
    "path": "../public/_nuxt/AppProductCard.vue.MkOdVf8S.js"
  },
  "/_nuxt/AppProductCard.vue.MkOdVf8S.js.map": {
    "type": "application/json",
    "etag": "\"6f-lMAcnE4cfDpB9mrv4KcoSDKq+U0\"",
    "mtime": "2024-02-27T17:16:37.701Z",
    "size": 111,
    "path": "../public/_nuxt/AppProductCard.vue.MkOdVf8S.js.map"
  },
  "/_nuxt/auth.OIOZKVik.js": {
    "type": "application/javascript",
    "etag": "\"b2-4TCrypfhqHXHD7uBcn49jusYpoo\"",
    "mtime": "2024-02-27T17:16:37.692Z",
    "size": 178,
    "path": "../public/_nuxt/auth.OIOZKVik.js"
  },
  "/_nuxt/auth.OIOZKVik.js.map": {
    "type": "application/json",
    "etag": "\"1ef-bOwDjXvePkBFtqydo6XlBxdpobU\"",
    "mtime": "2024-02-27T17:16:37.805Z",
    "size": 495,
    "path": "../public/_nuxt/auth.OIOZKVik.js.map"
  },
  "/_nuxt/brands.YnFC_boV.js": {
    "type": "application/javascript",
    "etag": "\"1d3a-ut2qyOC+DFKns4l4fcXyvzM8sCw\"",
    "mtime": "2024-02-27T17:16:37.669Z",
    "size": 7482,
    "path": "../public/_nuxt/brands.YnFC_boV.js"
  },
  "/_nuxt/brands.YnFC_boV.js.map": {
    "type": "application/json",
    "etag": "\"39f1-yQ29I/jiz1Dwp1qt5uAQTLW9mRI\"",
    "mtime": "2024-02-27T17:16:37.701Z",
    "size": 14833,
    "path": "../public/_nuxt/brands.YnFC_boV.js.map"
  },
  "/_nuxt/categories.uyDWNm9m.js": {
    "type": "application/javascript",
    "etag": "\"205a-jTgcZfHCnNW6A2YZM0pYW1YVzLM\"",
    "mtime": "2024-02-27T17:16:37.700Z",
    "size": 8282,
    "path": "../public/_nuxt/categories.uyDWNm9m.js"
  },
  "/_nuxt/categories.uyDWNm9m.js.map": {
    "type": "application/json",
    "etag": "\"3b01-r4Ar2/UC+7iSY1V3g841iML6J08\"",
    "mtime": "2024-02-27T17:16:37.805Z",
    "size": 15105,
    "path": "../public/_nuxt/categories.uyDWNm9m.js.map"
  },
  "/_nuxt/client-only.oAdxK6Sw.js": {
    "type": "application/javascript",
    "etag": "\"237-6p+EzYTePQYeLdM3IF6Fe7XamFY\"",
    "mtime": "2024-02-27T17:16:37.671Z",
    "size": 567,
    "path": "../public/_nuxt/client-only.oAdxK6Sw.js"
  },
  "/_nuxt/client-only.oAdxK6Sw.js.map": {
    "type": "application/json",
    "etag": "\"113e-0r/oHLrJoZyHJG5VyuYR4zS/tMw\"",
    "mtime": "2024-02-27T17:16:37.800Z",
    "size": 4414,
    "path": "../public/_nuxt/client-only.oAdxK6Sw.js.map"
  },
  "/_nuxt/entry.7ugRP3Aw.js": {
    "type": "application/javascript",
    "etag": "\"98932-tU3a0h5b+swAG4D5bj2QSADz1kc\"",
    "mtime": "2024-02-27T17:16:37.703Z",
    "size": 624946,
    "path": "../public/_nuxt/entry.7ugRP3Aw.js"
  },
  "/_nuxt/entry.7ugRP3Aw.js.map": {
    "type": "application/json",
    "etag": "\"304d97-ERPH0tQOKdnx9d1siqu/a9zXdzI\"",
    "mtime": "2024-02-27T17:16:38.056Z",
    "size": 3165591,
    "path": "../public/_nuxt/entry.7ugRP3Aw.js.map"
  },
  "/_nuxt/entry.CwUnOkqc.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"b8bce-SktlkOsEh/skf5KnWQc7Tjd+CSw\"",
    "mtime": "2024-02-27T17:16:37.672Z",
    "size": 756686,
    "path": "../public/_nuxt/entry.CwUnOkqc.css"
  },
  "/_nuxt/i18n.config.PK8ZAroV.js": {
    "type": "application/javascript",
    "etag": "\"2f2c-yLnm3Rveig9XVoZeC1s/c12j/Og\"",
    "mtime": "2024-02-27T17:16:37.700Z",
    "size": 12076,
    "path": "../public/_nuxt/i18n.config.PK8ZAroV.js"
  },
  "/_nuxt/i18n.config.PK8ZAroV.js.map": {
    "type": "application/json",
    "etag": "\"55a0-Qa457PPzMLt5m/8SGEYpvG43ZJA\"",
    "mtime": "2024-02-27T17:16:37.806Z",
    "size": 21920,
    "path": "../public/_nuxt/i18n.config.PK8ZAroV.js.map"
  },
  "/_nuxt/icon-base.vvY7qceX.js": {
    "type": "application/javascript",
    "etag": "\"2f67-Kp68h9ZxqUClcR/9Jfmt2raujao\"",
    "mtime": "2024-02-27T17:16:37.700Z",
    "size": 12135,
    "path": "../public/_nuxt/icon-base.vvY7qceX.js"
  },
  "/_nuxt/icon-base.vvY7qceX.js.map": {
    "type": "application/json",
    "etag": "\"cdfc-+yw6nfBafr0IIW3ua8rtxQtyXF0\"",
    "mtime": "2024-02-27T17:16:37.811Z",
    "size": 52732,
    "path": "../public/_nuxt/icon-base.vvY7qceX.js.map"
  },
  "/_nuxt/index-layout.9S6GYWQv.js": {
    "type": "application/javascript",
    "etag": "\"2bac-oUFJHbNVpnYGtjAN5PsXyGuGuww\"",
    "mtime": "2024-02-27T17:16:37.701Z",
    "size": 11180,
    "path": "../public/_nuxt/index-layout.9S6GYWQv.js"
  },
  "/_nuxt/index-layout.9S6GYWQv.js.map": {
    "type": "application/json",
    "etag": "\"6d62-wz+Zl0TyvuusAVoc5GYd2iG8yto\"",
    "mtime": "2024-02-27T17:16:37.911Z",
    "size": 28002,
    "path": "../public/_nuxt/index-layout.9S6GYWQv.js.map"
  },
  "/_nuxt/index.1ALCF4I3.js": {
    "type": "application/javascript",
    "etag": "\"4e40-O646YKP8RC9XLnuEY/itwS0Z/cs\"",
    "mtime": "2024-02-27T17:16:37.701Z",
    "size": 20032,
    "path": "../public/_nuxt/index.1ALCF4I3.js"
  },
  "/_nuxt/index.1ALCF4I3.js.map": {
    "type": "application/json",
    "etag": "\"9526-JdjQGz9iF7FmEjMQMC3Mn94ihik\"",
    "mtime": "2024-02-27T17:16:37.911Z",
    "size": 38182,
    "path": "../public/_nuxt/index.1ALCF4I3.js.map"
  },
  "/_nuxt/index.1yCehivy.js": {
    "type": "application/javascript",
    "etag": "\"86ad-NhfQZ32317xmFR/nLZ5FTz5ndUw\"",
    "mtime": "2024-02-27T17:16:37.700Z",
    "size": 34477,
    "path": "../public/_nuxt/index.1yCehivy.js"
  },
  "/_nuxt/index.1yCehivy.js.map": {
    "type": "application/json",
    "etag": "\"7f2cae-ss8TNJHQbgrYne/quAJ+luUfCR8\"",
    "mtime": "2024-02-27T17:16:38.113Z",
    "size": 8334510,
    "path": "../public/_nuxt/index.1yCehivy.js.map"
  },
  "/_nuxt/index.5lIj2-WH.js": {
    "type": "application/javascript",
    "etag": "\"c4b-aqQ1hvB4GtJP2BPBTFrj1HFQW0o\"",
    "mtime": "2024-02-27T17:16:37.672Z",
    "size": 3147,
    "path": "../public/_nuxt/index.5lIj2-WH.js"
  },
  "/_nuxt/index.5lIj2-WH.js.map": {
    "type": "application/json",
    "etag": "\"38866-Z2bjxMBSwgBL0D2hbJwFaEvI01c\"",
    "mtime": "2024-02-27T17:16:37.801Z",
    "size": 231526,
    "path": "../public/_nuxt/index.5lIj2-WH.js.map"
  },
  "/_nuxt/index.izeaALHj.js": {
    "type": "application/javascript",
    "etag": "\"1acd-bfeQc4Ne1J2le/ZaqaqsQUzhhlA\"",
    "mtime": "2024-02-27T17:16:37.700Z",
    "size": 6861,
    "path": "../public/_nuxt/index.izeaALHj.js"
  },
  "/_nuxt/index.izeaALHj.js.map": {
    "type": "application/json",
    "etag": "\"2a3c-dThQiROLsFjz7aL5bbjtITol3u4\"",
    "mtime": "2024-02-27T17:16:37.810Z",
    "size": 10812,
    "path": "../public/_nuxt/index.izeaALHj.js.map"
  },
  "/_nuxt/index.lIBEqVyA.js": {
    "type": "application/javascript",
    "etag": "\"3f0-rhlicu0P47h+ywJGuKw0uz38McE\"",
    "mtime": "2024-02-27T17:16:37.670Z",
    "size": 1008,
    "path": "../public/_nuxt/index.lIBEqVyA.js"
  },
  "/_nuxt/index.lIBEqVyA.js.map": {
    "type": "application/json",
    "etag": "\"27deb9-054xjdZeyigZ07QIaPKBFjHQUc4\"",
    "mtime": "2024-02-27T17:16:37.805Z",
    "size": 2612921,
    "path": "../public/_nuxt/index.lIBEqVyA.js.map"
  },
  "/_nuxt/index.xfqLyiTU.js": {
    "type": "application/javascript",
    "etag": "\"2e8-N4srWV898Z5hiyg1ueqZmPc+2Q4\"",
    "mtime": "2024-02-27T17:16:37.672Z",
    "size": 744,
    "path": "../public/_nuxt/index.xfqLyiTU.js"
  },
  "/_nuxt/index.xfqLyiTU.js.map": {
    "type": "application/json",
    "etag": "\"33f17-qG7ZKaOFzaOZiEihrNUF0TFaIFw\"",
    "mtime": "2024-02-27T17:16:37.801Z",
    "size": 212759,
    "path": "../public/_nuxt/index.xfqLyiTU.js.map"
  },
  "/_nuxt/index.zoal7U0i.js": {
    "type": "application/javascript",
    "etag": "\"2b9-EFYmAe+TPH3MNblF4K0aOuZpO2c\"",
    "mtime": "2024-02-27T17:16:37.672Z",
    "size": 697,
    "path": "../public/_nuxt/index.zoal7U0i.js"
  },
  "/_nuxt/index.zoal7U0i.js.map": {
    "type": "application/json",
    "etag": "\"48c504-jwANh7cD39J9DGEX8vCZ9Bsg9PU\"",
    "mtime": "2024-02-27T17:16:38.039Z",
    "size": 4769028,
    "path": "../public/_nuxt/index.zoal7U0i.js.map"
  },
  "/_nuxt/keshmed-logo.f8b6jEVg.js": {
    "type": "application/javascript",
    "etag": "\"9a-n5NU9Rc7bEQnMEVWGYuJn5p9mz8\"",
    "mtime": "2024-02-27T17:16:37.670Z",
    "size": 154,
    "path": "../public/_nuxt/keshmed-logo.f8b6jEVg.js"
  },
  "/_nuxt/keshmed-logo.f8b6jEVg.js.map": {
    "type": "application/json",
    "etag": "\"69-c0WyzaJsdHKiyXyBr9w0BiEMDZk\"",
    "mtime": "2024-02-27T17:16:37.801Z",
    "size": 105,
    "path": "../public/_nuxt/keshmed-logo.f8b6jEVg.js.map"
  },
  "/_nuxt/lodash.orgtvGpf.js": {
    "type": "application/javascript",
    "etag": "\"1198d-XWE6nPkEyi0DgZkbn1zZbvm40D8\"",
    "mtime": "2024-02-27T17:16:37.701Z",
    "size": 72077,
    "path": "../public/_nuxt/lodash.orgtvGpf.js"
  },
  "/_nuxt/lodash.orgtvGpf.js.map": {
    "type": "application/json",
    "etag": "\"ae611-NAS0FFV9nqA82ASl5cXtl645Nq8\"",
    "mtime": "2024-02-27T17:16:37.950Z",
    "size": 714257,
    "path": "../public/_nuxt/lodash.orgtvGpf.js.map"
  },
  "/_nuxt/login.G4tvzTF0.js": {
    "type": "application/javascript",
    "etag": "\"985-6akgNQE56JWl95N4pqgyFCjpQPM\"",
    "mtime": "2024-02-27T17:16:37.700Z",
    "size": 2437,
    "path": "../public/_nuxt/login.G4tvzTF0.js"
  },
  "/_nuxt/login.G4tvzTF0.js.map": {
    "type": "application/json",
    "etag": "\"115e-0c2mmAd3OuqoGCBVM3lZPtwBVTk\"",
    "mtime": "2024-02-27T17:16:37.805Z",
    "size": 4446,
    "path": "../public/_nuxt/login.G4tvzTF0.js.map"
  },
  "/_nuxt/materialdesignicons-webfont.6eb_lmTU.woff2": {
    "type": "font/woff2",
    "etag": "\"62710-TiD2zPQxmd6lyFsjoODwuoH/7iY\"",
    "mtime": "2024-02-27T17:16:37.669Z",
    "size": 403216,
    "path": "../public/_nuxt/materialdesignicons-webfont.6eb_lmTU.woff2"
  },
  "/_nuxt/materialdesignicons-webfont.D15t_tsC.woff": {
    "type": "font/woff",
    "etag": "\"8f8d0-zD3UavWtb7zNpwtFPVWUs57NasQ\"",
    "mtime": "2024-02-27T17:16:37.673Z",
    "size": 587984,
    "path": "../public/_nuxt/materialdesignicons-webfont.D15t_tsC.woff"
  },
  "/_nuxt/materialdesignicons-webfont.e5j8FT_3.ttf": {
    "type": "font/ttf",
    "etag": "\"13f40c-T1Gk3HWmjT5XMhxEjv3eojyKnbA\"",
    "mtime": "2024-02-27T17:16:37.701Z",
    "size": 1307660,
    "path": "../public/_nuxt/materialdesignicons-webfont.e5j8FT_3.ttf"
  },
  "/_nuxt/materialdesignicons-webfont.kq_ClZaA.eot": {
    "type": "application/vnd.ms-fontobject",
    "etag": "\"13f4e8-ApygSKV9BTQg/POr5dCUzjU5OZw\"",
    "mtime": "2024-02-27T17:16:37.675Z",
    "size": 1307880,
    "path": "../public/_nuxt/materialdesignicons-webfont.kq_ClZaA.eot"
  },
  "/_nuxt/orders.E05YctsL.js": {
    "type": "application/javascript",
    "etag": "\"120a-7SPPUhWrracQCghVaT3PEuqkdqk\"",
    "mtime": "2024-02-27T17:16:37.672Z",
    "size": 4618,
    "path": "../public/_nuxt/orders.E05YctsL.js"
  },
  "/_nuxt/orders.E05YctsL.js.map": {
    "type": "application/json",
    "etag": "\"2222-5T1SnPcFtI493XGFPgGUxfv9Yso\"",
    "mtime": "2024-02-27T17:16:37.801Z",
    "size": 8738,
    "path": "../public/_nuxt/orders.E05YctsL.js.map"
  },
  "/_nuxt/products.aKzbIz-X.js": {
    "type": "application/javascript",
    "etag": "\"1ba5-4kjomTD8NTwNe5z7BAjIopZQ8Eo\"",
    "mtime": "2024-02-27T17:16:37.670Z",
    "size": 7077,
    "path": "../public/_nuxt/products.aKzbIz-X.js"
  },
  "/_nuxt/products.aKzbIz-X.js.map": {
    "type": "application/json",
    "etag": "\"9a17d-QXaMgMXHgaUGoxsLqbEmbUk13bc\"",
    "mtime": "2024-02-27T17:16:37.800Z",
    "size": 631165,
    "path": "../public/_nuxt/products.aKzbIz-X.js.map"
  },
  "/_nuxt/useBrands.hvrC5f7P.js": {
    "type": "application/javascript",
    "etag": "\"13a-yxzMFh3X51/QlJZXicjQKn12oUA\"",
    "mtime": "2024-02-27T17:16:37.669Z",
    "size": 314,
    "path": "../public/_nuxt/useBrands.hvrC5f7P.js"
  },
  "/_nuxt/useBrands.hvrC5f7P.js.map": {
    "type": "application/json",
    "etag": "\"418-yxXTccfH8MFLezxT86Mw2uBra+w\"",
    "mtime": "2024-02-27T17:16:37.703Z",
    "size": 1048,
    "path": "../public/_nuxt/useBrands.hvrC5f7P.js.map"
  },
  "/_nuxt/useCategories.irO-WxiL.js": {
    "type": "application/javascript",
    "etag": "\"18c-G9xY9J6VSBZFovQNOKxFV3wEIhA\"",
    "mtime": "2024-02-27T17:16:37.672Z",
    "size": 396,
    "path": "../public/_nuxt/useCategories.irO-WxiL.js"
  },
  "/_nuxt/useCategories.irO-WxiL.js.map": {
    "type": "application/json",
    "etag": "\"4c2-lbErfNORwWI3nP45UIqyxyL7Nms\"",
    "mtime": "2024-02-27T17:16:37.805Z",
    "size": 1218,
    "path": "../public/_nuxt/useCategories.irO-WxiL.js.map"
  },
  "/_nuxt/useOrders.IqAoDDSj.js": {
    "type": "application/javascript",
    "etag": "\"128-xCgzI5bpj5XyMPc/hyi9W+lQhbQ\"",
    "mtime": "2024-02-27T17:16:37.670Z",
    "size": 296,
    "path": "../public/_nuxt/useOrders.IqAoDDSj.js"
  },
  "/_nuxt/useOrders.IqAoDDSj.js.map": {
    "type": "application/json",
    "etag": "\"3be-uyAIASJqiVGRyPkP2497xU9OoMU\"",
    "mtime": "2024-02-27T17:16:37.708Z",
    "size": 958,
    "path": "../public/_nuxt/useOrders.IqAoDDSj.js.map"
  },
  "/_nuxt/useProducts.p1LffWDY.js": {
    "type": "application/javascript",
    "etag": "\"1dc-KSiBy47IWbhhcSLIF+ZIZ+TYQbk\"",
    "mtime": "2024-02-27T17:16:37.671Z",
    "size": 476,
    "path": "../public/_nuxt/useProducts.p1LffWDY.js"
  },
  "/_nuxt/useProducts.p1LffWDY.js.map": {
    "type": "application/json",
    "etag": "\"65e-otVhryKv0KiIn/GEaEXpBVnPyJc\"",
    "mtime": "2024-02-27T17:16:37.800Z",
    "size": 1630,
    "path": "../public/_nuxt/useProducts.p1LffWDY.js.map"
  },
  "/_nuxt/vue.f36acd1f.tp68LqwU.js": {
    "type": "application/javascript",
    "etag": "\"1bf-0A+QTzecuz6DCHH98/FBht+fwdc\"",
    "mtime": "2024-02-27T17:16:37.671Z",
    "size": 447,
    "path": "../public/_nuxt/vue.f36acd1f.tp68LqwU.js"
  },
  "/_nuxt/vue.f36acd1f.tp68LqwU.js.map": {
    "type": "application/json",
    "etag": "\"82f-uzDCV9CYjRL31cxmK244BI4lND0\"",
    "mtime": "2024-02-27T17:16:37.801Z",
    "size": 2095,
    "path": "../public/_nuxt/vue.f36acd1f.tp68LqwU.js.map"
  },
  "/_nuxt/_id_.UiTrT67d.js": {
    "type": "application/javascript",
    "etag": "\"32ba-affu+9CUeW0Ho9O3SzWlUfhkHX4\"",
    "mtime": "2024-02-27T17:16:37.700Z",
    "size": 12986,
    "path": "../public/_nuxt/_id_.UiTrT67d.js"
  },
  "/_nuxt/_id_.UiTrT67d.js.map": {
    "type": "application/json",
    "etag": "\"67a7-MAdvXgUJZ5AGfEGKq8pcepa0OOA\"",
    "mtime": "2024-02-27T17:16:37.810Z",
    "size": 26535,
    "path": "../public/_nuxt/_id_.UiTrT67d.js.map"
  },
  "/_nuxt/builds/latest.json": {
    "type": "application/json",
    "etag": "\"47-NMdWFa9Tz9tgPczdoSa1YW8uo0Y\"",
    "mtime": "2024-02-27T17:16:59.019Z",
    "size": 71,
    "path": "../public/_nuxt/builds/latest.json"
  },
  "/_nuxt/builds/meta/41103305-d016-4eb8-a874-8ee625bd32d2.json": {
    "type": "application/json",
    "etag": "\"8b-rQ5yE53EQtXfrafIjiGOwSI5rdA\"",
    "mtime": "2024-02-27T17:16:59.020Z",
    "size": 139,
    "path": "../public/_nuxt/builds/meta/41103305-d016-4eb8-a874-8ee625bd32d2.json"
  }
};

const _DRIVE_LETTER_START_RE = /^[A-Za-z]:\//;
function normalizeWindowsPath(input = "") {
  if (!input) {
    return input;
  }
  return input.replace(/\\/g, "/").replace(_DRIVE_LETTER_START_RE, (r) => r.toUpperCase());
}
const _IS_ABSOLUTE_RE = /^[/\\](?![/\\])|^[/\\]{2}(?!\.)|^[A-Za-z]:[/\\]/;
const _DRIVE_LETTER_RE = /^[A-Za-z]:$/;
function cwd() {
  if (typeof process !== "undefined" && typeof process.cwd === "function") {
    return process.cwd().replace(/\\/g, "/");
  }
  return "/";
}
const resolve$1 = function(...arguments_) {
  arguments_ = arguments_.map((argument) => normalizeWindowsPath(argument));
  let resolvedPath = "";
  let resolvedAbsolute = false;
  for (let index = arguments_.length - 1; index >= -1 && !resolvedAbsolute; index--) {
    const path = index >= 0 ? arguments_[index] : cwd();
    if (!path || path.length === 0) {
      continue;
    }
    resolvedPath = `${path}/${resolvedPath}`;
    resolvedAbsolute = isAbsolute(path);
  }
  resolvedPath = normalizeString(resolvedPath, !resolvedAbsolute);
  if (resolvedAbsolute && !isAbsolute(resolvedPath)) {
    return `/${resolvedPath}`;
  }
  return resolvedPath.length > 0 ? resolvedPath : ".";
};
function normalizeString(path, allowAboveRoot) {
  let res = "";
  let lastSegmentLength = 0;
  let lastSlash = -1;
  let dots = 0;
  let char = null;
  for (let index = 0; index <= path.length; ++index) {
    if (index < path.length) {
      char = path[index];
    } else if (char === "/") {
      break;
    } else {
      char = "/";
    }
    if (char === "/") {
      if (lastSlash === index - 1 || dots === 1) ; else if (dots === 2) {
        if (res.length < 2 || lastSegmentLength !== 2 || res[res.length - 1] !== "." || res[res.length - 2] !== ".") {
          if (res.length > 2) {
            const lastSlashIndex = res.lastIndexOf("/");
            if (lastSlashIndex === -1) {
              res = "";
              lastSegmentLength = 0;
            } else {
              res = res.slice(0, lastSlashIndex);
              lastSegmentLength = res.length - 1 - res.lastIndexOf("/");
            }
            lastSlash = index;
            dots = 0;
            continue;
          } else if (res.length > 0) {
            res = "";
            lastSegmentLength = 0;
            lastSlash = index;
            dots = 0;
            continue;
          }
        }
        if (allowAboveRoot) {
          res += res.length > 0 ? "/.." : "..";
          lastSegmentLength = 2;
        }
      } else {
        if (res.length > 0) {
          res += `/${path.slice(lastSlash + 1, index)}`;
        } else {
          res = path.slice(lastSlash + 1, index);
        }
        lastSegmentLength = index - lastSlash - 1;
      }
      lastSlash = index;
      dots = 0;
    } else if (char === "." && dots !== -1) {
      ++dots;
    } else {
      dots = -1;
    }
  }
  return res;
}
const isAbsolute = function(p) {
  return _IS_ABSOLUTE_RE.test(p);
};
const dirname = function(p) {
  const segments = normalizeWindowsPath(p).replace(/\/$/, "").split("/").slice(0, -1);
  if (segments.length === 1 && _DRIVE_LETTER_RE.test(segments[0])) {
    segments[0] += "/";
  }
  return segments.join("/") || (isAbsolute(p) ? "/" : ".");
};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath(globalThis._importMeta_.url));
  return promises$1.readFile(resolve$1(serverDir, assets[id].path))
}

const publicAssetBases = {"/_nuxt/builds/meta":{"maxAge":31536000},"/_nuxt/builds":{"maxAge":1},"/_nuxt":{"maxAge":31536000}};

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = { gzip: ".gz", br: ".br" };
const _f4b49z = eventHandler((event) => {
  if (event.method && !METHODS.has(event.method)) {
    return;
  }
  let id = decodePath(
    withLeadingSlash(withoutTrailingSlash(parseURL(event.path).pathname))
  );
  let asset;
  const encodingHeader = String(
    getRequestHeader(event, "accept-encoding") || ""
  );
  const encodings = [
    ...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(),
    ""
  ];
  if (encodings.length > 1) {
    setResponseHeader(event, "Vary", "Accept-Encoding");
  }
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      removeResponseHeader(event, "Cache-Control");
      throw createError$1({
        statusMessage: "Cannot find static asset " + id,
        statusCode: 404
      });
    }
    return;
  }
  const ifNotMatch = getRequestHeader(event, "if-none-match") === asset.etag;
  if (ifNotMatch) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  const ifModifiedSinceH = getRequestHeader(event, "if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  if (asset.type && !getResponseHeader(event, "Content-Type")) {
    setResponseHeader(event, "Content-Type", asset.type);
  }
  if (asset.etag && !getResponseHeader(event, "ETag")) {
    setResponseHeader(event, "ETag", asset.etag);
  }
  if (asset.mtime && !getResponseHeader(event, "Last-Modified")) {
    setResponseHeader(event, "Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !getResponseHeader(event, "Content-Encoding")) {
    setResponseHeader(event, "Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !getResponseHeader(event, "Content-Length")) {
    setResponseHeader(event, "Content-Length", asset.size);
  }
  return readAsset(id);
});

const robots = [
  { UserAgent: '*' },
  { Allow: '/' },
  { Allow: '/products' },
  { Allow: '/product/*' },

  { Disallow: '/login' },
  { Disallow: '/admin/*' },

  { Sitemap: (req) => `https://${req.headers.host}/sitemap.xml` }
];

const _FT4oxe = defineEventHandler(async (event) => {
  setHeader(event, "Content-Type", "text/plain");
  return render(await getRules(robots, event.req));
});
var Correspondence = /* @__PURE__ */ ((Correspondence2) => {
  Correspondence2[Correspondence2["User-agent"] = 0] = "User-agent";
  Correspondence2[Correspondence2["Crawl-delay"] = 1] = "Crawl-delay";
  Correspondence2[Correspondence2["Disallow"] = 2] = "Disallow";
  Correspondence2[Correspondence2["Allow"] = 3] = "Allow";
  Correspondence2[Correspondence2["Host"] = 4] = "Host";
  Correspondence2[Correspondence2["Sitemap"] = 5] = "Sitemap";
  Correspondence2[Correspondence2["Clean-param"] = 6] = "Clean-param";
  Correspondence2[Correspondence2["Comment"] = 7] = "Comment";
  Correspondence2[Correspondence2["BlankLine"] = 8] = "BlankLine";
  return Correspondence2;
})(Correspondence || {});
function render(rules) {
  return rules.map((rule) => {
    const value = String(rule.value).trim();
    switch (rule.key.toString()) {
      case Correspondence[7 /* Comment */]:
        return `# ${value}`;
      case Correspondence[8 /* BlankLine */]:
        return "";
      default:
        return `${rule.key}: ${value}`;
    }
  }).join("\n");
}
async function getRules(options, req) {
  const correspondences = {
    useragent: "User-agent",
    crawldelay: "Crawl-delay",
    disallow: "Disallow",
    allow: "Allow",
    host: "Host",
    sitemap: "Sitemap",
    cleanparam: "Clean-param",
    comment: "Comment",
    blankline: "BlankLine"
  };
  const rules = [];
  const parseRule = (rule) => {
    const parsed = {};
    for (const [key, value] of Object.entries(rule)) {
      parsed[String(key).toLowerCase().replace(/[\W_]+/g, "")] = value;
    }
    return parsed;
  };
  for (const rule of Array.isArray(options) ? options : [options]) {
    const parsed = parseRule(rule);
    const keys = Object.keys(correspondences).filter((key) => typeof parsed[key] !== "undefined");
    for (const key of keys) {
      const parsedKey = parsed[key];
      let values;
      values = typeof parsedKey === "function" ? await parsedKey(req) : parsedKey;
      values = Array.isArray(values) ? values : [values];
      for (const value of values) {
        const v = typeof value === "function" ? await value(req) : value;
        if (v === false) {
          continue;
        }
        rules.push({
          key: correspondences[key],
          value: v
        });
      }
    }
  }
  return rules;
}

const _GtQoZh = defineEventHandler(async (e) => {
  if (e.context.siteConfig)
    return;
  const runtimeConfig = useRuntimeConfig(e);
  const config = runtimeConfig["nuxt-site-config"];
  const nitroApp = useNitroApp();
  const siteConfig = createSiteConfigStack({
    debug: config.debug
  });
  const appConfig = useAppConfig(e);
  const nitroOrigin = useNitroOrigin(e);
  e.context.siteConfigNitroOrigin = nitroOrigin;
  siteConfig.push({
    _context: "nitro:init",
    _priority: -4,
    url: nitroOrigin
  });
  siteConfig.push({
    _context: "runtimeEnv",
    _priority: 0,
    ...runtimeConfig.site || {},
    ...runtimeConfig.public.site || {},
    // @ts-expect-error untyped
    ...envSiteConfig(globalThis._importMeta_.env)
    // just in-case, shouldn't be needed
  });
  const buildStack = config.stack || [];
  buildStack.forEach((c) => siteConfig.push(c));
  if (appConfig.site) {
    siteConfig.push({
      _priority: -2,
      _context: "app:config",
      ...appConfig.site
    });
  }
  if (e.context._nitro.routeRules.site) {
    siteConfig.push({
      _context: "route-rules",
      ...e.context._nitro.routeRules.site
    });
  }
  const ctx = { siteConfig, event: e };
  await nitroApp.hooks.callHook("site-config:init", ctx);
  e.context.siteConfig = ctx.siteConfig;
});

const merger = createDefu((obj, key, value) => {
  if (Array.isArray(obj[key]) && Array.isArray(value))
    obj[key] = Array.from(/* @__PURE__ */ new Set([...obj[key], ...value]));
  return obj[key];
});
function mergeOnKey(arr, key) {
  const res = {};
  arr.forEach((item) => {
    const k = item[key];
    res[k] = merger(item, res[k] || {});
  });
  return Object.values(res);
}
function splitForLocales(path, locales) {
  const prefix = withLeadingSlash(path).split("/")[1];
  if (locales.includes(prefix))
    return [prefix, path.replace(`/${prefix}`, "")];
  return [null, path];
}

function resolve(s, resolvers) {
  if (typeof s === "undefined")
    return s;
  s = typeof s === "string" ? s : s.toString();
  if (hasProtocol(s, { acceptRelative: true, strict: false }))
    return resolvers.fixSlashes(s);
  return resolvers.canonicalUrlResolver(s);
}
function normaliseSitemapUrls(data, resolvers) {
  const entries = data.map((e) => typeof e === "string" ? { loc: e } : e).map((e) => {
    e = { ...e };
    if (e.url) {
      e.loc = e.url;
      delete e.url;
    }
    e.loc = fixSlashes(false, e.loc);
    return e;
  }).filter(Boolean);
  function normaliseEntry(e) {
    if (e.lastmod) {
      const date = normaliseDate(e.lastmod);
      if (date)
        e.lastmod = date;
      else
        delete e.lastmod;
    }
    if (!e.lastmod)
      delete e.lastmod;
    e.loc = resolve(e.loc, resolvers);
    if (e.alternatives) {
      e.alternatives = mergeOnKey(e.alternatives.map((e2) => {
        const a = { ...e2 };
        if (typeof a.href === "string")
          a.href = resolve(a.href, resolvers);
        else if (typeof a.href === "object" && a.href)
          a.href = resolve(a.href.href, resolvers);
        return a;
      }), "hreflang");
    }
    if (e.images) {
      e.images = mergeOnKey(e.images.map((i) => {
        i = { ...i };
        i.loc = resolve(i.loc, resolvers);
        return i;
      }), "loc");
    }
    if (e.videos) {
      e.videos = e.videos.map((v) => {
        v = { ...v };
        if (v.content_loc)
          v.content_loc = resolve(v.content_loc, resolvers);
        return v;
      });
    }
    return e;
  }
  return mergeOnKey(
    entries.map(normaliseEntry).map((e) => ({ ...e, _key: `${e._sitemap || ""}${e.loc}` })),
    "_key"
  );
}
function normaliseDate(d) {
  if (typeof d === "string") {
    d = d.replace("Z", "");
    d = d.replace(/\.\d+$/, "");
    if (d.match(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/) || d.match(/^\d{4}-\d{2}-\d{2}$/))
      return d;
    d = new Date(d);
    if (Number.isNaN(d.getTime()))
      return false;
  }
  const z = (n) => `0${n}`.slice(-2);
  return `${d.getUTCFullYear()}-${z(d.getUTCMonth() + 1)}-${z(d.getUTCDate())}T${z(d.getUTCHours())}:${z(d.getUTCMinutes())}:${z(d.getUTCSeconds())}+00:00`;
}

async function fetchDataSource(input) {
  const context = typeof input.context === "string" ? { name: input.context } : input.context || { name: "fetch" };
  context.tips = context.tips || [];
  const url = typeof input.fetch === "string" ? input.fetch : input.fetch[0];
  const options = typeof input.fetch === "string" ? {} : input.fetch[1];
  const start = Date.now();
  const timeout = options.timeout || 5e3;
  const timeoutController = new AbortController();
  const abortRequestTimeout = setTimeout(() => timeoutController.abort(), timeout);
  let isHtmlResponse = false;
  try {
    const urls = await globalThis.$fetch(url, {
      responseType: "json",
      signal: timeoutController.signal,
      headers: {
        Accept: "application/json"
      },
      // @ts-expect-error untyped
      onResponse({ response }) {
        if (typeof response._data === "string" && response._data.startsWith("<!DOCTYPE html>"))
          isHtmlResponse = true;
      }
    });
    const timeTakenMs = Date.now() - start;
    if (isHtmlResponse) {
      context.tips.push("This is usually because the URL isn't correct or is throwing an error. Please check the URL");
      return {
        ...input,
        context,
        urls: [],
        timeTakenMs,
        error: "Received HTML response instead of JSON"
      };
    }
    return {
      ...input,
      context,
      timeTakenMs,
      urls
    };
  } catch (_err) {
    const error = _err;
    if (error.message.includes("This operation was aborted"))
      context.tips.push("The request has taken too long. Make sure app sources respond within 5 seconds or adjust the timeout fetch option.");
    else
      context.tips.push(`Response returned a status of ${error.response?.status || "unknown"}.`);
    console.error("[nuxt-simple-sitemap] Failed to fetch source.", { url, error });
    return {
      ...input,
      context,
      urls: [],
      error: error.message
    };
  } finally {
    abortRequestTimeout && clearTimeout(abortRequestTimeout);
  }
}
function globalSitemapSources() {
  return import('../rollup/global-sources.mjs').then((m) => m.sources);
}
function childSitemapSources(definition) {
  return definition?._hasSourceChunk ? import('../rollup/child-sources.mjs').then((m) => m.sources[definition.sitemapName] || []) : Promise.resolve([]);
}
async function resolveSitemapSources(sources) {
  return (await Promise.all(
    sources.map((source) => {
      if (typeof source === "object" && "urls" in source) {
        return {
          timeTakenMs: 0,
          ...source,
          urls: source.urls
        };
      }
      if (source.fetch)
        return fetchDataSource(source);
      return {
        ...source,
        error: "Invalid source"
      };
    })
  )).flat();
}

function normaliseI18nSources(sources, { autoI18n, isI18nMapped }) {
  if (autoI18n && isI18nMapped) {
    return sources.map((s) => {
      const urls = (s.urls || []).map((_url) => {
        const url = typeof _url === "string" ? { loc: _url } : _url;
        url.loc = url.loc || url.url;
        url.loc = withLeadingSlash(url.loc);
        return url;
      });
      s.urls = urls.map((url) => {
        if (url._sitemap || url._i18nTransform)
          return url;
        if (url.loc) {
          const match = splitForLocales(url.loc, autoI18n.locales.map((l) => l.code));
          const localeCode = match[0] || autoI18n.defaultLocale;
          const pathWithoutPrefix = match[1];
          const locale = autoI18n.locales.find((e) => e.code === localeCode);
          if (locale) {
            if (!url.alternatives) {
              const alternatives = urls.map((u) => {
                if (u._sitemap || u._i18nTransform)
                  return false;
                if (u?.loc) {
                  const [_localeCode, _pathWithoutPrefix] = splitForLocales(u.loc, autoI18n.locales.map((l) => l.code));
                  if (pathWithoutPrefix === _pathWithoutPrefix) {
                    const entries = [];
                    if (_localeCode === autoI18n.defaultLocale) {
                      entries.push({
                        href: u.loc,
                        hreflang: "x-default"
                      });
                    }
                    entries.push({
                      href: u.loc,
                      hreflang: _localeCode || autoI18n.defaultLocale
                    });
                    return entries;
                  }
                }
                return false;
              }).flat().filter(Boolean);
              if (alternatives.length)
                url.alternatives = alternatives;
            }
            return {
              _sitemap: locale.iso || locale.code,
              ...url
            };
          }
        }
        return url;
      });
      return s;
    });
  }
  return sources;
}
function applyI18nEnhancements(_urls, options) {
  const { autoI18n } = options;
  return _urls.map((e) => {
    if (!e._i18nTransform)
      return e;
    delete e._i18nTransform;
    const path = withLeadingSlash(parseURL(e.loc).pathname);
    const match = splitForLocales(path, autoI18n.locales.map((l) => l.code));
    let pathWithoutLocale = path;
    let locale;
    if (match[0]) {
      pathWithoutLocale = match[1] || "/";
      locale = match[0];
    }
    if (locale && false) {
      console.warn("You're providing a locale in the url, but the url is marked as inheritI18n. This will cause issues with the sitemap. Please remove the locale from the url.");
      return e;
    }
    if (autoI18n.differentDomains) {
      return {
        // will force it to pass filter
        _sitemap: options.sitemapName,
        ...e,
        alternatives: [
          {
            // apply default locale domain
            ...autoI18n.locales.find((l) => [l.code, l.iso].includes(autoI18n.defaultLocale)),
            code: "x-default"
          },
          ...autoI18n.locales.filter((l) => !!l.domain)
        ].map((locale2) => {
          return {
            hreflang: locale2.iso || locale2.code,
            href: joinURL(withHttps(locale2.domain), pathWithoutLocale)
          };
        })
      };
    }
    return autoI18n.locales.map((l) => {
      let loc = joinURL(`/${l.code}`, pathWithoutLocale);
      if (autoI18n.differentDomains || ["prefix_and_default", "prefix_except_default"].includes(autoI18n.strategy) && l.code === autoI18n.defaultLocale)
        loc = pathWithoutLocale;
      return {
        _sitemap: options.isI18nMapped ? l.iso || l.code : void 0,
        ...e,
        loc,
        alternatives: [{ code: "x-default" }, ...autoI18n.locales].map((locale2) => {
          const code = locale2.code === "x-default" ? autoI18n.defaultLocale : locale2.code;
          const isDefault = locale2.code === "x-default" || locale2.code === autoI18n.defaultLocale;
          let href = "";
          if (autoI18n.strategy === "prefix") {
            href = joinURL("/", code, pathWithoutLocale);
          } else if (["prefix_and_default", "prefix_except_default"].includes(autoI18n.strategy)) {
            if (isDefault) {
              href = pathWithoutLocale;
            } else {
              href = joinURL("/", code, pathWithoutLocale);
            }
          }
          const hreflang = locale2.iso || locale2.code;
          return {
            hreflang,
            href
          };
        })
      };
    });
  }).flat();
}

function createFilter(options = {}) {
  const include = options.include || [];
  const exclude = options.exclude || [];
  if (include.length === 0 && exclude.length === 0)
    return () => true;
  return function(path) {
    for (const v of [{ rules: exclude, result: false }, { rules: include, result: true }]) {
      const regexRules = v.rules.filter((r) => r instanceof RegExp);
      if (regexRules.some((r) => r.test(path)))
        return v.result;
      const stringRules = v.rules.filter((r) => typeof r === "string");
      if (stringRules.length > 0) {
        const routes = {};
        for (const r of stringRules) {
          if (r === path)
            return v.result;
          routes[r] = true;
        }
        const routeRulesMatcher = toRouteMatcher(createRouter$1({ routes, strictTrailingSlash: false }));
        if (routeRulesMatcher.matchAll(path).length > 0)
          return Boolean(v.result);
      }
    }
    return include.length === 0;
  };
}
function filterSitemapUrls(_urls, options) {
  const urlFilter = createFilter({
    include: options.include,
    exclude: options.exclude
  });
  return _urls.filter((e) => {
    let path = e.loc;
    try {
      path = parseURL(e.loc).pathname;
    } catch {
      return false;
    }
    if (!urlFilter(path))
      return false;
    if (options.isMultiSitemap && e._sitemap && options.sitemapName)
      return e._sitemap === options.sitemapName;
    return true;
  });
}

function sortSitemapUrls(urls) {
  return urls.sort(
    (a, b) => {
      const aLoc = typeof a === "string" ? a : a.loc;
      const bLoc = typeof b === "string" ? b : b.loc;
      return aLoc.localeCompare(bLoc, void 0, { numeric: true });
    }
  ).sort((a, b) => {
    const aLoc = (typeof a === "string" ? a : a.loc) || "";
    const bLoc = (typeof b === "string" ? b : b.loc) || "";
    const aSegments = aLoc.split("/").length;
    const bSegments = bLoc.split("/").length;
    if (aSegments > bSegments)
      return 1;
    if (aSegments < bSegments)
      return -1;
    return 0;
  });
}

const StringifiedRegExpPattern = /\/(.*?)\/([gimsuy]*)$/;
function normalizeRuntimeFilters(input) {
  return (input || []).map((rule) => {
    if (rule instanceof RegExp || typeof rule === "string")
      return rule;
    const match = rule.regex.match(StringifiedRegExpPattern);
    if (match)
      return new RegExp(match[1], match[2]);
    return false;
  }).filter(Boolean);
}
function useSimpleSitemapRuntimeConfig() {
  const clone = JSON.parse(JSON.stringify(useRuntimeConfig()["nuxt-simple-sitemap"]));
  for (const k in clone.sitemaps) {
    const sitemap = clone.sitemaps[k];
    sitemap.include = normalizeRuntimeFilters(sitemap.include);
    sitemap.exclude = normalizeRuntimeFilters(sitemap.exclude);
    clone.sitemaps[k] = sitemap;
  }
  return Object.freeze(clone);
}

function resolveKey(k) {
  switch (k) {
    case "images":
      return "image";
    case "videos":
      return "video";
    case "news":
      return "news";
    default:
      return k;
  }
}
function handleObject(key, obj) {
  return [
    `        <${key}:${key}>`,
    ...Object.entries(obj).map(([sk, sv]) => {
      if (key === "video" && Array.isArray(sv)) {
        return sv.map((v) => {
          if (typeof v === "string") {
            return [
              `            `,
              `<${key}:${sk}>`,
              escapeValueForXml(v),
              `</${key}:${sk}>`
            ].join("");
          }
          const attributes = Object.entries(v).filter(([ssk]) => ssk !== sk).map(([ssk, ssv]) => `${ssk}="${escapeValueForXml(ssv)}"`).join(" ");
          return [
            `            <${key}:${sk} ${attributes}>`,
            // value is the same sk
            v[sk],
            `</${key}:${sk}>`
          ].join("");
        }).join("\n");
      }
      if (typeof sv === "object") {
        if (key === "video") {
          const attributes = Object.entries(sv).filter(([ssk]) => ssk !== sk).map(([ssk, ssv]) => `${ssk}="${escapeValueForXml(ssv)}"`).join(" ");
          return [
            `            <${key}:${sk} ${attributes}>`,
            // value is the same sk
            sv[sk],
            `</${key}:${sk}>`
          ].join("");
        }
        return [
          `            <${key}:${sk}>`,
          ...Object.entries(sv).map(([ssk, ssv]) => `                <${key}:${ssk}>${escapeValueForXml(ssv)}</${key}:${ssk}>`),
          `            </${key}:${sk}>`
        ].join("\n");
      }
      return `            <${key}:${sk}>${escapeValueForXml(sv)}</${key}:${sk}>`;
    }),
    `        </${key}:${key}>`
  ].join("\n");
}
function handleArray(key, arr) {
  if (arr.length === 0)
    return false;
  key = resolveKey(key);
  if (key === "alternatives") {
    return arr.map((obj) => [
      `        <xhtml:link rel="alternate" ${Object.entries(obj).map(([sk, sv]) => `${sk}="${escapeValueForXml(sv)}"`).join(" ")} />`
    ].join("\n")).join("\n");
  }
  return arr.map((obj) => handleObject(key, obj)).join("\n");
}
function handleEntry(k, e) {
  return Array.isArray(e[k]) ? handleArray(k, e[k]) : typeof e[k] === "object" ? handleObject(k, e[k]) : `        <${k}>${escapeValueForXml(e[k])}</${k}>`;
}
function wrapSitemapXml(input, resolvers, wrapSitemapXmlOptions) {
  const xsl = wrapSitemapXmlOptions.xsl ? resolvers.relativeBaseUrlResolver(wrapSitemapXmlOptions.xsl) : false;
  const credits = wrapSitemapXmlOptions.credits;
  input.unshift(`<?xml version="1.0" encoding="UTF-8"?>${xsl ? `<?xml-stylesheet type="text/xsl" href="${xsl}"?>` : ""}`);
  if (credits)
    input.push(`<!-- XML Sitemap generated by Nuxt Simple Sitemap v${wrapSitemapXmlOptions.version} -->`);
  return input.join("\n");
}
function escapeValueForXml(value) {
  if (value === true || value === false)
    return value ? "yes" : "no";
  return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}

async function buildSitemapIndex(resolvers) {
  const {
    sitemaps,
    // enhancing
    autoLastmod,
    // chunking
    defaultSitemapsChunkSize,
    autoI18n,
    isI18nMapped,
    sortEntries,
    // xls
    version,
    xsl,
    credits
  } = useSimpleSitemapRuntimeConfig();
  if (!sitemaps)
    throw new Error("Attempting to build a sitemap index without required `sitemaps` configuration.");
  function maybeSort(urls) {
    return sortEntries ? sortSitemapUrls(urls) : urls;
  }
  const isChunking = typeof sitemaps.chunks !== "undefined";
  const chunks = {};
  if (isChunking) {
    const sitemap = sitemaps.chunks;
    const sources = await resolveSitemapSources(await globalSitemapSources());
    const normalisedUrls = normaliseSitemapUrls(sources.map((e) => e.urls).flat(), resolvers);
    let enhancedUrls = normalisedUrls.map((e) => defu(e, sitemap.defaults));
    if (autoI18n?.locales)
      enhancedUrls = applyI18nEnhancements(enhancedUrls, { isI18nMapped, autoI18n, sitemapName: sitemap.sitemapName });
    const filteredUrls = filterSitemapUrls(enhancedUrls, { ...sitemap, autoI18n, isMultiSitemap: true });
    const sortedUrls = maybeSort(filteredUrls);
    sortedUrls.forEach((url, i) => {
      const chunkIndex = Math.floor(i / defaultSitemapsChunkSize);
      chunks[chunkIndex] = chunks[chunkIndex] || { urls: [] };
      chunks[chunkIndex].urls.push(url);
    });
  } else {
    for (const sitemap in sitemaps) {
      if (sitemap !== "index") {
        chunks[sitemap] = chunks[sitemap] || { urls: [] };
      }
    }
  }
  const entries = [];
  for (const name in chunks) {
    const sitemap = chunks[name];
    const entry = {
      sitemap: resolvers.canonicalUrlResolver(`${name}-sitemap.xml`)
    };
    let lastmod = sitemap.urls.filter((a) => !!a?.lastmod).map((a) => typeof a.lastmod === "string" ? new Date(a.lastmod) : a.lastmod).sort((a, b) => (b?.getTime() || 0) - (a?.getTime() || 0))?.[0];
    if (!lastmod && autoLastmod)
      lastmod = /* @__PURE__ */ new Date();
    if (lastmod)
      entry.lastmod = normaliseDate(lastmod);
    entries.push(entry);
  }
  if (sitemaps.index)
    entries.push(...sitemaps.index.sitemaps);
  const sitemapXml = entries.map((e) => [
    "    <sitemap>",
    `        <loc>${escapeValueForXml(e.sitemap)}</loc>`,
    // lastmod is optional
    e.lastmod ? `        <lastmod>${escapeValueForXml(e.lastmod)}</lastmod>` : false,
    "    </sitemap>"
  ].filter(Boolean).join("\n")).join("\n");
  return wrapSitemapXml([
    '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',
    sitemapXml,
    "</sitemapindex>"
  ], resolvers, { version, xsl, credits });
}

const _PD1Ozc = defineEventHandler(async (e) => {
  const canonicalQuery = getQuery(e).canonical;
  const isShowingCanonical = typeof canonicalQuery !== "undefined" && canonicalQuery !== "false";
  let sitemap = await buildSitemapIndex({
    event: e,
    canonicalUrlResolver: createSitePathResolver(e, { canonical: isShowingCanonical || !false, absolute: true, withBase: true }),
    relativeBaseUrlResolver: createSitePathResolver(e, { absolute: false, withBase: true })
  });
  const nitro = useNitroApp();
  const ctx = { sitemap, sitemapName: "sitemap" };
  await nitro.hooks.callHook("sitemap:output", ctx);
  sitemap = ctx.sitemap;
  setHeader(e, "Content-Type", "text/xml; charset=UTF-8");
  setHeader(e, "Cache-Control", "max-age=600, must-revalidate");
  return sitemap;
});

const _fyHplA = defineEventHandler(async (e) => {
  setHeader(e, "Content-Type", "application/xslt+xml");
  setHeader(e, "Cache-Control", "max-age=600, must-revalidate");
  const fixPath = createSitePathResolver(e, { absolute: false, withBase: true });
  const { sitemapName: fallbackSitemapName, version, xslColumns, xslTips } = useSimpleSitemapRuntimeConfig();
  const { name: siteName, url: siteUrl } = useSiteConfig(e);
  const referrer = getHeader(e, "Referer") || "/";
  const isNotIndexButHasIndex = referrer !== fixPath("/sitemap.xml") && parseURL(referrer).pathname.endsWith("-sitemap.xml");
  const sitemapName = parseURL(referrer).pathname.split("/").pop()?.split("-sitemap")[0] || fallbackSitemapName;
  const title = `${siteName}${sitemapName !== "sitemap.xml" ? ` - ${sitemapName === "sitemap_index.xml" ? "index" : sitemapName}` : ""}`.replace(/&/g, "&amp;");
  const canonicalQuery = getQuery$1(referrer).canonical;
  const isShowingCanonical = typeof canonicalQuery !== "undefined" && canonicalQuery !== "false";
  const conditionalTips = [
    'You are looking at a <a href="https://developer.mozilla.org/en-US/docs/Web/XSLT/Transforming_XML_with_XSLT/An_Overview" style="color: #398465" target="_blank">XML stylesheet</a>. Read the <a href="https://nuxtseo.com/sitemap/guides/customising-ui" style="color: #398465" target="_blank">docs</a> to learn how to customize it. View the page source to see the raw XML.',
    `URLs missing? Check Nuxt Devtools Sitemap tab (or the <a href="${withQuery("/__sitemap__/debug.json", { sitemap: sitemapName })}" style="color: #398465" target="_blank">debug endpoint</a>).`
  ];
  if (!isShowingCanonical) {
    const canonicalPreviewUrl = withQuery(referrer, { canonical: "" });
    conditionalTips.push(`Your canonical site URL is <strong>${siteUrl}</strong>.`);
    conditionalTips.push(`You can preview your canonical sitemap by visiting <a href="${canonicalPreviewUrl}" style="color: #398465; white-space: nowrap;">${fixPath(canonicalPreviewUrl)}?canonical</a>`);
  } else {
    conditionalTips.push(`You are viewing the canonical sitemap. You can switch to using the request origin: <a href="${fixPath(referrer)}" style="color: #398465; white-space: nowrap ">${fixPath(referrer)}</a>`);
  }
  let columns = [...xslColumns];
  if (!columns.length) {
    columns = [
      { label: "URL", width: "50%" },
      { label: "Images", width: "25%", select: "count(image:image)" },
      { label: "Last Updated", width: "25%", select: "concat(substring(sitemap:lastmod,0,11),concat(' ', substring(sitemap:lastmod,12,5)),concat(' ', substring(sitemap:lastmod,20,6)))" }
    ];
  }
  return `<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="2.0"
                xmlns:html="http://www.w3.org/TR/REC-html40"
                xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"
                xmlns:sitemap="http://www.sitemaps.org/schemas/sitemap/0.9"
                xmlns:xhtml="http://www.w3.org/1999/xhtml"
                xmlns:news="http://www.google.com/schemas/sitemap-news/0.9"
                xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:output method="html" version="1.0" encoding="UTF-8" indent="yes"/>
  <xsl:template match="/">
    <html xmlns="http://www.w3.org/1999/xhtml">
      <head>
        <title>XML Sitemap</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <style type="text/css">
          body {
            font-family: Inter, Helvetica, Arial, sans-serif;
            font-size: 14px;
            color: #333;
          }

          table {
            border: none;
            border-collapse: collapse;
          }

          .bg-yellow-200 {
            background-color: #fef9c3;
          }

          .p-5 {
            padding: 1.25rem;
          }

          .rounded {
            border-radius: 4px;
            }

          .shadow {
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
          }

          #sitemap tr:nth-child(odd) td {
            background-color: #f8f8f8 !important;
          }

          #sitemap tbody tr:hover td {
            background-color: #fff;
          }

          #sitemap tbody tr:hover td, #sitemap tbody tr:hover td a {
            color: #000;
          }

          .expl a {
            color: #398465
            font-weight: 600;
          }

          .expl a:visited {
            color: #398465
          }

          a {
            color: #000;
            text-decoration: none;
          }

          a:visited {
            color: #777;
          }

          a:hover {
            text-decoration: underline;
          }

          td {
            font-size: 12px;
          }

          .text-2xl {
            font-size: 2rem;
            font-weight: 600;
            line-height: 1.25;
          }

          th {
            text-align: left;
            padding-right: 30px;
            font-size: 12px;
          }

          thead th {
            border-bottom: 1px solid #000;
          }
          .fixed { position: fixed; }
          .right-2 { right: 2rem; }
          .top-2 { top: 2rem; }
          .w-30 { width: 30rem; }
          p { margin: 0; }
          li { padding-bottom: 0.5rem; line-height: 1.5; }
          h1 { margin: 0; }
          .mb-5 { margin-bottom: 1.25rem; }
          .mb-3 { margin-bottom: 0.75rem; }
        </style>
      </head>
      <body>
        <div style="grid-template-columns: 1fr 1fr; display: grid; margin: 3rem;">
            <div>
             <div id="content">
          <h1 class="text-2xl mb-3">XML Sitemap</h1>
          <h2>${title}</h2>
          ${isNotIndexButHasIndex ? `<p style="font-size: 12px; margin-bottom: 1rem;"><a href="${fixPath("/sitemap_index.xml")}">${fixPath("/sitemap_index.xml")}</a></p>` : ""}
          <xsl:if test="count(sitemap:sitemapindex/sitemap:sitemap) &gt; 0">
            <p class="expl" style="margin-bottom: 1rem;">
              This XML Sitemap Index file contains
              <xsl:value-of select="count(sitemap:sitemapindex/sitemap:sitemap)"/> sitemaps.
            </p>
            <table id="sitemap" cellpadding="3">
              <thead>
                <tr>
                  <th width="75%">Sitemap</th>
                  <th width="25%">Last Modified</th>
                </tr>
              </thead>
              <tbody>
                <xsl:for-each select="sitemap:sitemapindex/sitemap:sitemap">
                  <xsl:variable name="sitemapURL">
                    <xsl:value-of select="sitemap:loc"/>
                  </xsl:variable>
                  <tr>
                    <td>
                      <a href="{$sitemapURL}">
                        <xsl:value-of select="sitemap:loc"/>
                      </a>
                    </td>
                    <td>
                      <xsl:value-of
                        select="concat(substring(sitemap:lastmod,0,11),concat(' ', substring(sitemap:lastmod,12,5)),concat(' ', substring(sitemap:lastmod,20,6)))"/>
                    </td>
                  </tr>
                </xsl:for-each>
              </tbody>
            </table>
          </xsl:if>
          <xsl:if test="count(sitemap:sitemapindex/sitemap:sitemap) &lt; 1">
            <p class="expl" style="margin-bottom: 1rem;">
              This XML Sitemap contains
              <xsl:value-of select="count(sitemap:urlset/sitemap:url)"/> URLs.
            </p>
            <table id="sitemap" cellpadding="3">
              <thead>
                <tr>
                  ${columns.map((c) => `<th width="${c.width}">${c.label}</th>`).join("\n")}
                </tr>
              </thead>
              <tbody>
                <xsl:variable name="lower" select="'abcdefghijklmnopqrstuvwxyz'"/>
                <xsl:variable name="upper" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ'"/>
                <xsl:for-each select="sitemap:urlset/sitemap:url">
                  <tr>
                    <td>
                      <xsl:variable name="itemURL">
                        <xsl:value-of select="sitemap:loc"/>
                      </xsl:variable>
                      <a href="{$itemURL}">
                        <xsl:value-of select="sitemap:loc"/>
                      </a>
                    </td>
                    ${columns.filter((c) => c.label !== "URL").map((c) => `<td>
<xsl:value-of select="${c.select}"/>
</td>`).join("\n")}
                  </tr>
                </xsl:for-each>
              </tbody>
            </table>
          </xsl:if>
        </div>
        </div>
                    ${""}
        </div>
      </body>
    </html>
  </xsl:template>
</xsl:stylesheet>
`;
});

function withoutQuery(path) {
  return path.split("?")[0];
}
function createNitroRouteRuleMatcher() {
  const { nitro, app } = useRuntimeConfig();
  const _routeRulesMatcher = toRouteMatcher(
    createRouter$1({
      routes: Object.fromEntries(
        Object.entries(nitro?.routeRules || {}).map(([path, rules]) => [withoutTrailingSlash(path), rules])
      )
    })
  );
  return (path) => {
    return defu({}, ..._routeRulesMatcher.matchAll(
      // radix3 does not support trailing slashes
      withoutBase(withoutTrailingSlash(withoutQuery(path)), app.baseURL)
    ).reverse());
  };
}

async function buildSitemap(sitemap, resolvers) {
  const {
    sitemaps,
    // enhancing
    autoLastmod,
    autoI18n,
    isI18nMapped,
    isMultiSitemap,
    // sorting
    sortEntries,
    // chunking
    defaultSitemapsChunkSize,
    // xls
    version,
    xsl,
    credits
  } = useSimpleSitemapRuntimeConfig();
  const isChunking = typeof sitemaps.chunks !== "undefined" && !Number.isNaN(Number(sitemap.sitemapName));
  function maybeSort(urls2) {
    return sortEntries ? sortSitemapUrls(urls2) : urls2;
  }
  function maybeSlice(urls2) {
    if (isChunking && defaultSitemapsChunkSize) {
      const chunk = Number(sitemap.sitemapName);
      return urls2.slice(chunk * defaultSitemapsChunkSize, (chunk + 1) * defaultSitemapsChunkSize);
    }
    return urls2;
  }
  if (autoI18n?.differentDomains) {
    const domain = autoI18n.locales.find((e) => [e.iso, e.code].includes(sitemap.sitemapName))?.domain;
    if (domain) {
      const _tester = resolvers.canonicalUrlResolver;
      resolvers.canonicalUrlResolver = (path) => resolveSitePath(path, {
        absolute: true,
        withBase: false,
        siteUrl: withHttps(domain),
        trailingSlash: !_tester("/test/").endsWith("/"),
        base: "/"
      });
    }
  }
  const sources = sitemap.includeAppSources ? await globalSitemapSources() : [];
  sources.push(...await childSitemapSources(sitemap));
  let resolvedSources = await resolveSitemapSources(sources);
  if (autoI18n)
    resolvedSources = normaliseI18nSources(resolvedSources, { autoI18n, isI18nMapped });
  const normalisedUrls = normaliseSitemapUrls(resolvedSources.map((e) => e.urls).flat(), resolvers);
  ({ ...sitemap.defaults || {} });
  const routeRuleMatcher = createNitroRouteRuleMatcher();
  let enhancedUrls = normalisedUrls.map((e) => defu(e, sitemap.defaults)).map((e) => {
    const path = parseURL(e.loc).pathname;
    let routeRules = routeRuleMatcher(path);
    if (autoI18n?.locales && autoI18n?.strategy !== "no_prefix") {
      const match = splitForLocales(path, autoI18n.locales.map((l) => l.code));
      const pathWithoutPrefix = match[1];
      if (pathWithoutPrefix && pathWithoutPrefix !== path)
        routeRules = defu(routeRules, routeRuleMatcher(pathWithoutPrefix));
    }
    if (routeRules.sitemap === false)
      return false;
    if (typeof routeRules.index !== "undefined" && !routeRules.index)
      return false;
    const hasRobotsDisabled = Object.entries(routeRules.headers || {}).some(([name, value]) => name.toLowerCase() === "x-robots-tag" && value.toLowerCase() === "noindex");
    if (routeRules.redirect || hasRobotsDisabled)
      return false;
    return routeRules.sitemap ? defu(e, routeRules.sitemap) : e;
  }).filter(Boolean);
  if (autoI18n?.locales)
    enhancedUrls = applyI18nEnhancements(enhancedUrls, { isI18nMapped, autoI18n, sitemapName: sitemap.sitemapName });
  const filteredUrls = filterSitemapUrls(enhancedUrls, { event: resolvers.event, isMultiSitemap, autoI18n, ...sitemap });
  const sortedUrls = maybeSort(filteredUrls);
  const slicedUrls = maybeSlice(sortedUrls);
  const nitro = useNitroApp();
  const ctx = {
    urls: slicedUrls,
    sitemapName: sitemap.sitemapName
  };
  await nitro.hooks.callHook("sitemap:resolved", ctx);
  const urls = maybeSort(normaliseSitemapUrls(ctx.urls, resolvers));
  const urlset = urls.map((e) => {
    const keys = Object.keys(e).filter((k) => !k.startsWith("_"));
    return [
      "    <url>",
      keys.map((k) => handleEntry(k, e)).filter(Boolean).join("\n"),
      "    </url>"
    ].join("\n");
  });
  return wrapSitemapXml([
    '<urlset xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:video="http://www.google.com/schemas/sitemap-video/1.1" xmlns:xhtml="http://www.w3.org/1999/xhtml" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1" xmlns:news="http://www.google.com/schemas/sitemap-news/0.9" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd http://www.google.com/schemas/sitemap-image/1.1 http://www.google.com/schemas/sitemap-image/1.1/sitemap-image.xsd" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',
    urlset.join("\n"),
    "</urlset>"
  ], resolvers, { version, xsl, credits });
}

function useNitroUrlResolvers(e) {
  const canonicalQuery = getQuery(e).canonical;
  const isShowingCanonical = typeof canonicalQuery !== "undefined" && canonicalQuery !== "false";
  const siteConfig = useSiteConfig(e);
  return {
    event: e,
    fixSlashes: (path) => fixSlashes(siteConfig.trailingSlash, path),
    // we need these as they depend on the nitro event
    canonicalUrlResolver: createSitePathResolver(e, {
      canonical: isShowingCanonical || !false,
      absolute: true,
      withBase: true
    }),
    relativeBaseUrlResolver: createSitePathResolver(e, { absolute: false, withBase: true })
  };
}
async function createSitemap(e, definition) {
  const { sitemapName } = definition;
  const nitro = useNitroApp();
  let sitemap = await (definition.sitemapName === "index" ? buildSitemapIndex(useNitroUrlResolvers(e)) : buildSitemap(definition, useNitroUrlResolvers(e)));
  const ctx = { sitemap, sitemapName };
  await nitro.hooks.callHook("sitemap:output", ctx);
  sitemap = ctx.sitemap;
  setHeader(e, "Content-Type", "text/xml; charset=UTF-8");
  setHeader(e, "Cache-Control", "max-age=600, must-revalidate");
  e.context._isSitemap = true;
  return sitemap;
}

const _0TfPLr = defineEventHandler(async (e) => {
  const { sitemaps } = useSimpleSitemapRuntimeConfig();
  if ("index" in sitemaps) {
    return sendRedirect(e, withBase("/sitemap_index.xml", useRuntimeConfig().app.baseURL), 301);
  }
  return createSitemap(e, Object.values(sitemaps)[0]);
});

const _Cs6BPH = lazyEventHandler(() => {
  const opts = useRuntimeConfig().ipx || {};
  const fsDir = opts.fs?.dir ? isAbsolute(opts.fs.dir) ? opts.fs.dir : fileURLToPath(new URL(opts.fs.dir, globalThis._importMeta_.url)) : void 0;
  const fsStorage = opts.fs?.dir ? ipxFSStorage({ ...opts.fs, dir: fsDir }) : void 0;
  const httpStorage = opts.http?.domains ? ipxHttpStorage({ ...opts.http }) : void 0;
  if (!fsStorage && !httpStorage) {
    throw new Error("IPX storage is not configured!");
  }
  const ipxOptions = {
    ...opts,
    storage: fsStorage || httpStorage,
    httpStorage
  };
  const ipx = createIPX(ipxOptions);
  const ipxHandler = createIPXH3Handler(ipx);
  return useBase(opts.baseURL, ipxHandler);
});

const _lazy_wLDKVG = () => import('../handlers/renderer.mjs').then(function (n) { return n.r; });

const handlers = [
  { route: '', handler: _f4b49z, lazy: false, middleware: true, method: undefined },
  { route: '/__nuxt_error', handler: _lazy_wLDKVG, lazy: true, middleware: false, method: undefined },
  { route: '/robots.txt', handler: _FT4oxe, lazy: false, middleware: false, method: undefined },
  { route: '', handler: _GtQoZh, lazy: false, middleware: true, method: undefined },
  { route: '/sitemap_index.xml', handler: _PD1Ozc, lazy: false, middleware: false, method: undefined },
  { route: '/__sitemap__/style.xsl', handler: _fyHplA, lazy: false, middleware: false, method: undefined },
  { route: '/sitemap.xml', handler: _0TfPLr, lazy: false, middleware: false, method: undefined },
  { route: '/_ipx/**', handler: _Cs6BPH, lazy: false, middleware: false, method: undefined },
  { route: '/index-sitemap.xml', handler: _lazy_wLDKVG, lazy: true, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_wLDKVG, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const captureError = (error, context = {}) => {
    const promise = hooks.callHookParallel("error", error, context).catch((_err) => {
      console.error("Error while capturing another error", _err);
    });
    if (context.event && isEvent(context.event)) {
      const errors = context.event.context.nitro?.errors;
      if (errors) {
        errors.push({ error, context });
      }
      if (context.event.waitUntil) {
        context.event.waitUntil(promise);
      }
    }
  };
  const h3App = createApp({
    debug: destr(false),
    onError: (error, event) => {
      captureError(error, { event, tags: ["request"] });
      return errorHandler(error, event);
    },
    onRequest: async (event) => {
      await nitroApp.hooks.callHook("request", event).catch((error) => {
        captureError(error, { event, tags: ["request"] });
      });
    },
    onBeforeResponse: async (event, response) => {
      await nitroApp.hooks.callHook("beforeResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    },
    onAfterResponse: async (event, response) => {
      await nitroApp.hooks.callHook("afterResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    }
  });
  const router = createRouter({
    preemptive: true
  });
  const localCall = createCall(toNodeListener(h3App));
  const _localFetch = createFetch(localCall, globalThis.fetch);
  const localFetch = (input, init) => _localFetch(input, init).then(
    (response) => normalizeFetchResponse(response)
  );
  const $fetch = createFetch$1({
    fetch: localFetch,
    Headers: Headers$1,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(createRouteRulesHandler({ localFetch }));
  h3App.use(
    eventHandler((event) => {
      event.context.nitro = event.context.nitro || { errors: [] };
      const envContext = event.node.req?.__unenv__;
      if (envContext) {
        Object.assign(event.context, envContext);
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, {
        fetch: $fetch
      });
      event.waitUntil = (promise) => {
        if (!event.context.nitro._waitUntilPromises) {
          event.context.nitro._waitUntilPromises = [];
        }
        event.context.nitro._waitUntilPromises.push(promise);
        if (envContext?.waitUntil) {
          envContext.waitUntil(promise);
        }
      };
      event.captureError = (error, context) => {
        captureError(error, { event, ...context });
      };
    })
  );
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router.handler);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch,
    captureError
  };
  for (const plugin of plugins) {
    try {
      plugin(app);
    } catch (err) {
      captureError(err, { tags: ["plugin"] });
      throw err;
    }
  }
  return app;
}
const nitroApp = createNitroApp();
const useNitroApp = () => nitroApp;

const debug = (...args) => {
};
function GracefulShutdown(server, opts) {
  opts = opts || {};
  const options = Object.assign(
    {
      signals: "SIGINT SIGTERM",
      timeout: 3e4,
      development: false,
      forceExit: true,
      onShutdown: (signal) => Promise.resolve(signal),
      preShutdown: (signal) => Promise.resolve(signal)
    },
    opts
  );
  let isShuttingDown = false;
  const connections = {};
  let connectionCounter = 0;
  const secureConnections = {};
  let secureConnectionCounter = 0;
  let failed = false;
  let finalRun = false;
  function onceFactory() {
    let called = false;
    return (emitter, events, callback) => {
      function call() {
        if (!called) {
          called = true;
          return Reflect.apply(callback, this, arguments);
        }
      }
      for (const e of events) {
        emitter.on(e, call);
      }
    };
  }
  const signals = options.signals.split(" ").map((s) => s.trim()).filter((s) => s.length > 0);
  const once = onceFactory();
  once(process, signals, (signal) => {
    shutdown(signal).then(() => {
      if (options.forceExit) {
        process.exit(failed ? 1 : 0);
      }
    }).catch((err) => {
      process.exit(1);
    });
  });
  function isFunction(functionToCheck) {
    const getType = Object.prototype.toString.call(functionToCheck);
    return /^\[object\s([A-Za-z]+)?Function]$/.test(getType);
  }
  function destroy(socket, force = false) {
    if (socket._isIdle && isShuttingDown || force) {
      socket.destroy();
      if (socket.server instanceof http.Server) {
        delete connections[socket._connectionId];
      } else {
        delete secureConnections[socket._connectionId];
      }
    }
  }
  function destroyAllConnections(force = false) {
    for (const key of Object.keys(connections)) {
      const socket = connections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        destroy(socket);
      }
    }
    for (const key of Object.keys(secureConnections)) {
      const socket = secureConnections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        destroy(socket);
      }
    }
  }
  server.on("request", function(req, res) {
    req.socket._isIdle = false;
    if (isShuttingDown && !res.headersSent) {
      res.setHeader("connection", "close");
    }
    res.on("finish", function() {
      req.socket._isIdle = true;
      destroy(req.socket);
    });
  });
  server.on("connection", function(socket) {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = connectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      connections[id] = socket;
      socket.once("close", () => {
        delete connections[socket._connectionId];
      });
    }
  });
  server.on("secureConnection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = secureConnectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      secureConnections[id] = socket;
      socket.once("close", () => {
        delete secureConnections[socket._connectionId];
      });
    }
  });
  process.on("close", function() {
  });
  function shutdown(sig) {
    function cleanupHttp() {
      destroyAllConnections();
      return new Promise((resolve, reject) => {
        server.close((err) => {
          if (err) {
            return reject(err);
          }
          return resolve(true);
        });
      });
    }
    if (options.development) {
      return process.exit(0);
    }
    function finalHandler() {
      if (!finalRun) {
        finalRun = true;
        if (options.finally && isFunction(options.finally)) {
          options.finally();
        }
      }
      return Promise.resolve();
    }
    function waitForReadyToShutDown(totalNumInterval) {
      if (totalNumInterval === 0) {
        debug(
          `Could not close connections in time (${options.timeout}ms), will forcefully shut down`
        );
        return Promise.resolve(true);
      }
      const allConnectionsClosed = Object.keys(connections).length === 0 && Object.keys(secureConnections).length === 0;
      if (allConnectionsClosed) {
        return Promise.resolve(false);
      }
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve(waitForReadyToShutDown(totalNumInterval - 1));
        }, 250);
      });
    }
    if (isShuttingDown) {
      return Promise.resolve();
    }
    return options.preShutdown(sig).then(() => {
      isShuttingDown = true;
      cleanupHttp();
    }).then(() => {
      const pollIterations = options.timeout ? Math.round(options.timeout / 250) : 0;
      return waitForReadyToShutDown(pollIterations);
    }).then((force) => {
      if (force) {
        destroyAllConnections(force);
      }
      return options.onShutdown(sig);
    }).then(finalHandler).catch((err) => {
      const errString = typeof err === "string" ? err : JSON.stringify(err);
      failed = true;
      throw errString;
    });
  }
  function shutdownManual() {
    return shutdown("manual");
  }
  return shutdownManual;
}

function getGracefulShutdownConfig() {
  return {
    disabled: !!process.env.NITRO_SHUTDOWN_DISABLED,
    signals: (process.env.NITRO_SHUTDOWN_SIGNALS || "SIGTERM SIGINT").split(" ").map((s) => s.trim()),
    timeout: Number.parseInt(process.env.NITRO_SHUTDOWN_TIMEOUT, 10) || 3e4,
    forceExit: !process.env.NITRO_SHUTDOWN_NO_FORCE_EXIT
  };
}
function setupGracefulShutdown(listener, nitroApp) {
  const shutdownConfig = getGracefulShutdownConfig();
  if (shutdownConfig.disabled) {
    return;
  }
  GracefulShutdown(listener, {
    signals: shutdownConfig.signals.join(" "),
    timeout: shutdownConfig.timeout,
    forceExit: shutdownConfig.forceExit,
    onShutdown: async () => {
      await new Promise((resolve) => {
        const timeout = setTimeout(() => {
          console.warn("Graceful shutdown timeout, force exiting...");
          resolve();
        }, shutdownConfig.timeout);
        nitroApp.hooks.callHook("close").catch((err) => {
          console.error(err);
        }).finally(() => {
          clearTimeout(timeout);
          resolve();
        });
      });
    }
  });
}

const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const server = cert && key ? new Server({ key, cert }, toNodeListener(nitroApp.h3App)) : new Server$1(toNodeListener(nitroApp.h3App));
const port = destr(process.env.NITRO_PORT || process.env.PORT) || 3e3;
const host = process.env.NITRO_HOST || process.env.HOST;
const path = process.env.NITRO_UNIX_SOCKET;
const listener = server.listen(path ? { path } : { port, host }, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  const protocol = cert && key ? "https" : "http";
  const addressInfo = listener.address();
  if (typeof addressInfo === "string") {
    console.log(`Listening on unix socket ${addressInfo}`);
    return;
  }
  const baseURL = (useRuntimeConfig().app.baseURL || "").replace(/\/$/, "");
  const url = `${protocol}://${addressInfo.family === "IPv6" ? `[${addressInfo.address}]` : addressInfo.address}:${addressInfo.port}${baseURL}`;
  console.log(`Listening on ${url}`);
});
trapUnhandledNodeErrors();
setupGracefulShutdown(listener, nitroApp);
const nodeServer = {};

export { $fetch as $, ofetch as A, getRequestHeaders as B, nodeServer as C, send as a, setResponseStatus as b, setResponseHeaders as c, useRuntimeConfig as d, eventHandler as e, getQuery as f, getResponseStatus as g, createError$1 as h, getRouteRules as i, joinURL as j, getResponseStatusText as k, defu as l, sanitizeStatusCode as m, klona as n, getRequestHeader as o, parse as p, createHooks as q, destr as r, setResponseHeader as s, isEqual as t, useNitroApp as u, setCookie as v, getCookie as w, deleteCookie as x, toRouteMatcher as y, createRouter$1 as z };
